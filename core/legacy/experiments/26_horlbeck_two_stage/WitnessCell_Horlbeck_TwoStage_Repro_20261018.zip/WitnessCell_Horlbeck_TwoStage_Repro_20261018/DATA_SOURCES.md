# 数据来源与可复现范围

本包从作者发布的重复特异增长表型出发，已经保留两阶段实际使用的处理后数组。默认复现完全离线，不下载数据、不连接OSF、不安装软件。

原始研究与数据：

- Horlbeck et al. 2018: https://pmc.ncbi.nlm.nih.gov/articles/PMC6426455/
- GEO GSE116198: https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE116198
- 作者分析代码: https://github.com/mhorlbeck/GImap_tools/blob/master/GImap_analysis.py

作者的两个原始下载文件：

| 文件 | SHA-256 |
|---|---|
| `GSE116198_sgRNA_pair_phenotypes.txt.gz` | `ba9772f3b0e929bcf5b23bebf17d4caab86c7f2ccd50dbd62fbc47e40c2aac21` |
| `GSE116198_GImap_sgRNA_sequences_barcodes.txt.gz` | `84a785108a5bf830ce2ee569e14757fe5c31738ba6d88c95206f38a0b1bbc150` |

两文件此前也包含在 `WitnessCell_Horlbeck_Freeze_v1.zip` 的 `data/raw/` 中。大文件不重复加入这个小于10 MB的模型复现包。

如果已经获得这两个原始文件，可独立检查 Jurkat 聚合：

```bash
python3 stages/Jurkat/verify_source.py --raw /原始文件所在目录
```

这里使用 `Triple Sequencing` 的两个独立重复。K562原表含ID列的列索引为13、14，Jurkat为4、5；实现同时检查三层列名，不仅按数字取列。

聚合时，同一physical guide pair先平均AB/BA方向，再等权平均不同physical guide pairs；单扰动由target–negative-control测量得到。发布的全图GI分数不作为留出标签。两个阶段的允许训练集合、单扰动信息和留出集合均在包内明确保存。

本包不包含：完整原始测序read counts/FASTQ、另一套未执行的RNA或MLP实验，以及未使用的大规模原始图谱。上述内容均不是复现这里两阶段模型数值的依赖。
