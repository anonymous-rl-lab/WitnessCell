"""Reproduce both stages from compact prepared data, then run full verifiers.

Creates a new output tree. No package files, scientific rules, data splits or
hyperparameter grids are modified. K562's execution list changes to recompute
all three folds, including the previously completed smoke fold.
"""
from pathlib import Path
import os,sys,json,shutil,subprocess,argparse,time,hashlib
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
import numpy as np
ROOT=Path(__file__).resolve().parent
METHODS=('M0','M0_repeat_mean','rank1_selected','spectral_selected','rank1_regularized','spectral_regularized')

def read(p):return json.loads(p.read_text())
def stage_call(root,script):
    print(f'Running {root.name}/{script} ...',flush=True)
    log=root/(script+'.log')
    with log.open('w') as stream:
        proc=subprocess.run([sys.executable,script],cwd=root,stdout=stream,stderr=subprocess.STDOUT)
    if proc.returncode:
        raise RuntimeError(f'{script} failed; log: {log}\n'+log.read_text()[-5000:])

def compare_npz(a,b,keys):
    differences={}
    with np.load(a,allow_pickle=False) as x,np.load(b,allow_pickle=False) as y:
        for key in keys:
            if x[key].shape!=y[key].shape:raise AssertionError('Shape changed: '+key)
            if x[key].dtype.kind in 'US' or key in ('ids','global_ids','edges','fold'):
                if not np.array_equal(x[key],y[key]):raise AssertionError('Identity changed: '+key)
                error=0.
            else:error=float(np.max(np.abs(x[key]-y[key]))) if x[key].size else 0.
            differences[key]=error
            if error>1e-10:raise AssertionError(f'Prediction difference {error} exceeds 1e-10: {key}')
    return differences

def regenerate(stage,output):
    source=ROOT/'stages'/stage
    dest=output/stage
    shutil.copytree(source,dest)
    start=time.monotonic()
    prediction_errors=[];metric_errors=[];selection_matches=[]
    if stage=='K562':
        plan=read(dest/'PLAN.json')
        plan['new_folds']=[0,1,2]
        plan['reproduction_note']='Execution-only: regenerate all three original folds with the frozen scientific rules and same prepared inputs.'
        (dest/'PLAN.json').write_text(json.dumps(plan,indent=2))
        for fold in range(3):
            for budget in ('low','high'):(dest/'cases'/f'outer{fold}'/'results'/budget/'inner_models').mkdir(parents=True,exist_ok=True)
        stage_call(dest,'run_experiment.py');stage_call(dest,'score_all.py');stage_call(dest,'verify_full.py')
        expected,new=read(source/'SUMMARY.json'),read(dest/'SUMMARY.json')
        for budget in ('low','high'):
            prediction_errors.append(compare_npz(source/f'predictions_{budget}_all_folds.npz',dest/f'predictions_{budget}_all_folds.npz',('ids','fold','edges','y',*METHODS)))
            for method in METHODS:
                for key in ('mse_pooled','gain_pooled','projected_gain_pooled'):
                    metric_errors.append(abs(expected['aggregate'][budget]['models'][method][key]-new['aggregate'][budget]['models'][method][key]))
            for fold in range(3):
                rel=Path('cases')/f'outer{fold}'/'results'/budget
                a,b=read(source/rel/'selection.json'),read(dest/rel/'selection.json')
                for family in ('rank1','spectral'):
                    selection_matches.append(a[family]['selected']==b[family]['selected'])
                prediction_errors.append(compare_npz(source/rel/'predictions.npz',dest/rel/'predictions.npz',(*METHODS,'rank1_G','spectral_G')))
        metrics={b:{k:new['aggregate'][b]['models'][k]['gain_pooled'] for k in ('rank1_selected','spectral_selected')} for b in ('low','high')}
    else:
        (dest/'results/high/inner_models').mkdir(parents=True,exist_ok=True)
        stage_call(dest,'run_confirmation.py');stage_call(dest,'score_confirmation.py');stage_call(dest,'verify_confirmation.py')
        expected,new=read(source/'SUMMARY.json'),read(dest/'SUMMARY.json')
        prediction_errors.append(compare_npz(source/'results/high/predictions.npz',dest/'results/high/predictions.npz',('edges','global_ids',*METHODS,'rank1_G','spectral_G')))
        for method in ('M0','M0_repeat_mean','rank1_selected','spectral_selected'):
            for key in ('mse_pooled','gain_pooled','projected_gain_pooled'):
                metric_errors.append(abs(expected['models'][method][key]-new['models'][method][key]))
        prediction_errors.append(compare_npz(source/'results/node_reweighting_draws.npz',dest/'results/node_reweighting_draws.npz',('M0','M0_repeat_mean','rank1_selected','spectral_selected')))
        a,b=read(source/'results/high/selection.json'),read(dest/'results/high/selection.json')
        for family in ('rank1','spectral'):selection_matches.append(a[family]['selected']==b[family]['selected'])
        metrics={k:new['models'][k]['gain_pooled'] for k in ('rank1_selected','spectral_selected')}
    maximum_prediction=max(v for d in prediction_errors for v in d.values())
    maximum_metric=max(metric_errors)
    if maximum_metric>1e-10 or not all(selection_matches):raise AssertionError('Summary or model selection changed')
    independent=read(dest/'INDEPENDENT_CHECK.json')
    if independent['status']!='PASS':raise AssertionError('Independent checks failed')
    result={'status':'PASS','seconds':time.monotonic()-start,'max_prediction_or_draw_difference':maximum_prediction,
        'max_summary_difference':maximum_metric,'selected_models_identical':all(selection_matches),
        'independent_check':independent['status'],'independent_counts':independent.get('counts',{}),'gain_pooled':metrics}
    print(json.dumps({stage:result},indent=2),flush=True)
    return result

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--out',type=Path,default=Path('reproduced'),help='New output directory; existing directories are never overwritten')
    ap.add_argument('--stage',choices=('all','K562','Jurkat'),default='all')
    args=ap.parse_args();dest=args.out.resolve()
    if dest.exists():raise SystemExit('Output exists; specify a new --out directory.')
    # Validate the distributed compact payload before creating fresh results.
    subprocess.run([sys.executable,str(ROOT/'verify.py')],check=True)
    dest.mkdir(parents=True)
    stages=('K562','Jurkat') if args.stage=='all' else (args.stage,)
    start=time.monotonic();result={'status':'RUNNING','stages':{},'scope':'numerical reproduction of existing results, not a new confirmation experiment'}
    try:
        for stage in stages:result['stages'][stage]=regenerate(stage,dest)
        result['status']='PASS'
    except Exception as exc:
        result['status']='FAIL';result['error']=repr(exc);raise
    finally:
        result['total_seconds']=time.monotonic()-start
        (dest/'REPRODUCTION_CHECK.json').write_text(json.dumps(result,indent=2))
    print('Both stages reproduced and independently checked.' if len(stages)==2 else 'Selected stage reproduced and independently checked.')
    print('Summary: '+str(dest/'REPRODUCTION_CHECK.json'))
if __name__=='__main__':main()
