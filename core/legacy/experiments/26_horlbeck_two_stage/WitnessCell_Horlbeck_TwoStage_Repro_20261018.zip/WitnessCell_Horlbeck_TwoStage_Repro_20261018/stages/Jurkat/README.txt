WitnessCell Jurkat confirmation, 2026-10-18

Read WitnessCell_Horlbeck_Jurkat_Confirmation_20261018.txt for conclusions and boundaries.

Results: 79 genes, 2464 training pairs, 617 held-out pairs, two repeats. Original 80-gene v1 stopped on unavailable GINS4 singles; availability-only amendment archived before fitting.

Recheck saved results (no fitting):
  python3 verify_confirmation.py

Reproduce all models and scores in a NEW directory:
  python3 reproduce.py --out /absolute/path/jurkat_reproduction_new

Recheck original source aggregation (requires original frozen raw files):
  python3 verify_source.py --raw /path/to/WitnessCell_Horlbeck_Freeze_v1/data/raw

Source download entry: https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE116198
Required raw filenames and exact hashes are in INPUT_PROVENANCE.json.
The large source gzip is not duplicated here. Prepared labels and counts are included for full model-level reproducibility.

Dependencies: numpy, scipy; matplotlib only to regenerate the figure. ENVIRONMENT.json records actual versions. Use an existing compatible environment; do not reinstall CUDA.

PLAN.json and FREEZE.json preserve the pre-fit rules. PREDICTIONS_LOCKED.json predates test scoring. Original v1 snapshot and pre-fit availability amendment are in protocol/. This local freeze is not a new OSF registration; the assistant did not submit a registration.

All methods were refit on Jurkat training data under the frozen rule. This is held-environment confirmation within the same original study, not independent-study replication or K562-weight zero-shot transfer. The node reweighting interval is conditional and not a calibrated population confidence guarantee.

INDEPENDENT_CHECK.json and SOURCE_CHECK.json contain separate independent checks. REPRODUCTION_CHECK.json records a fresh rerun. No additional scientific model was selected using this rerun.
