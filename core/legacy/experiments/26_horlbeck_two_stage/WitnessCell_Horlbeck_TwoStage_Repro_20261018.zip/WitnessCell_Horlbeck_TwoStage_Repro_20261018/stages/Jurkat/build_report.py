"""Create a result report and figure after independent checks; not analysis selection."""
from pathlib import Path
import json,hashlib,csv
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parent
NAME='WitnessCell_Horlbeck_Jurkat_Confirmation_20261018'
def main():
    s=json.loads((ROOT/'SUMMARY.json').read_text());v=json.loads((ROOT/'INDEPENDENT_CHECK.json').read_text());a=json.loads((ROOT/'SOURCE_CHECK.json').read_text())
    assert v['status']=='PASS' and a['status']=='PASS'
    rows=s['models'];r=rows['rank1_selected'];m=rows['spectral_selected'];b=rows['M0'];avg=rows['M0_repeat_mean']
    lock=json.loads((ROOT/'PREDICTIONS_LOCKED.json').read_text());freeze=json.loads((ROOT/'FREEZE.json').read_text())
    pct=lambda x:f'{100*x:.4f}%'
    interval=lambda x:'['+', '.join(pct(t) for t in x)+']'
    lines=[
    'WitnessCell：Jurkat 保留细胞环境确认结果',
    '日期：2026-10-18',
    '',
    '主要结论',
    f'主要方法秩一模型相对 M0 的留出误差降低 {pct(r["gain_pooled"])}；两次重复分别降低 {pct(r["gain_each"][0])}、{pct(r["gain_each"][1])}。',
    f'次要比较谱收缩矩阵降低 {pct(m["gain_pooled"])}；两次重复分别降低 {pct(m["gain_each"][0])}、{pct(m["gain_each"][1])}。',
    '秩一满足冻结前确定的方向复现条件，并得到本次条件性重加权区间支持。次要方法没有替代主要方法判定。',
    '',
    '用大白话说',
    '我们把在 K562 中开发好的做题方法固定下来，换到 Jurkat 细胞重新学习。先给它一部分双扰动的测量，再让它预测没有见过的双扰动组合。伙伴修正确实帮助它答得更准，而且两份重复测量都受益。',
    '这说明，超出本轮既定端点与非线性基线的可用预测信息，并非只在 K562 开发面板出现。结果支持这一冻结流程在另一细胞环境中重新训练后的有效性。',
    '',
    '数据与信息边界',
    f'79 个基因，3,081 个合格非自配对；2,464 对用于训练，617 对一次性留出评价；每个组合两次重复，共1,234个测量值，独立基因对数量仍是617。',
    '同一基因对的所有 guide 配对、方向与两次重复共同划分。单扰动测量为允许信息。所有模型共用训练组合和单扰动。',
    '数据为 GSE116198 作者发布的增长表型 gamma，取 Jurkat / Triple Sequencing / Replicate 1、2；不使用全图拟合的 GI 分数。',
    '按原 K562 规则先平均同一 physical guide pair 的方向，再平均不同 physical guide pairs。未新增作者 Jurkat 专用的效应量筛选。',
    '原80基因方案先因GINS4两次重复的单扰动均缺失停止；保存原冻结快照后，仅按缺失性去掉GINS4，未换入别的基因。79基因修订在任何Jurkat拟合、组合结果检视和测试评分之前完成。其余3,081对全部可用。',
    '本地程序先聚合并封存测试真值，再由只读取训练标签与无标签测试身份的程序训练；不等同于独立第三方掌管的盲法。',
    '',
    '冻结流程',
    'M0固定alpha=10；两次重复分别拟合，按单扰动标准差缩放并还原原单位。伙伴矩阵G在原单位下共用于两次重复。',
    '秩一和谱矩阵采用同一函数层面核范数与Frobenius惩罚。tau/tau_zero={0.3,0.1,0.03,0.01}，nu={0.1,1.0}；允许G=0回退。',
    '三折内部验证只用训练组合，评价完整M0+G的原单位误差。最终两种模型都选择tau/tau_zero=0.3、nu=0.1；这里选中参数来自Jurkat训练内部，选参规则没有改变。',
    f'修订冻结时间（UTC）：{freeze["utc_frozen"]}；预测锁定时间：{lock["utc"]}；揭盲评分时间：{s["utc_scored"]}。',
    f'正式拟合耗时约{lock["seconds"]:.2f}秒（已有CPU环境，单线程BLAS）；这不包括原始数据流式聚合、复核和整理时间。48/48内部候选拟合通过数值标准，24/24目标函数顺序检查通过，两个最终拟合通过。',
    '本轮模型核心代码与K562完成版逐字相同。没有根据Jurkat评价结果改模型、扩大网格或重抽测试集。',
    '',
    '主要数值（原始增长表型均方误差）',
    '模型\t合并MSE\t相对M0改善\t重复1改善\t重复2改善\t去端点误差改善',
    ]
    for label,key in [('M0','M0'),('M0重复预测平均参考','M0_repeat_mean'),('秩一（主要）','rank1_selected'),('谱收缩（次要）','spectral_selected')]:
        row=rows[key];lines.append('\t'.join([label,f'{row["mse_pooled"]:.12g}',pct(row['gain_pooled']),pct(row['gain_each'][0]),pct(row['gain_each'][1]),pct(row['projected_gain_pooled'])]))
    lines += ['',
    '误差改善的稳定性',
    f'秩一的基因组成重加权名义95%敏感性区间：{interval(r["node_reweighting_95_interval"])}。',
    f'谱矩阵相同区间：{interval(m["node_reweighting_95_interval"])}。',
    '使用79节点多项式重抽10,000次；每条边的权重为两个端点次数的乘积，两次重复一起计分。所有方法使用相同权重。',
    '这些区间仅描述固定模型、当前测量下对基因组成重加权的敏感性；其覆盖率未做本任务零校准，不包括重新训练/选模、共同批次误差或跨研究变异，不能当作所有未来实验的保证。',
    f'分别去掉每一个基因关联的测试边：秩一79/79次仍改善，最小改善{pct(r["delete_one_gene_min"])}；谱矩阵79/79次仍改善，最小改善{pct(m["delete_one_gene_min"])}。这说明结果不依赖某一个基因，但不是“每个基因均被预测准确”的证明。',
    '',
    '收益来源与边界',
    f'测试图有538维可消去自由端点效应的对比空间。消去端点后，秩一误差仍下降{pct(r["projected_gain_pooled"])}，谱矩阵下降{pct(m["projected_gain_pooled"])}。因此改善不能全部归于新增的自由端点校正。',
    '这里评价的是相对既定M0的可预测增量，不能仅凭此认定每项修正都是生物学遗传互作，也不能证明真实伙伴结构严格秩一。',
    f'谱矩阵原始误差改善比秩一多{100*(m["gain_pooled"]-r["gain_pooled"]):.4f}个百分点；这是次要比较的点估计，不能替代预定主要方法，也未设立其优于秩一的独立确认检验。',
    f'直接平均两次M0预测使误差增加{pct(-avg["gain_pooled"])}；本轮的伙伴收益超过了这个简单预测平均参考，但该参考不是所有可能的重复汇集方法。',
    'Jurkat与K562属于同一原始研究；本轮是保留细胞环境的流程确认，不是独立研究复现。参数在Jurkat训练侧重新估计，因此也不是K562参数的直接迁移。',
    '本轮为高覆盖条件，约80%组合已用于训练；不能据此宣称只需几十个组合、已确定密度阈值或已证明O(n)测量需求。',
    '本轮不验证RNA预测、湿实验前瞻表现或75%命中率。旧OSF注册采用不同的早期模型，本次保存新的本地冻结与可用性修订，不声称它已由旧注册覆盖。',
    '',
    '复算与附件',
    '代码、处理后训练/测试数据、每个候选的内部验证预测、最终模型、617对逐组合预测、10,000次重加权数组、两个独立核对脚本与报告均在结果ZIP。',
    'verify_confirmation.py独立检查冻结链、模型正规方程/预测/选择、评分和区间；verify_source.py独立从原始表型重聚合并核对输入。',
    '独立数值复核完成1,092项检查；独立从原始表型重聚合的训练、测试和单扰动数组逐元素一致，最大差为0。\n原始约107MiB表型gzip沿用已保存的WitnessCell_Horlbeck_Freeze_v1包；为避免重复，结果ZIP不重复放入该完整gzip，INPUT_PROVENANCE.json记录精确SHA-256。模型结果可仅用包内处理后数据重现。',
    '复现：python3 reproduce.py --out /一个不存在的新目录/jurkat_reproduction',
    '重新核对来源：python3 verify_source.py --help（按脚本入口说明定位原始冻结包）。',
    '历史v1方案中“80 endpoints”文字在可用性修订后未追改；实际冻结n_fixed=79、节点计算及报告均按79执行，独立核对已记录这项文档残留。',
    '',
    '公开来源',
    'Horlbeck et al. 2018: https://pmc.ncbi.nlm.nih.gov/articles/PMC6426455/',
    'GEO GSE116198: https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE116198',
    '作者处理代码: https://github.com/mhorlbeck/GImap_tools/blob/master/GImap_analysis.py',
    ]
    (ROOT/(NAME+'.txt')).write_text('\n'.join(lines)+'\n',encoding='utf-8')
    plt.rcParams.update({'font.size':11,'axes.spines.top':False,'axes.spines.right':False})
    fig,ax=plt.subplots(1,2,figsize=(11.5,4.8),gridspec_kw={'width_ratios':[1,1.25]})
    colors=['#146c94','#e49436'];labels=['Rank 1 (primary)','Spectral (secondary)'];data=[r,m]
    means=[100*x['gain_pooled'] for x in data]
    errors=np.array([[100*(x['gain_pooled']-x['node_reweighting_95_interval'][0]) for x in data],[100*(x['node_reweighting_95_interval'][1]-x['gain_pooled']) for x in data]])
    ax[0].bar(np.arange(2),means,color=colors,width=.6,yerr=errors,capsize=5)
    ax[0].set_xticks(np.arange(2),labels);ax[0].set_ylabel('Error reduction versus M0 (%)');ax[0].set_title('Held-out growth predictions')
    ax[0].set_ylim(0,max(means+list(np.max(errors,axis=0)))+8)
    for i,y in enumerate(means):ax[0].text(i,y+.25,f'{y:.2f}%',ha='center',va='bottom',fontweight='bold')
    x=np.arange(3);width=.33
    for i,(row,col,label) in enumerate(zip(data,colors,labels)):
        vals=100*np.array([*row['gain_each'],row['projected_gain_pooled']]);bars=ax[1].bar(x+(i-.5)*width,vals,width,color=col,label=label)
        ax[1].bar_label(bars,labels=[f'{q:.2f}' for q in vals],padding=3,fontsize=9)
    ax[1].set_xticks(x,['Repeat 1','Repeat 2','Endpoint-removed']);ax[1].set_ylabel('Error reduction versus M0 (%)');ax[1].set_ylim(0,12);ax[1].set_title('Both repeats and non-additive contrasts');ax[1].legend(frameon=False,loc='upper left')
    fig.suptitle('WitnessCell: frozen-workflow Jurkat confirmation',fontsize=16,fontweight='bold')
    fig.text(.5,.035,'79 genes | 2,464 training pairs | 617 held-out pairs | 2 repeats\nError bars: conditional gene-reweighting sensitivity intervals; same-study held environment.',ha='center',fontsize=10)
    fig.tight_layout(rect=(0,.12,1,.92));fig.savefig(ROOT/(NAME+'.png'),dpi=180);plt.close(fig)
    with np.load(ROOT/'results/evaluation_predictions.npz',allow_pickle=False) as z:
        with (ROOT/'results/per_pair_predictions.tsv').open('w',newline='') as f:
            w=csv.writer(f,delimiter='\t');w.writerow(['gene_pair','replicate','observed','M0','rank1','spectral','M0_repeat_mean'])
            for i,gid in enumerate(z['ids']):
                for t in range(2):w.writerow([gid,t+1,*[float(z[k][i,t]) for k in ('y','M0','rank1_selected','spectral_selected','M0_repeat_mean')]])
    print(json.dumps({'report':NAME+'.txt','figure':NAME+'.png'}))
if __name__=='__main__':main()
