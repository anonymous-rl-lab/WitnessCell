"""Prepare registered K562 panel without exposing response summaries.

Only K562 / Triple Sequencing / Replicate 1 and Replicate 2 strings are
converted to numbers. Jurkat, alternative sequencing methods and replicate
averages remain unparsed strings discarded during streaming.
"""
from __future__ import annotations
import argparse, collections, csv, gzip, hashlib, json, math, pathlib
from datetime import datetime, timezone
import numpy as np

PREFIX='WC_HORLBECK_OSF_V1_20261018'
ANNOTATION='GSE116198_GImap_sgRNA_sequences_barcodes.txt.gz'
PHENOTYPES='GSE116198_sgRNA_pair_phenotypes.txt.gz'
EXPECTED={ANNOTATION:'84a785108a5bf830ce2ee569e14757fe5c31738ba6d88c95206f38a0b1bbc150',PHENOTYPES:'ba9772f3b0e929bcf5b23bebf17d4caab86c7f2ccd50dbd62fbc47e40c2aac21'}

def hash_file(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()

def gene_order_key(g):
 return hashlib.sha256(f'{PREFIX}|genes|{g}'.encode('utf-8')).hexdigest(),g

def read_annotation(path):
 mapping={}; invalid=set(); counts=collections.Counter()
 with gzip.open(path,'rt',encoding='utf-8',newline='') as f:
  for row in csv.reader(f,delimiter='\t'):
   if len(row)!=9: raise ValueError('Unexpected source annotation width')
   guide=row[1].strip()
   # Matches source GImap_analysis.py generatePhenotypeMatrix, line52.
   gene=guide.split('_')[0].strip()
   if not guide or not gene or row[2].strip()!=guide:
    invalid.add(guide);counts['ambiguous_annotation']+=1;continue
   # The archived annotation has a constant Y field; its biological
   # meaning is not inferred. Unexpected values require metadata review.
   if row[3].strip()!='Y':
    raise ValueError('Unexpected source annotation field3; mapping requires review')
   if guide in mapping and mapping[guide]!=gene:
    invalid.add(guide);counts['conflicting_annotation']+=1
   mapping[guide]=gene;counts['annotation_rows']+=1
 for guide in invalid:mapping.pop(guide,None)
 counts['unique_valid_guides']=len(mapping)
 counts['non_targeting_guides']=sum(v=='negative' for v in mapping.values())
 return mapping,dict(counts)

def header_columns(reader):
 head=[next(reader) for _ in range(3)]
 if len(set(map(len,head)))!=1:raise ValueError('Inconsistent source headers')
 labels=[tuple(head[k][j].strip() for k in range(3)) for j in range(len(head[0]))]
 expected=[('K562','Triple Sequencing','Replicate 1'),('K562','Triple Sequencing','Replicate 2')]
 columns=[]
 for label in expected:
  found=[j for j,x in enumerate(labels) if x==label]
  if len(found)!=1:raise ValueError('Required repeat-specific gamma column unresolved')
  columns.append(found[0])
 return columns,labels

def finite_float(s):
 try: v=float(s)
 except (ValueError,TypeError):return None
 return v if math.isfinite(v) else None

def collect_physical_pairs(path,mapping,mode,panel=None):
 """Dictionary physicalguidepair->orientedmeasurements, then symmetrize.

Technical duplicate rows with exactly equal values are ignored; conflicting
repeat measurements for an identical orientation stop preparation.
 """
 physical={};counts=collections.Counter(); labels=None
 with gzip.open(path,'rt',encoding='utf-8',newline='') as f:
  reader=csv.reader(f,delimiter='\t');columns,labels=header_columns(reader)
  for row in reader:
   if not row or not row[0].strip():counts['blank_rows']+=1;continue
   counts['source_data_rows']+=1
   names=row[0].strip().split('++')
   if len(names)!=2:raise ValueError('Pair identifier does not contain exactly two guides')
   ga,gb=names
   if ga not in mapping or gb not in mapping:counts['unmapped_or_invalid_rows']+=1;continue
   a,b=mapping[ga],mapping[gb]
   if mode=='singles':
    wanted=(a=='negative') != (b=='negative')
   elif mode=='combinations':
    wanted=a in panel and b in panel and a!=b
   else:raise ValueError(mode)
   if not wanted:continue
   counts['selected_source_rows']+=1
   if len(row)!=len(labels):raise ValueError('Unexpected phenotype row width')
   values=tuple(finite_float(row[c]) for c in columns)
   counts['missing_nonfinite_replicate_records']+=sum(v is None for v in values)
   key=tuple(sorted((ga,gb)))
   orientation=(ga,gb)
   oriented=physical.setdefault(key,{})
   if orientation in oriented:
    counts['duplicate_oriented_rows']+=1
    if oriented[orientation]!=values:raise ValueError('Conflicting repeated orientation; no silent averaging')
   else:oriented[orientation]=values
 # Each physical guide pair first receives equal-weight AB/BA averaging.
 by_gene=collections.defaultdict(lambda:[[],[]])
 physical_counts=collections.defaultdict(lambda:[0,0])
 for (ga,gb),oriented in physical.items():
  a,b=mapping[ga],mapping[gb]
  key=(b if a=='negative' else a) if mode=='singles' else tuple(sorted((a,b)))
  for t in range(2):
   vals=[v[t] for v in oriented.values() if v[t] is not None]
   if vals:
    by_gene[key][t].append(sum(vals)/len(vals));physical_counts[key][t]+=1
 counts['physical_guide_pairs']=len(physical)
 # Distinct physical-guidepair estimates have equal weight at gene level.
 means={key:[(sum(vals)/len(vals) if vals else None) for vals in reps] for key,reps in by_gene.items()}
 return means,physical_counts,dict(counts),labels

def prepare(raw_dir,out_dir):
 raw_dir=pathlib.Path(raw_dir);out_dir=pathlib.Path(out_dir);out_dir.mkdir(parents=True,exist_ok=True)
 raw_files=[]
 for name,expected in EXPECTED.items():
  p=raw_dir/name;sha=hash_file(p)
  if sha!=expected:raise ValueError('Raw asset SHA-256 mismatch: '+name)
  raw_files.append({'name':name,'bytes':p.stat().st_size,'sha256':sha})
 mapping,annotation_counts=read_annotation(raw_dir/ANNOTATION)
 single_values,single_counts,scounts,labels=collect_physical_pairs(raw_dir/PHENOTYPES,mapping,'singles')
 eligible=sorted([g for g,v in single_values.items() if all(x is not None for x in v)],key=gene_order_key)
 genes=eligible[:80]
 if not genes:raise ValueError('No eligible genes with both single replicates')
 gene_index={g:i for i,g in enumerate(genes)}
 pair_values,pair_counts,pcounts,_=collect_physical_pairs(raw_dir/PHENOTYPES,mapping,'combinations',set(genes))
 pairs=sorted(q for q,v in pair_values.items() if all(x is not None for x in v))
 if not pairs:raise ValueError('No shared combination pairs')
 singles=np.asarray([single_values[g] for g in genes],dtype=np.float64)
 edges=np.asarray([[gene_index[g],gene_index[h]] for g,h in pairs],dtype=np.int64)
 responses=np.asarray([pair_values[q] for q in pairs],dtype=np.float64)
 np.savez_compressed(out_dir/'panel.npz',genes=np.asarray(genes,dtype=str),singles=singles,edges=edges,responses=responses,
  single_guide_pair_counts=np.asarray([single_counts[g] for g in genes],dtype=np.int64),
  combination_guide_pair_counts=np.asarray([pair_counts[q] for q in pairs],dtype=np.int64),
  replicates=np.asarray(['K562 Replicate 1','K562 Replicate 2'],dtype=str))
 with (out_dir/'eligible_genes.tsv').open('w',encoding='utf-8',newline='') as f:
  writer=csv.writer(f,delimiter='\t');writer.writerow(['gene','hash_rank','selected'])
  writer.writerows((g,i+1,int(i<80)) for i,g in enumerate(eligible))
 metadata={
  'prepared_utc':datetime.now(timezone.utc).isoformat(),
  'access_status':'Source files downloaded and K562 required values computationally aggregated before registration; no response summaries, model fits, performance or Jurkat numeric columns inspected.',
  'raw_files':raw_files,'source_headers':labels,
  'numeric_columns':[{'zero_based_column':13,'cell_line':'K562','method':'Triple Sequencing','replicate':'Replicate 1'}, {'zero_based_column':14,'cell_line':'K562','method':'Triple Sequencing','replicate':'Replicate 2'}],
  'excluded_measurement_methods':['Barcode Sequencing','sgRNA Sequencing','Replicate average'],
  'method_reason':'Triple sequencing is the original study primary analysis removing mismatched guide/barcode recombination. K562 T0 was barcode-only; the source authors supplied normalized gamma. No choice used numeric comparison.',
  'annotation_mapping':'Headerless source map field1 guide identifier; derive gene as guide.split("_")[0], matching source GImap_analysis.py; negative_control-* maps negative. Map field3 is constant Y in this source and is checked only as a schema guard; field2 must match guide.',
  'aggregation':'Average available AB/BA orientations within the same physical guide pair, separately by replicate; then equal-weight mean of distinct physical guide pairs at each unordered gene pair. Singles analogously from target+negative_control physical pairs.',
  'counts':{'annotation':annotation_counts,'singles_pass':scounts,'combinations_pass':pcounts,'eligible_genes':len(eligible),'selected_genes':len(genes),'eligible_pairs':len(pairs),'pairs_missing_either_repeat':len(pair_values)-len(pairs),'max_distinct_gene_pairs':len(genes)*(len(genes)-1)//2},
  'outcome_summaries_generated':False,'jurkat_numeric_values_imported':False,
  'panel_arrays':{'genes':list(np.asarray(genes).shape),'singles':list(singles.shape),'edges':list(edges.shape),'responses':list(responses.shape)},
  'notes':['No full-map GI scores used.','No full-map mean, variance, correlation, fitting or rank analysis computed.','No separate per-row phenotype quality flag exists in this table; source-supplied missing/nonfinite values are excluded. Constant annotation field Y is not interpreted as a biological quality score.','No readcount thresholds added; missing/nonfinite gamma excluded per replicate.','Raw archive contains Jurkat bytes; these are preserved for provenance but excluded from numeric preparation.']}
 (out_dir/'preparation_metadata.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
 print(json.dumps({'stage':'assets_prepared','genes':len(genes),'pairs':len(pairs),'replicates':2,'outcome_summaries_generated':False}))
 return metadata

def main():
 ap=argparse.ArgumentParser(description=__doc__)
 root=pathlib.Path(__file__).resolve().parents[2]
 ap.add_argument('--raw-dir',type=pathlib.Path,default=root/'data/raw')
 ap.add_argument('--out-dir',type=pathlib.Path,default=root/'data/prepared')
 args=ap.parse_args();prepare(args.raw_dir,args.out_dir)
if __name__=='__main__':main()
