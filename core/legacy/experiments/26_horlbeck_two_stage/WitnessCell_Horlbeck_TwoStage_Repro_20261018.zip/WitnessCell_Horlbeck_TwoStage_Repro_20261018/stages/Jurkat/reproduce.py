"""Reproduce fits from prepared inputs in a new directory; never overwrite confirmation."""
import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
from pathlib import Path
import argparse,shutil,subprocess,sys,json
import numpy as np
ROOT=Path(__file__).resolve().parent
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--out',type=Path,required=True);args=ap.parse_args()
    target=args.out.resolve()
    if target.exists():raise RuntimeError('Use a new output directory')
    target.mkdir(parents=True)
    freeze=json.loads((ROOT/'FREEZE.json').read_text())
    for name in list(freeze['files'])+['FREEZE.json','INPUT_PROVENANCE.json']:
        p=target/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(ROOT/name,p)
    for folder in ('inputs','sealed'):shutil.copytree(ROOT/folder,target/folder,dirs_exist_ok=True)
    (target/'results/high/inner_models').mkdir(parents=True)
    for script in ('run_confirmation.py','score_confirmation.py'):
        with (target/(script+'.log')).open('w') as out:subprocess.run([sys.executable,str(target/script)],cwd=target,stdout=out,stderr=subprocess.STDOUT,check=True)
    original=json.loads((ROOT/'SUMMARY.json').read_text());repeated=json.loads((target/'SUMMARY.json').read_text())
    differences={k:abs(v['mse_pooled']-repeated['models'][k]['mse_pooled']) for k,v in original['models'].items()}
    print(json.dumps({'maximum_mse_difference':max(differences.values()),'by_model':differences,'output':str(target)},indent=2))
if __name__=='__main__':main()
