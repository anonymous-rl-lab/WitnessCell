"""Train frozen workflow without opening sealed query labels."""
import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
from pathlib import Path
import sys,json,hashlib,time,datetime
import numpy as np
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'core'))
import run_smoke as frozen
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    plan=json.loads((ROOT/'PLAN.json').read_text());freeze=json.loads((ROOT/'FREEZE.json').read_text())
    for f,h in freeze['files'].items():assert sha(ROOT/f)==h, f
    prov=json.loads((ROOT/'INPUT_PROVENANCE.json').read_text())
    for f in ('inputs/training.npz','inputs/query.npz'):assert sha(ROOT/f)==prov['file_sha256'][f]
    with np.load(ROOT/'inputs/training.npz',allow_pickle=False) as z:data={k:z[k] for k in z.files}
    with np.load(ROOT/'inputs/query.npz',allow_pickle=False) as z:edges=z['edges'];ids=z['global_ids'];assert 'y' not in z.files
    assert not set(ids)&set(data['global_ids'])
    frozen.ROOT=ROOT
    start=time.monotonic()
    frozen.run_budget('high',data,edges,ids,plan,start+plan['real_fit_budget_seconds'])
    files=list((ROOT/'results/high').rglob('*'))
    frozen.dump(ROOT/'PREDICTIONS_LOCKED.json',{'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'evaluation_truth_opened_by_trainer':False,
        'freeze_sha256':sha(ROOT/'FREEZE.json'),'input_provenance_sha256':sha(ROOT/'INPUT_PROVENANCE.json'),
        'files':{str(p.relative_to(ROOT)):sha(p) for p in files if p.is_file()},'seconds':time.monotonic()-start})
    print('PREDICTIONS_LOCKED; held-out truth not scored')
if __name__=='__main__':main()
