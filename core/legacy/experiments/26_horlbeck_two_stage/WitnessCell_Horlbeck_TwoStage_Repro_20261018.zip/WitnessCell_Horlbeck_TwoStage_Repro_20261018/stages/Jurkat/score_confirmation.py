"""Reveal and score only after frozen predictions exist. No refitting."""
import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
from pathlib import Path
import json,hashlib,datetime
import numpy as np
ROOT=Path(__file__).resolve().parent
METHODS=('M0','M0_repeat_mean','rank1_selected','spectral_selected')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def npz(p):
    with np.load(p,allow_pickle=False) as z:return {k:z[k] for k in z.files}
def main():
    plan=json.loads((ROOT/'PLAN.json').read_text());freeze=json.loads((ROOT/'FREEZE.json').read_text());lock=json.loads((ROOT/'PREDICTIONS_LOCKED.json').read_text());prov=json.loads((ROOT/'INPUT_PROVENANCE.json').read_text())
    assert sha(ROOT/'FREEZE.json')==lock['freeze_sha256']
    assert sha(ROOT/'INPUT_PROVENANCE.json')==lock['input_provenance_sha256']
    for f,h in freeze['files'].items():assert sha(ROOT/f)==h, f
    for f,h in lock['files'].items():assert sha(ROOT/f)==h, f
    assert sha(ROOT/'sealed/evaluation_truth.npz')==prov['file_sha256']['sealed/evaluation_truth.npz']
    p=npz(ROOT/'results/high/predictions.npz');truth=npz(ROOT/'sealed/evaluation_truth.npz');train=npz(ROOT/'inputs/training.npz')
    for key in ('edges','global_ids'):assert np.array_equal(p[key],truth[key])
    y=truth['y'];edges=truth['edges'];n=len(train['genes']);m=len(edges)
    X=np.zeros((m,n));X[np.arange(m),edges[:,0]]=1;X[np.arange(m),edges[:,1]]=1
    U,s,_=np.linalg.svd(X,full_matrices=False);rank=int(np.sum(s>max(X.shape)*np.finfo(float).eps*s[0]));Q=U[:,:rank]
    def project(v):return v-Q@(Q.T@v)
    base=(y-p['M0'])**2;base_sum=base.sum(axis=0);pbase=(project(y-p['M0'])**2).sum(axis=0)
    rows={};loss={}
    for name in METHODS:
        loss[name]=(y-p[name])**2;ss=loss[name].sum(axis=0);ps=(project(y-p[name])**2).sum(axis=0)
        gains=[]
        for g in range(n):
            keep=np.all(edges!=g,axis=1);gains.append(float(1-loss[name][keep].sum()/base[keep].sum()))
        rows[name]={'sse_each':ss.tolist(),'mse_each':(ss/m).tolist(),'mse_pooled':float(ss.sum()/(2*m)),
            'gain_each':(1-ss/base_sum).tolist(),'gain_pooled':float(1-ss.sum()/base_sum.sum()),
            'projected_sse_each':ps.tolist(),'projected_gain_each':(1-ps/pbase).tolist(),'projected_gain_pooled':float(1-ps.sum()/pbase.sum()),
            'delete_one_gene_gain':gains,'delete_one_gene_min':min(gains),'delete_one_gene_positive':sum(g>0 for g in gains)}
    spec=plan['uncertainty'];rng=np.random.default_rng(spec['seed']);draws={k:[] for k in METHODS};tries=0
    while len(draws['M0'])<spec['draws'] and tries<spec['max_attempts']:
        tries+=1;freq=rng.multinomial(n,np.repeat(1/n,n));w=freq[edges[:,0]]*freq[edges[:,1]];den=float(w@base.sum(axis=1))
        if den<=0:continue
        for k in METHODS:draws[k].append(float(1-(w@loss[k].sum(axis=1))/den))
    assert len(draws['M0'])==spec['draws']
    for k in METHODS:rows[k]['node_reweighting_95_interval']=np.quantile(draws[k],spec['quantiles']).tolist()
    avg_sse=float(loss['M0_repeat_mean'].sum())
    for k in METHODS:rows[k]['gain_vs_repeat_mean']=float(1-loss[k].sum()/avg_sse)
    primary=rows['rank1_selected'];direction=primary['gain_pooled']>0 and all(v>0 for v in primary['gain_each'])
    supported=direction and primary['node_reweighting_95_interval'][0]>0
    inner=json.loads((ROOT/'results/high/inner_summary.json').read_text());selection=json.loads((ROOT/'results/high/selection.json').read_text())
    result={'utc_scored':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':plan['purpose'],'n_genes':n,'n_train':len(train['edges']),'n_test':m,'n_repeat_measurements':m*2,'test_contrast_dimension':m-rank,
        'models':rows,'selection':selection,'primary_decision':{'direction_replication':bool(direction),'conditional_interval_support':bool(supported),'primary':'rank1_selected','secondary_cannot_rescue_primary':True},
        'interval_note':spec['label'],'bootstrap_draws':spec['draws'],'bootstrap_attempts':tries,
        'checks':{'inner_fits':sum(len(x['diagnostics']) for x in inner['grid']),'inner_converged':sum(int(d['converged']) for x in inner['grid'] for d in x['diagnostics']),'objective_probes_passed':sum(int(x['pass']) for x in inner['objective_probes']),'final_selected_converged':all(v['final_converged'] for v in selection.values()),'predictions_locked_before_scoring':True}}
    (ROOT/'SUMMARY.json').write_text(json.dumps(result,indent=2,allow_nan=False))
    np.savez_compressed(ROOT/'results/node_reweighting_draws.npz',**{k:np.array(v) for k,v in draws.items()})
    np.savez_compressed(ROOT/'results/evaluation_predictions.npz',genes=train['genes'],edges=edges,ids=truth['global_ids'],y=y,**{k:p[k] for k in METHODS})
    print(json.dumps({k:result[k] for k in ('n_train','n_test','models','primary_decision','checks')},indent=2))
if __name__=='__main__':main()
