"""Independent post-score verification of Jurkat confirmation.

Does not import the fitting/scoring code or fit any new model. Reconstructs
saved predictions and objectives from equations, checks CV selection and
within-fold projection, and writes only INDEPENDENT_CHECK.json.
"""
import os
for _key in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS'):
    os.environ[_key] = '1'
from pathlib import Path
import hashlib
import json
import datetime
import zipfile
import numpy as np

ROOT = Path(__file__).resolve().parent
METHODS = ('M0', 'M0_repeat_mean', 'rank1_selected', 'spectral_selected')
failures = []
counts = {}
maximum = {}

def check(condition, label):
    counts['assertions'] = counts.get('assertions', 0) + 1
    if not bool(condition):
        failures.append(label)

def close(actual, expected, label, tolerance=1e-10):
    actual, expected = np.asarray(actual), np.asarray(expected)
    if actual.shape != expected.shape:
        check(False, label + ': shape mismatch')
        return
    err = float(np.max(np.abs(actual-expected))) if actual.size else 0.
    maximum[label.split(':')[0]] = max(maximum.get(label.split(':')[0], 0.), err)
    check(np.isfinite(err) and err <= tolerance, label)

def read(path):
    return json.loads(path.read_text())

def npz(path):
    with np.load(path, allow_pickle=False) as z:
        return {key: z[key] for key in z.files}

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def base_prediction(models, edges, singles):
    """Independent scalar formula, with stored original scaling convention."""
    scales = np.std(singles, axis=0)
    scales[scales == 0] = 1.
    i, j = edges.T
    predictions = []
    for t, model in enumerate(models):
        a = np.asarray(model['a'])
        e, db, dc = [np.asarray(model[key]) for key in ('e', 'd_beta', 'd_c')]
        check(model['rank'] == 0 and model['alpha'] == 10., 'M0 fixed rule')
        close(a, singles[:, t]/scales[t], 'M0 units')
        ag, ah = a[i], a[j]
        y = (model['e0'] + e[i] + e[j] + .5*(ag+ah)
             + .5*((model['beta']+db[i])*ah + (model['beta']+db[j])*ag)
             + .5*((model['c']+dc[i])*ah**2 + (model['c']+dc[j])*ag**2))
        predictions.append(y*scales[t])
    return np.column_stack(predictions)

def objective(G, edges, residual, tau, nu):
    n = len(G)
    r = residual.mean(axis=1)
    return (float(np.mean((r-G[edges[:, 0], edges[:, 1]])**2))
            + tau/n*np.abs(np.linalg.eigvalsh(G)).sum()
            + nu/n**2*np.sum(G**2))

def loss_gradient(G, edges, r, nu):
    g = (2*nu/len(G)**2)*G
    i, j = edges.T
    error = (G[i, j]-r)/len(edges)
    g[i, j] += error
    g[j, i] += error
    return g

def model_check(G, details, edges, residual, family, tau, nu):
    n = len(G)
    close(G, G.T, 'matrix symmetry', 1e-11)
    check(np.isfinite(G).all(), 'finite matrix')
    obj = objective(G, edges, residual, tau, nu)
    close(obj, details['objective'], 'objective reconstruction', 1e-11)
    check(details['converged'] and not details['timed_out'], 'saved convergence')
    check(details['stationarity_relative'] <= 1.00001e-6, 'reported stationarity')
    r = residual.mean(axis=1)
    if family == 'rank1':
        u = np.asarray(details['u'])
        lam = details['lambda']
        close(G, lam*np.outer(u, u), 'rank1 reconstruction', 1e-11)
        close(np.linalg.norm(u), 1., 'rank1 normalization', 1e-10)
        gu = 2*lam*(loss_gradient(G, edges, r, 0.)@u)
        tangent = gu-u*np.dot(u, gu)
        rel = float(np.max(np.abs(tangent))/max(np.mean(r*r), 1e-12))
        maximum['rank1 independent relative gradient'] = max(maximum.get('rank1 independent relative gradient', 0.), rel)
        check(rel <= 1.02e-6, 'rank1 independent tangent gradient')
        prod = u[edges[:, 0]]*u[edges[:, 1]]
        numerator = float(np.mean(r*prod))
        expected_lambda = np.sign(numerator)*max(abs(numerator)-tau/(2*n), 0.)/(float(np.mean(prod**2))+nu/n**2)
        close(lam, expected_lambda, 'rank1 strength optimum', 1e-8)
    else:
        step = 1./(1./len(edges)+2*nu/n**2)
        z = G-step*loss_gradient(G, edges, r, nu)
        vals, vecs = np.linalg.eigh((z+z.T)/2)
        shrunk = np.sign(vals)*np.maximum(np.abs(vals)-step*tau/n, 0.)
        prox = (vecs*shrunk)@vecs.T
        denom = max(float(np.linalg.norm(loss_gradient(np.zeros_like(G), edges, r, 0.))), 1e-12)
        rel = float(np.linalg.norm(G-prox)/(step*denom))
        maximum['spectral independent relative proximal gradient'] = max(maximum.get('spectral independent relative proximal gradient', 0.), rel)
        check(rel <= 1.02e-6, 'spectral independent proximal stationarity')
        close(np.linalg.eigvalsh(G), details['eigenvalues'], 'saved eigenvalues', 1e-10)
    return obj

def correct(G, train_edges, query_edges):
    supported = np.bincount(train_edges.ravel(), minlength=len(G)) > 0
    i, j = query_edges.T
    return np.where(supported[i] & supported[j], G[i, j], 0.)

def identical(actual, expected, label):
    check(np.array_equal(np.asarray(actual), np.asarray(expected)), label)

def baseline_optimality(models, edges, y, singles):
    """Rebuild allowed-data ridge normal equations without invoking a fitter."""
    support = np.unique(edges)
    size = len(support)
    H = np.zeros((size, max(0, size-1)))
    for j in range(size-1):
        d = np.sqrt((j+1)*(j+2))
        H[:j+1, j] = 1/d
        H[j+1, j] = -(j+1)/d
    local = np.full(len(singles), -1, dtype=int)
    local[support] = np.arange(size)
    gi, hi = local[edges].T
    bg, bh = H[gi], H[hi]
    scales = np.std(singles, axis=0)
    scales[scales == 0] = 1.
    for t, model in enumerate(models):
        identical(model['supported'], support, 'M0 supported training endpoints')
        a = singles[:, t]/scales[t]
        ag, ah = a[edges[:, 0]], a[edges[:, 1]]
        X = np.column_stack((np.ones(len(edges)), .5*(ag+ah),
                             .5*(ag*ag+ah*ah), bg+bh,
                             .5*(bg*ah[:, None]+bh*ag[:, None]),
                             .5*(bg*ah[:, None]**2+bh*ag[:, None]**2)))
        coef = np.concatenate(([model['e0'], model['beta'], model['c']],
                 *[H.T@np.asarray(model[k])[support] for k in ('e', 'd_beta', 'd_c')]))
        penalty = np.zeros(len(coef)); penalty[3:] = 10./size
        residual = .5*(ag+ah)+X@coef-y[:, t]/scales[t]
        grad = 2*X.T@residual/len(edges)+2*penalty*coef
        gmax = float(np.max(np.abs(grad)))
        maximum['M0 independent normal-equation residual'] = max(
            maximum.get('M0 independent normal-equation residual', 0.), gmax)
        check(gmax < 1e-8, 'M0 stationary on allowed training labels')
        close(float(np.mean(residual**2)+penalty@(coef**2)),
              model['diagnostics']['objective'], 'M0 objective', 1e-10)
        for k in ('e', 'd_beta', 'd_c'):
            v = np.asarray(model[k])
            close(v[support].sum(), 0., 'M0 endpoint centering', 1e-10)
            unsupported = np.ones(len(v), dtype=bool); unsupported[support] = False
            close(v[unsupported], np.zeros(unsupported.sum()), 'M0 unsupported fallback', 0.)

def main():
    # Deliberately requires SUMMARY: this verifier must run only after scoring.
    summary = read(ROOT/'SUMMARY.json')
    plan, freeze = read(ROOT/'PLAN.json'), read(ROOT/'FREEZE.json')
    prov, lock = read(ROOT/'INPUT_PROVENANCE.json'), read(ROOT/'PREDICTIONS_LOCKED.json')
    for filename, value in freeze['files'].items():
        check(sha(ROOT/filename) == value, 'freeze hash: '+filename)
    for filename, value in plan['core_sha256'].items():
        check(sha(ROOT/'core'/filename) == value, 'K562 core unchanged: '+filename)
    for filename, value in prov['file_sha256'].items():
        check(sha(ROOT/filename) == value, 'prepared input hash: '+filename)
    for filename, value in lock['files'].items():
        check(sha(ROOT/filename) == value, 'prediction lock hash: '+filename)
    check(sha(ROOT/'FREEZE.json') == lock['freeze_sha256'], 'freeze chain')
    check(sha(ROOT/'INPUT_PROVENANCE.json') == lock['input_provenance_sha256'], 'input chain')
    times = [datetime.datetime.fromisoformat(v) for v in
             (freeze['utc_frozen'], prov['utc'], lock['utc'], summary['utc_scored'])]
    check(all(a <= b for a, b in zip(times, times[1:])), 'recorded freeze/prepare/lock/score order')
    check(lock['evaluation_truth_opened_by_trainer'] is False, 'trainer declared labels unopened')

    data = npz(ROOT/'inputs/training.npz')
    query = npz(ROOT/'inputs/query.npz')
    truth = npz(ROOT/'sealed/evaluation_truth.npz')
    frozen_genes = read(ROOT/'protocol/genes.json')
    identical(data['genes'], frozen_genes, 'fixed K562 gene panel')
    n = len(frozen_genes)
    check(n == plan['n_fixed'] == prov['n_genes'], 'availability-amended panel size')
    amendment = read(ROOT/'protocol/AVAILABILITY_AMENDMENT.json')
    original_genes = read(ROOT/'protocol/original_k562_80genes.json')
    identical(frozen_genes, [g for g in original_genes if g != 'GINS4'], 'only availability-missing GINS4 removed')
    check(len(original_genes) == 80 and n == 79, 'documented 80 to 79 availability amendment')
    with zipfile.ZipFile(ROOT/'protocol/v1_before_availability_amendment.zip') as z:
        old_freeze_bytes = z.read('FREEZE.json')
        old_freeze = json.loads(old_freeze_bytes)
        check(hashlib.sha256(old_freeze_bytes).hexdigest() == amendment['prior_freeze_sha256'], 'amendment links original freeze')
        for name, value in old_freeze['files'].items():
            check(hashlib.sha256(z.read(name)).hexdigest() == value, 'archived v1 freeze integrity '+name)
        identical(json.loads(z.read('protocol/genes.json')), original_genes, 'archived original 80 genes')
        for name in ('run_confirmation.py', 'score_confirmation.py', *['core/'+k for k in plan['core_sha256']]):
            check(z.read(name) == (ROOT/name).read_bytes(), 'amendment preserved model/selection/scoring '+name)
        old_plan = json.loads(z.read('PLAN.json'))
        for key in ('M0', 'partner', 'loss', 'tau_fractions', 'nu', 'tau_rule', 'zero_candidate',
                    'inner_folds', 'inner_assignment', 'selection', 'primary', 'secondary', 'decision',
                    'uncertainty', 'outer_split', 'optimizer_maxiter', 'optimizer_tolerance', 'core_sha256'):
            check(old_plan[key] == plan[key], 'amendment preserved protocol '+key)
        check(datetime.datetime.fromisoformat(old_freeze['utc_frozen']) <= datetime.datetime.fromisoformat(amendment['utc']) <= times[0],
              'original freeze precedes availability amendment and refreeze')
    check('y' not in query and set(query) == {'edges', 'global_ids'}, 'query contains identities only')
    for key in ('edges', 'global_ids'):
        identical(query[key], truth[key], 'query truth alignment '+key)
    edges, y = truth['edges'], truth['y']
    train_edges, train_y, folds = data['edges'], data['y'], data['inner_fold']
    check(train_y.shape == (len(train_edges), 2) and y.shape == (len(edges), 2), 'paired repeats')
    check(np.isfinite(train_y).all() and np.isfinite(y).all() and np.isfinite(data['singles']).all(), 'finite inputs')
    all_ids = list(map(str, data['global_ids']))+list(map(str, query['global_ids']))
    check(len(set(all_ids)) == len(all_ids), 'unique disjoint train/test IDs')
    all_edges = np.vstack((train_edges, edges))
    check(len({tuple(sorted(e)) for e in all_edges}) == len(all_edges), 'unique disjoint unordered pairs')
    check(np.all(all_edges[:, 0] != all_edges[:, 1]), 'no self-pairs')
    for es, ids in [(train_edges, data['global_ids']), (edges, query['global_ids'])]:
        expected = ['|'.join(sorted([str(data['genes'][i]), str(data['genes'][j])])) for i, j in es]
        identical(ids, expected, 'gene names define pair IDs')
    salt = plan['outer_split']['salt']
    ordered = sorted(all_ids, key=lambda s:(hashlib.sha256((salt+'|pair|'+s).encode()).hexdigest(), s))
    ntest = int(np.ceil(plan['outer_split']['test_fraction']*len(all_ids)))
    check(set(query['global_ids']) == set(ordered[:ntest]), 'outer hash split independently reconstructed')
    check(set(data['global_ids']) == set(ordered[ntest:]), 'outer train complement')
    identical(sorted(data['global_ids']), sorted(prov['train_ids']), 'provenance training IDs')
    identical(sorted(query['global_ids']), sorted(prov['test_ids']), 'provenance test IDs')
    expected_folds = [int.from_bytes(hashlib.sha256(('wc_spectral_smoke_v1|'+s).encode()).digest()[:8], 'big')%3
                      for s in data['global_ids']]
    identical(folds, expected_folds, 'inner hash split independently reconstructed')
    identical(data['low_positions'], np.arange(len(train_y)), 'single full-training budget')
    check(np.bincount(train_edges.ravel(), minlength=n).min() > 0, 'all endpoints supported')

    out = ROOT/'results/high'
    pred = npz(out/'predictions.npz')
    for key in ('edges', 'global_ids'):
        identical(pred[key], query[key], 'prediction identity alignment '+key)
    split = read(out/'split.json')
    identical(split['train_global_ids'], data['global_ids'], 'saved training IDs')
    identical(split['evaluation_global_ids'], query['global_ids'], 'saved evaluation IDs')
    identical(split['inner_fold'], folds, 'saved inner folds')
    models = read(out/'M0_models.json')
    baseline_optimality(models, train_edges, train_y, data['singles'])
    baseline = base_prediction(models, edges, data['singles'])
    close(baseline, pred['M0'], 'final M0 reconstruction', 1e-11)
    close(np.repeat(baseline.mean(axis=1)[:, None], 2, axis=1), pred['M0_repeat_mean'], 'M0 average reconstruction', 1e-11)
    train_residual = train_y-base_prediction(models, train_edges, data['singles'])
    cv, selection = read(out/'inner_summary.json'), read(out/'selection.json')
    base_oof = np.zeros_like(train_y)
    cache = {}
    for f in range(3):
        tr, va = folds != f, folds == f
        bm = read(out/f'inner{f}_baseline.json')
        baseline_optimality(bm, train_edges[tr], train_y[tr], data['singles'])
        base_oof[va] = base_prediction(bm, train_edges[va], data['singles'])
        cache[f] = (tr, va, train_y[tr]-base_prediction(bm, train_edges[tr], data['singles']))
    base_ss = np.sum((train_y-base_oof)**2, axis=0)
    close(base_ss, cv['M0_sse'], 'CV baseline SSE', 1e-9)
    rebuilt_rows, objectives = [], {}
    expected_grid = {(family, fraction, nu) for family in ('rank1', 'spectral')
                     for fraction in plan['tau_fractions'] for nu in plan['nu']}
    check({(r['family'], r['fraction'], r['nu']) for r in cv['grid']} == expected_grid, 'exact frozen candidate grid')
    check(len(cv['grid']) == len(expected_grid), 'no duplicate grid rows')
    for row in cv['grid']:
        key, family = row['key'], row['family']
        stored = npz(out/f'{key}_inner_predictions.npz')
        close(stored['y'], train_y, 'CV truth alignment', 0.)
        identical(stored['edges'], train_edges, 'CV edges alignment')
        identical(stored['fold'], folds, 'CV fold alignment')
        close(stored['baseline'], base_oof, 'CV baseline predictions', 1e-11)
        rebuilt = base_oof.copy()
        check(sorted(d['inner_fold'] for d in row['diagnostics']) == [0, 1, 2], 'three inner fits')
        for details in row['diagnostics']:
            f = details['inner_fold']; tr, va, residual = cache[f]
            G = npz(out/'inner_models'/f'{key}_f{f}.npz')['G']
            tz = n*np.max(np.abs(np.linalg.eigvalsh(loss_gradient(np.zeros_like(G), train_edges[tr], residual.mean(axis=1), 0.))))
            close(tz, details['tau_zero'], 'CV tau zero', 1e-11)
            close(tz*row['fraction'], details['tau'], 'CV tau scaling', 1e-11)
            objectives[(family, row['fraction'], row['nu'], f)] = model_check(
                G, details, train_edges[tr], residual, family, details['tau'], row['nu'])
            rebuilt[va] += correct(G, train_edges[tr], train_edges[va])[:, None]
            counts['inner_fits'] = counts.get('inner_fits', 0)+1
        close(rebuilt, stored['pred'], 'CV corrected prediction', 1e-11)
        ss = np.sum((train_y-rebuilt)**2, axis=0)
        close(ss, row['sse'], 'CV candidate SSE', 1e-9)
        close(ss.sum(), row['total'], 'CV candidate total', 1e-9)
        close(1-ss/base_ss, row['gain_each'], 'CV candidate gains', 1e-10)
        eligible = all(d['converged'] for d in row['diagnostics'])
        check(row['eligible'] == eligible, 'CV eligibility')
        rebuilt_rows.append(dict(key=key, family=family, fraction=row['fraction'], nu=row['nu'], total=float(ss.sum()), eligible=eligible))
    for p in cv['objective_probes']:
        k = (p['fraction'], p['nu'], p['inner_fold'])
        rank_obj, spectral_obj = objectives[('rank1', *k)], objectives[('spectral', *k)]
        gap = spectral_obj-rank_obj
        tol = 1e-7+1e-5*max(abs(rank_obj), abs(spectral_obj))
        close(gap, p['spectral_minus_rank1_objective'], 'convex order gap', 1e-11)
        close(tol, p['tolerance'], 'convex order tolerance', 1e-13)
        check(gap <= tol and p['pass'], 'convex contains rank1')
        counts['objective_order_probes'] = counts.get('objective_order_probes', 0)+1
    for family in ('rank1', 'spectral'):
        candidates = [r for r in rebuilt_rows if r['family'] == family and r['eligible']]
        best = min(candidates, key=lambda r:(r['total'], -r['fraction'], -r['nu']))
        use = best['total'] < base_ss.sum()-1e-12*max(1., base_ss.sum())
        check(selection[family]['best_regularized'] == best['key'], 'selected regularized candidate')
        check(selection[family]['selected'] == (best['key'] if use else 'G0'), 'frozen inner-only choice')
        close(selection[family]['inner_gain_pooled'], 1-best['total']/base_ss.sum(), 'selection pooled gain', 1e-10)
        G = pred[family+'_G']; details = read(out/f'{family}_model.json')
        tz = n*np.max(np.abs(np.linalg.eigvalsh(loss_gradient(np.zeros_like(G), train_edges, train_residual.mean(axis=1), 0.))))
        close(details['tau'], tz*best['fraction'], 'final tau uses own training pool', 1e-11)
        close(details['nu'], best['nu'], 'final nu', 0.)
        model_check(G, details, train_edges, train_residual, family, details['tau'], details['nu'])
        corrected = baseline+correct(G, train_edges, edges)[:, None]
        close(corrected, pred[family+'_regularized'], 'final nonzero prediction', 1e-11)
        close(corrected if use else baseline, pred[family+'_selected'], 'final selected prediction', 1e-11)
        counts['final_refits'] = counts.get('final_refits', 0)+1

    # Independently use least squares projection, instead of scorer's SVD basis.
    m = len(edges)
    X = np.zeros((m, n)); X[np.arange(m), edges[:, 0]] = 1; X[np.arange(m), edges[:, 1]] = 1
    projection_rank = int(np.linalg.matrix_rank(X))
    def project(error):
        return error-X@np.linalg.lstsq(X, error, rcond=None)[0]
    loss = {k:(y-pred[k])**2 for k in METHODS}
    base_each = loss['M0'].sum(axis=0)
    projected_base = (project(y-pred['M0'])**2).sum(axis=0)
    independent_scores = {}
    for method in METHODS:
        ss = loss[method].sum(axis=0)
        ps = (project(y-pred[method])**2).sum(axis=0)
        deletion = []
        for g in range(n):
            keep = (edges[:, 0] != g)&(edges[:, 1] != g)
            deletion.append(float(1-loss[method][keep].sum()/loss['M0'][keep].sum()))
        vals = dict(sse_each=ss.tolist(), mse_each=(ss/m).tolist(), mse_pooled=float(ss.sum()/(2*m)),
                    gain_each=(1-ss/base_each).tolist(), gain_pooled=float(1-ss.sum()/base_each.sum()),
                    projected_sse_each=ps.tolist(), projected_gain_each=(1-ps/projected_base).tolist(),
                    projected_gain_pooled=float(1-ps.sum()/projected_base.sum()),
                    delete_one_gene_gain=deletion, delete_one_gene_min=min(deletion),
                    delete_one_gene_positive=sum(g>0 for g in deletion),
                    gain_vs_repeat_mean=float(1-ss.sum()/loss['M0_repeat_mean'].sum()))
        for key, value in vals.items():
            close(value, summary['models'][method][key], 'score '+key, 1e-9)
        independent_scores[method] = vals

    spec = plan['uncertainty']; rng = np.random.default_rng(spec['seed'])
    draws = {k:[] for k in METHODS}; attempts = 0
    edge_loss = {k:loss[k].sum(axis=1) for k in METHODS}
    while len(draws['M0']) < spec['draws'] and attempts < spec['max_attempts']:
        attempts += 1
        counts_gene = rng.multinomial(n, np.ones(n)/n)
        weights = counts_gene[edges[:, 0]]*counts_gene[edges[:, 1]]
        denominator = float(np.dot(weights, edge_loss['M0']))
        if denominator <= 0:
            continue
        for method in METHODS:
            draws[method].append(float(1-np.dot(weights, edge_loss[method])/denominator))
    check(len(draws['M0']) == spec['draws'], 'full prescribed node draws')
    stored_draws = npz(ROOT/'results/node_reweighting_draws.npz')
    for method in METHODS:
        close(draws[method], stored_draws[method], 'node draw reproduction', 1e-11)
        interval = np.quantile(draws[method], spec['quantiles'])
        close(interval, summary['models'][method]['node_reweighting_95_interval'], 'node interval reproduction', 1e-11)
        independent_scores[method]['node_reweighting_95_interval'] = interval.tolist()
    check(attempts == summary['bootstrap_attempts'], 'bootstrap attempt count')
    primary = independent_scores['rank1_selected']
    direction = primary['gain_pooled'] > 0 and all(v > 0 for v in primary['gain_each'])
    interval_support = direction and primary['node_reweighting_95_interval'][0] > 0
    check(direction == summary['primary_decision']['direction_replication'], 'primary directional decision')
    check(interval_support == summary['primary_decision']['conditional_interval_support'], 'primary interval decision')
    check(summary['primary_decision']['primary'] == 'rank1_selected', 'primary family fixed')
    check(summary['primary_decision']['secondary_cannot_rescue_primary'], 'secondary does not replace primary')
    check(summary['test_contrast_dimension'] == m-projection_rank == prov['test_contrast_dimension'], 'contrast dimension')
    check(summary['n_train'] == len(train_y) == prov['n_train'], 'training count')
    check(summary['n_test'] == m == prov['n_test'], 'test count')
    check(summary['n_repeat_measurements'] == 2*m, 'repeat count distinct from pair count')
    packed = npz(ROOT/'results/evaluation_predictions.npz')
    for key, array in [('genes', data['genes']), ('edges', edges), ('ids', query['global_ids'])]:
        identical(packed[key], array, 'packaged identity '+key)
    close(packed['y'], y, 'packaged truth', 0.)
    for method in METHODS:
        close(packed[method], pred[method], 'packaged predictions '+method, 0.)
    check(counts['inner_fits'] == 48 and counts['final_refits'] == 2 and counts['objective_order_probes'] == 24,
          'prescribed fit/probe counts')
    for k, v in [('inner_fits', counts['inner_fits']), ('objective_probes_passed', counts['objective_order_probes'])]:
        check(summary['checks'][k] == v, 'summary check '+k)
    check(summary['checks']['inner_converged'] == sum(d['converged'] for r in cv['grid'] for d in r['diagnostics']), 'summary converged count')
    check(summary['checks']['final_selected_converged'], 'summary final convergence')
    check(summary['checks']['predictions_locked_before_scoring'], 'summary lock claim')
    result = dict(status='PASS' if not failures else 'FAIL',
                  utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  verification='No fitting/core/scorer imports; independent equations, selection, loss, node-draw and hash-chain reconstruction.',
                  counts=counts, maximum_absolute_discrepancies=maximum, failures=failures,
                  primary_decision=dict(direction_replication=bool(direction), conditional_interval_support=bool(interval_support)),
                  scores=independent_scores, availability_amendment=amendment,
                  documentation_notes=['PLAN sensitivity prose still says 80 endpoints; n_fixed=79 and unchanged scoring code actually use all 79 retained endpoints. Original frozen prose retained, not edited after scoring.'],
                  limitations=['Checks current artifacts and recorded order, not all historical human access.',
                               'Node reweighting is conditional sensitivity, with uncalibrated nominal coverage.',
                               'Same-study held environment; no independent-study or RNA validation claim.'])
    (ROOT/'INDEPENDENT_CHECK.json').write_text(json.dumps(result, indent=2, allow_nan=False))
    print(json.dumps({k:result[k] for k in ('status', 'counts', 'maximum_absolute_discrepancies', 'failures')}, indent=2))
    if failures:
        raise SystemExit(1)

if __name__ == '__main__':
    main()

