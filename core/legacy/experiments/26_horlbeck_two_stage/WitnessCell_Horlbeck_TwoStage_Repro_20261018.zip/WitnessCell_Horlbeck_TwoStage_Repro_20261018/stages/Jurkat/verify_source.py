"""Independent Jurkat source aggregation check; imports no experiment code.

Run after prediction lock and scoring. Rebuilds supplied gene-level targets from
the author-processed growth-phenotype source, not the published GI matrix.
"""
import argparse
import collections
import datetime
import gzip
import hashlib
import json
import math
from pathlib import Path

import numpy as np


def digest(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--raw", type=Path, default=Path(__file__).resolve().parent.parent / "horlbeck_freeze_20261018/WitnessCell_Horlbeck_Freeze_v1/data/raw")
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    genes = json.loads((root / "protocol/genes.json").read_text())
    original_genes = json.loads((root / "protocol/original_k562_80genes.json").read_text())
    assert len(genes) == 79 and set(original_genes) - set(genes) == {"GINS4"}
    selected = set(genes)
    single_selected = selected | {"GINS4"}
    annotations = args.raw / "GSE116198_GImap_sgRNA_sequences_barcodes.txt.gz"
    phenotypes = args.raw / "GSE116198_sgRNA_pair_phenotypes.txt.gz"
    guide_gene = {}
    with gzip.open(annotations, "rt") as f:
        for line in f:
            if not line.strip():
                continue
            fields = line.rstrip("\n").split("\t")
            assert len(fields) == 9 and fields[3] == "Y"
            assert fields[1] == fields[2]
            guide = fields[2]
            gene = "negative" if guide.startswith("negative_control-") else guide.split("_")[0]
            assert guide not in guide_gene
            guide_gene[guide] = gene

    # Raw records grouped first by physical guide pair, then vector orientation.
    # Separate repeat lists ensure that a missing measurement is never zero.
    physical = {}
    group_of = {}
    counters = collections.Counter()
    gins4_available_records = [0, 0]
    with gzip.open(phenotypes, "rt") as f:
        headers = [next(f).rstrip("\n").split("\t") for _ in range(3)]
        labels = list(zip(*headers))
        columns = [labels.index(("Jurkat", "Triple Sequencing", f"Replicate {r}")) for r in (1, 2)]
        assert columns == [4, 5]
        for line in f:
            if not line.strip():
                counters["blank_rows"] += 1
                continue
            counters["source_rows"] += 1
            fields = line.rstrip("\n").split("\t")
            ga, gb = fields[0].split("++")
            if ga not in guide_gene or gb not in guide_gene:
                continue
            a, b = guide_gene[ga], guide_gene[gb]
            if a == "negative" and b in single_selected:
                group = ("single", b)
            elif b == "negative" and a in single_selected:
                group = ("single", a)
            elif a in selected and b in selected and a != b:
                group = ("pair", "|".join(sorted((a, b))))
            else:
                continue
            counters[group[0] + "_source_rows"] += 1
            key = tuple(sorted((ga, gb)))
            group_of[key] = group
            orientation = (ga, gb)
            reps = physical.setdefault(key, {}).setdefault(orientation, [[], []])
            for r, col in enumerate(columns):
                try:
                    value = float(fields[col])
                except ValueError:
                    value = float("nan")
                if math.isfinite(value):
                    reps[r].append(value)
                    if group == ("single", "GINS4"):
                        gins4_available_records[r] += 1
                else:
                    counters[group[0] + "_nonfinite_records"] += 1

    # Equal orientation weighting, then equal physical-guide-pair weighting.
    grouped = collections.defaultdict(lambda: [[], []])
    orientation_histogram = collections.Counter()
    for key, orientation_records in physical.items():
        orientation_histogram[str(len(orientation_records))] += 1
        group = group_of[key]
        for r in (0, 1):
            means = [math.fsum(reps[r]) / len(reps[r]) for reps in orientation_records.values() if reps[r]]
            if means:
                grouped[group][r].append(math.fsum(means) / len(means))

    def value(group, r):
        values = grouped[group][r]
        return math.fsum(values) / len(values) if values else float("nan")

    def compare(expected, observed):
        assert expected.shape == observed.shape
        diff = float(np.max(np.abs(expected - observed)))
        return {"shape": list(expected.shape), "max_absolute_error": diff,
                "bitwise_equal": bool(np.array_equal(expected, observed)),
                "allclose_atol_1e-12_rtol_0": bool(np.allclose(expected, observed, atol=1e-12, rtol=0))}

    rebuilt_singles = np.array([[value(("single", gene), r) for r in (0, 1)] for gene in genes])
    rebuilt_counts = np.array([[len(grouped[("single", gene)][r]) for r in (0, 1)] for gene in genes])
    training = np.load(root / "inputs/training.npz", allow_pickle=False)
    sealed = np.load(root / "sealed/evaluation_truth.npz", allow_pickle=False)
    query = np.load(root / "inputs/query.npz", allow_pickle=False)
    counts = np.load(root / "inputs/measurement_counts.npz", allow_pickle=False)
    assert training["genes"].tolist() == genes
    checks = {"singles": compare(rebuilt_singles, training["singles"]),
              "single_counts": compare(rebuilt_counts, counts["single_physical_pairs"])}
    for label, asset in (("training", training), ("evaluation", sealed)):
        ids = asset["global_ids"].tolist()
        actual_ids = ["|".join(sorted((genes[int(a)], genes[int(b)]))) for a, b in asset["edges"]]
        assert ids == actual_ids
        rebuilt = np.array([[value(("pair", pair), r) for r in (0, 1)] for pair in ids])
        checks[label + "_responses"] = compare(rebuilt, asset["y"])
    pair_ids = counts["pair_ids"].tolist()
    rebuilt_pair_counts = np.array([[len(grouped[("pair", pair)][r]) for r in (0, 1)] for pair in pair_ids])
    checks["pair_counts"] = compare(rebuilt_pair_counts, counts["pair_physical_counts"])
    assert np.array_equal(query["edges"], sealed["edges"])
    assert np.array_equal(query["global_ids"], sealed["global_ids"])
    train_ids, test_ids = set(training["global_ids"]), set(sealed["global_ids"])
    assert not train_ids & test_ids
    assert train_ids | test_ids == set(pair_ids)
    assert len(pair_ids) == len(genes) * (len(genes) - 1) // 2
    assert all(v["allclose_atol_1e-12_rtol_0"] for v in checks.values())
    gins4_counts = [len(grouped[("single", "GINS4")][r]) for r in (0, 1)]
    out = {
        "status": "PASS", "utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "independence": "Raw source reread; standalone implementation using csv-like streaming and math.fsum; no imports of prepare_jurkat, source_prepare_k562, model or scoring modules; no fitting or gene selection.",
        "source": "GSE116198 author-processed growth phenotype gamma, not GI scores",
        "columns": [list(labels[i]) for i in columns], "column_indexes_including_id": columns,
        "aggregation": "Finite records mean within ordered guide-pair orientation; equal available-orientation mean within unordered physical guide pair; equal physical-pair mean within gene or unordered gene pair. Negative controls supply singles. No zeros imputed.",
        "annotation_guides": len(guide_gene), "negative_control_guides": sum(g == "negative" for g in guide_gene.values()),
        "source_counters": dict(counters), "orientation_count_histogram": dict(orientation_histogram),
        "n_genes": len(genes), "n_training_pairs": len(train_ids), "n_evaluation_pairs": len(test_ids), "n_total_pairs": len(pair_ids),
        "checks": checks,
        "GINS4_availability": {"finite_ordered_source_records_by_repeat": gins4_available_records,
                              "finite_physical_guide_pairs_by_repeat": gins4_counts,
                              "missing_repeats": [r + 1 for r, count in enumerate(gins4_counts) if count == 0]},
        "source_sha256": {p.name: digest(p) for p in (annotations, phenotypes)},
        "checked_asset_sha256": {str(p.relative_to(root)): digest(p) for p in (root / "inputs/training.npz", root / "sealed/evaluation_truth.npz", root / "inputs/query.npz", root / "inputs/measurement_counts.npz")},
        "script_sha256": digest(Path(__file__)),
    }
    (root / "SOURCE_CHECK.json").write_text(json.dumps(out, indent=2) + "\n")
    print(json.dumps(out, indent=2))


if __name__ == "__main__":
    main()
