WitnessCell：固定M0、秩一与谱矩阵的完整三折开发实验
日期：2026-10-18；读出：Horlbeck K562生长表型。

结论：三折均支持在较高训练信息量下，伙伴修正能够改善未测组合预测；当前结果不支持把多模式矩阵视为必要条件。
烟测后未改变模型、超参数候选、选模规则或收敛标准。保留已完成的第1折，补齐第2、3折，并合并全部632个不重复评价基因对。每对有两次重复测量。

详细结果：WitnessCell_Horlbeck_Spectral_Full_20261018.txt
复算：python3 reproduce.py
独立核对：python3 verify_full.py
