"""Create a Chinese results report and a figure from locked saved scores."""
from pathlib import Path
import json,platform,sys
import numpy as np
ROOT=Path(__file__).resolve().parent
NAME='WitnessCell_Horlbeck_Spectral_Full_20261018'
def pct(v):return f'{100*v:+.4f}%'
def main():
    s=json.loads((ROOT/'SUMMARY.json').read_text());a=s['aggregate'];folds=s['folds']
    verify=json.loads((ROOT/'INDEPENDENT_CHECK.json').read_text())
    assert verify['status']=='PASS', 'Independent verification must pass before report generation'
    timing=json.loads((ROOT/'FIT_TIMING.json').read_text());rep=json.loads((ROOT/'REPRODUCTION_CHECK.json').read_text())
    lines=['WitnessCell：固定M0、秩一与谱矩阵的完整三折开发实验','日期：2026-10-18；读出：Horlbeck K562生长表型。','',
      '结论：三折均支持在较高训练信息量下，伙伴修正能够改善未测组合预测；当前结果不支持把多模式矩阵视为必要条件。',
      '烟测后未改变模型、超参数候选、选模规则或收敛标准。保留已完成的第1折，补齐第2、3折，并合并全部632个不重复评价基因对。每对有两次重复测量。','',
      '主要结果：正数表示相对同一训练预算下M0的误差降低。按逐组合SSE相加后计算比值，未平均三个折的百分比。',
      '训练预算 / 方法 | 总体MSE | 总体误差降低 | 重复1误差降低 | 重复2误差降低 | 去端点误差降低']
    for budget in ('low','high'):
        for m,label in [('M0','M0'),('rank1_selected','秩一（含G0回退）'),('spectral_selected','谱矩阵（含G0回退）'),('M0_repeat_mean','M0重复预测直接平均（参考）')]:
            x=a[budget]['models'][m]
            lines.append(f"{budget} / {label} | {x['mse_pooled']:.10f} | {pct(x['gain_pooled'])} | {pct(x['gain_each'][0])} | {pct(x['gain_each'][1])} | {pct(x['projected_gain_pooled'])}")
    lines+=['','逐折结果（总体误差降低）：','折 / 训练预算 | 秩一 | 谱矩阵 | 评价组合数']
    for f in ('0','1','2'):
        for b in ('low','high'):
            d=folds[f]['budgets'][b]
            lines.append(f"{int(f)+1} / {b} ({d['train_pairs']}对训练) | {pct(d['models']['rank1_selected']['gain_pooled'])} | {pct(d['models']['spectral_selected']['gain_pooled'])} | {folds[f]['evaluation_pairs']}")
    m0gain=s['density_comparison']['M0']['high_vs_low_gain'];overall=1-a['high']['models']['spectral_selected']['sse_total']/a['low']['models']['M0']['sse_total']
    gap=a['high']['models']['spectral_selected']['gain_pooled']-a['high']['models']['rank1_selected']['gain_pooled']
    lines+=['','大白话解释：',
      f'1. 增加训练组合后，M0自己已改善{100*m0gain:.4f}%；伙伴修正是在更强M0之上获得额外改善，二者没有混算。',
      '2. 低密度421、421、422对训练时，伙伴层总体收益接近零：秩一有两折选择退回M0，谱矩阵汇总略有恶化。',
      '3. 高密度2317、2317、2318对训练时，两种伙伴模型在三个折、两次重复共六个结果中全部改善。',
      '4. 高密度下，去除自由端点加法成分后误差仍下降，说明改进不全是端点校正；仍不能排除剩余共同非线性失配，也不能单独证明特定生物机制。',
      f'5. 谱矩阵总体比秩一多降低{100*gap:.4f}个百分点的M0误差，差距很小；其中两折秩一更好，一折谱矩阵更好。当前不能断言必须有多个伙伴模式。',
      f'6. 高密度谱模型相对低密度M0的总误差下降为{100*overall:.4f}%，包含增加数据和增加修正两个来源；主方法结果仍采用相对同密度M0的改善。',
      '7. 两档信息量支持比较这两个预算，不能由此推断最少测量数、密度阈值、完整采样曲线或O(n)规律。',
      '',
      '执行范围：',
      '- 原80基因面板，共3160个非自配对；允许训练候选池2528对，原正式测试632对均未进入本轮训练或评分。',
      '- 本轮632个开发评价组合来自原允许池。每个评价组合只在它所属的外层折评分一次；它可以在其他折作为训练组合，这是交叉验证，不能把折当独立实验。',
      '- 每折低密度训练集包含于高密度训练集，两者均排除本折评价组合。组合的两个重复始终一起留出。',
      '- 第一折已经在烟测中查看过；其余两折按烟测最终版规则完成。因此整体是完整开发评价，不是新的独立确认。',
      '- Jurkat未访问。未进行湿实验、前瞻预测或RNA外部验证。',
      '',
      '模型与选择规则：',
      '- M0固定alpha=10，沿用原代码与各重复自己的单扰动尺度；每个训练预算、每个内层划分重新拟合。',
      '- 伙伴层训练目标为同一训练集上的M0残差；内层评价完整M0+G。没有强制使用OOF残差。',
      '- 两重复原单位共用一个G。等权平方损失等价于拟合两重复平均残差；并不额外宣称特殊的重复证据机制。',
      '- 共同目标：mean_edges((mean_repeat_residual-G_AB)^2)+tau/80*||G||_*+nu/80^2*||G||_F^2。',
      '- 秩一G=lambda*u*u^T，||u||2=1，lambda可正可负，不额外中心化或加集中度罚。谱矩阵对称，允许正负谱，未测对角线自由且受矩阵惩罚。',
      '- 缺失组合与对角线不进入观测损失。无训练支持端点按固定规则回退。',
      '- 两家族共用8个候选：tau/tau_zero为0.3、0.1、0.03、0.01，nu为0.1、1；tau_zero仅由每次拟合的训练残差计算。',
      '- 内层三折按完整预测的两重复合并SSE选参，显式含G0。未选择的最佳正则化候选仍保存，仅作诊断。',
      '- 高密度三个折均独立选中相同设置：秩一tau比例0.03、nu=0.1；谱矩阵tau比例0.3、nu=0.1。',
      '',
      '复算与数值检查：',
      f"- 三折合计{s['checks']['inner_converged']}/{s['checks']['inner_fit_count']}个内层拟合通过收敛标准，{s['checks']['objective_order_probes_passed']}个同目标比较均满足谱矩阵目标不高于秩一。",
      '- 12个最终伙伴模型重拟合均通过；保存了全部逐组合预测、每折每候选内层预测与矩阵。',
      '- 去端点投影在每个外层折各自计算，再相加其SSE，避免把不同拟合模型的输出合并投影而制造对比。',
      '- 低密度三折M0与旧M0保存结果对齐核对；独立脚本重构保存预测并复算选模、误差与收益。',
      '- 核心求解器和基线代码与烟测最终版逐字节一致，本轮没有再修改目标、初始化、候选或数值标准。',
      f"- 补跑另外两折拟合用时{timing['total_new_fit_seconds']:.3f}秒；完整三折复算入口额外用时{rep['reproduction_fit_seconds']:.3f}秒。代码整理、验证与打包时间未包含在这些训练耗时中。",
      '- 使用现有CPU环境，未安装软件或重建AutoDL环境。',
      '',
      '下一步建议：',
      '把当前规则作为候选冻结，准备保留环境中的独立确认。谱矩阵没有形成明显优于秩一的优势，当前无需为了追求复杂度追加MLP。若下一阶段要二选一，应在查看保留环境结果前明确主方法；也可预先指定两方法并处理多重比较。',
      '这项结果支持K562生长读出上、较充分组合支持下的留出预测价值；不把它转换为RNA能力通过、75%命中率或期刊录用保证。',
      '',
      '复算方式：现有含NumPy和SciPy的Python环境运行 python3 reproduce.py。它会在reproduction目录重新计算全部三折，保留交付结果。',
      '只读独立核对：python3 verify_full.py。数据、参考旧M0、冻结规则、核心代码、保存矩阵、原始预测与汇总均在包内。'
    ]
    (ROOT/(NAME+'.txt')).write_text('\n'.join(lines)+'\n')
    (ROOT/'README_zh.txt').write_text('\n'.join(lines[:5])+f'\n\n详细结果：{NAME}.txt\n复算：python3 reproduce.py\n独立核对：python3 verify_full.py\n')
    (ROOT/'environment.json').write_text(json.dumps({'python':sys.version,'numpy':np.__version__,'scipy':__import__('scipy').__version__,'platform':platform.platform(),'device':'CPU','blas_threads':1,'installed_new_packages':False},indent=2))
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'axes.spines.top':False,'axes.spines.right':False})
    fig,axs=plt.subplots(1,2,figsize=(11,4.2),layout='constrained');colors=['#2677B8','#D7742B']
    x=np.arange(2);width=.32
    for j,m in enumerate(('rank1_selected','spectral_selected')):
        vals=[100*a[b]['models'][m]['gain_pooled'] for b in ('low','high')]
        bars=axs[0].bar(x+(j-.5)*width,vals,width,color=colors[j],label=['Rank-one','Spectral'][j])
        axs[0].bar_label(bars,labels=[f'{v:+.2f}%' for v in vals],padding=4,fontsize=10)
    axs[0].axhline(0,color='#777777',lw=.8);axs[0].set_xticks(x,['421–422 pairs','2,317–2,318 pairs']);axs[0].set_ylabel('MSE reduction versus same-budget M0 (%)');axs[0].set_title('All 632 development pairs');axs[0].set_ylim(-2,14);axs[0].legend(frameon=False)
    for j,m in enumerate(('rank1_selected','spectral_selected')):
        vals=[100*folds[str(f)]['budgets']['high']['models'][m]['gain_pooled'] for f in (0,1,2)]
        axs[1].plot(np.arange(3),vals,'o-',color=colors[j],label=['Rank-one','Spectral'][j],lw=1.7)
        for xx,yy in enumerate(vals):axs[1].annotate(f'{yy:.2f}',(xx,yy),xytext=(0,8 if j==0 else -15),textcoords='offset points',ha='center',fontsize=9)
    axs[1].axhline(0,color='#777777',lw=.8);axs[1].set_xticks([0,1,2],['Fold 1','Fold 2','Fold 3']);axs[1].set_title('Higher-information budget');axs[1].set_ylabel('MSE reduction versus M0 (%)');axs[1].set_ylim(0,20)
    fig.savefig(ROOT/(NAME+'.png'),dpi=180);plt.close(fig)
    print(json.dumps({'report':str(ROOT/(NAME+'.txt')),'figure':str(ROOT/(NAME+'.png')),'verification_status':verify.get('status')}))
if __name__=='__main__':main()
