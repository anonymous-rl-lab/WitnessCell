#!/usr/bin/env python3
"""Independent synthetic/identity checks; never opens real outcome files.

The probes test implementation and optimization. Synthetic held-out gains are not
scientific performance or a calibrated false-positive-rate experiment.
"""
from __future__ import annotations
import json
import time
from pathlib import Path
import numpy as np

SEED = 20261018


def independent_objective(G, edges, residual, tau, nu):
    G = np.asarray(G, float)
    edges = np.asarray(edges, int)
    residual = np.asarray(residual, float)
    if residual.ndim == 2:
        residual = residual.mean(axis=1)
    n = len(G)
    loss = np.mean((G[edges[:, 0], edges[:, 1]] - residual)**2)
    penalty = tau / n * np.abs(np.linalg.eigvalsh(G)).sum()
    penalty += nu / n**2 * np.sum(G**2)
    return float(loss + penalty)


def independent_smooth_gradient(G, edges, residual, nu):
    residual = np.asarray(residual, float)
    if residual.ndim == 2:
        residual = residual.mean(axis=1)
    n = len(G)
    grad = 2 * nu / n**2 * G.copy()
    values = (G[edges[:, 0], edges[:, 1]] - residual) / len(edges)
    np.add.at(grad, (edges[:, 0], edges[:, 1]), values)
    np.add.at(grad, (edges[:, 1], edges[:, 0]), values)
    return grad


def mse_table(G, edges, y):
    pred = G[edges[:, 0], edges[:, 1]][:, None]
    mse0 = np.mean(y**2, axis=0)
    mse = np.mean((y-pred)**2, axis=0)
    return {"mse_by_repeat": mse.tolist(), "baseline_mse_by_repeat": mse0.tolist(),
            "gain_by_repeat": (1-mse/mse0).tolist(),
            "pooled_gain": float(1-mse.sum()/mse0.sum())}


def run_checks():
    # Adapter functions are supplied below after the solver's public interface.
    import spectral_models as sm
    rng = np.random.default_rng(SEED)
    n = 9
    edges = np.array([(i,j) for i in range(n) for j in range(i+1,n)], int)
    edges = edges[rng.choice(len(edges), 22, replace=False)]
    Z = rng.normal(size=(n,n)); G = (Z+Z.T)/2
    r = rng.normal(size=(len(edges),2)); rbar = r.mean(axis=1)
    tau, nu = .17, .23
    expected = independent_objective(G, edges, rbar, tau, nu)
    actual = solver_objective(sm, G, edges, rbar, tau, nu)
    repeated_loss = float(np.mean((r-G[edges[:,0],edges[:,1],None])**2))
    average_loss = float(np.mean((rbar-G[edges[:,0],edges[:,1]])**2))
    identity_rhs = average_loss + .25*np.mean((r[:,0]-r[:,1])**2)
    u = rng.normal(size=n); u /= np.linalg.norm(u)
    lam = -2.31
    rank1_G = lam*np.outer(u,u)
    p_matrix = tau/n*np.abs(np.linalg.eigvalsh(rank1_G)).sum()+nu/n**2*np.sum(rank1_G**2)
    p_scalar = tau/n*abs(lam)+nu/n**2*lam**2
    grad = independent_smooth_gradient(G, edges, rbar, nu)
    grad_actual = solver_smooth_gradient(sm, G, edges, rbar, nu)
    directional_errors = []
    for _ in range(6):
        H = rng.normal(size=(n,n)); H=(H+H.T)/2; H/=np.linalg.norm(H)
        eps = 1e-6
        fd = (independent_objective(G+eps*H,edges,rbar,0,nu)-independent_objective(G-eps*H,edges,rbar,0,nu))/(2*eps)
        directional_errors.append(abs(fd-float(np.sum(grad_actual*H))))
    missing = next((i,j) for i in range(n) for j in range(i+1,n) if not np.any(np.all(edges==[i,j],axis=1)))
    Z2 = G.copy(); Z2[missing]=Z2[missing[::-1]]=G[missing]+7.0
    Z2[0,0] += 9.0
    missing_effect = abs(solver_objective(sm,Z2,edges,rbar,0,0)-solver_objective(sm,G,edges,rbar,0,0))
    checks = {
        "objective_absolute_error": abs(actual-expected),
        "repeat_average_identity_absolute_error": abs(repeated_loss-identity_rhs),
        "solver_repeat_average_identity_absolute_error": abs(solver_objective(sm,G,edges,r,tau,nu)-solver_objective(sm,G,edges,rbar,tau,nu)),
        "signed_rank1_penalty_absolute_error": abs(p_matrix-p_scalar),
        "solver_signed_rank1_penalty_absolute_error": abs(solver_objective(sm,rank1_G,edges,rbar,tau,nu)-solver_objective(sm,rank1_G,edges,rbar,0,0)-p_scalar),
        "smooth_gradient_max_absolute_error": float(np.max(np.abs(grad-grad_actual))),
        "smooth_directional_fd_max_absolute_error": max(directional_errors),
        "unobserved_edge_and_diagonal_loss_change": missing_effect,
        "fixed_seed": SEED,
    }
    for name, value in checks.items():
        if name != "fixed_seed":
            assert value < 2e-7, (name, value)
    # A known-zero target has exactly G=0 as a global optimum.
    zero_edges = np.array([(i,j) for i in range(12) for j in range(i+1,12)], int)[::2]
    zero_fit = solver_fit(sm, "spectral", 12, zero_edges, np.zeros(len(zero_edges)), .03, .01)
    checks["exact_zero_solution_frobenius"] = float(np.linalg.norm(zero_fit["G"]))
    assert checks["exact_zero_solution_frobenius"] < 1e-9

    n = 24
    all_edges = np.array([(i,j) for i in range(n) for j in range(i+1,n)], int)
    order = rng.permutation(len(all_edges))
    train = all_edges[order[:198]]
    test = all_edges[order[198:]]
    Q, _ = np.linalg.qr(rng.normal(size=(n,3)))
    truth = Q @ np.diag([22., -17., 12.]) @ Q.T
    simulations = {}
    for label, signal in [("null_noise", np.zeros((n,n))), ("signed_three_modes", truth)]:
        rtrain = signal[train[:,0],train[:,1],None]+rng.normal(0,.05,size=(len(train),2))
        rtest = signal[test[:,0],test[:,1],None]+rng.normal(0,.05,size=(len(test),2))
        rb = rtrain.mean(axis=1)
        fits = {}
        for method in ["rank1", "spectral"]:
            start = time.monotonic()
            fits[method] = solver_fit(sm, method, n, train, rb, .025, .01)
            fits[method]["seconds"] = time.monotonic()-start
        obj = {m: independent_objective(f["G"],train,rb,.025,.01) for m,f in fits.items()}
        difference = obj["spectral"]-obj["rank1"]
        tolerance = 2e-7*max(1.,abs(obj["rank1"]))
        assert difference <= tolerance, (label, difference, obj)
        simulations[label] = {
            "n_genes": n, "n_train_pairs": len(train), "n_test_pairs": len(test),
            "noise_sd_per_repeat": .05, "tau": .025, "nu": .01,
            "known_signal_eigenvalues": [22., -17., 12.] if label != "null_noise" else [0.],
            "convex_minus_rank1_objective": difference,
            "convex_objective_tolerance": tolerance,
            "models": {m: {"objective": obj[m], "seconds": f["seconds"],
                       "converged": bool(f.get("converged", True)),
                       "numerical_rank": int(np.sum(np.abs(np.linalg.eigvalsh(f["G"]))>1e-6)),
                       **mse_table(f["G"],test,rtest)} for m,f in fits.items()},
        }
    return {"status": "PASS", "scope": "Implementation probes only; no real outcomes used. No empirical null calibration claimed.",
            "identities": checks, "simulations": simulations}


def solver_objective(sm, G, edges, r, tau, nu):
    return float(sm.data_loss_objective(G, edges, r, tau=tau, nu=nu))


def solver_smooth_gradient(sm, G, edges, r, nu):
    return sm.smooth_gradient(G, edges, r, nu=nu)


def solver_fit(sm, method, n, edges, r, tau, nu):
    func = sm.fit_spectral if method == "spectral" else sm.fit_rank1
    result = func(n, edges, r, tau=tau, nu=nu, max_iter=3000, tol=1e-6)
    assert result["converged"], (method, result.get("stationarity_relative"), result.get("iterations"))
    return result



if __name__ == "__main__":
    started = time.monotonic()
    result = run_checks()
    result["total_seconds"] = time.monotonic()-started
    path = Path(__file__).resolve().parent/"engineering_checks.json"
    path.write_text(json.dumps(result,ensure_ascii=False,indent=2)+"\n")
    print(json.dumps(result,ensure_ascii=False))
