"""Prepare remaining K562 development folds from permitted pool; no formal outcomes."""
from pathlib import Path
import hashlib,json
import numpy as np
ROOT=Path(__file__).resolve().parent
def dump(p,v):p.write_text(json.dumps(v,indent=2))
def main():
    source=ROOT.parent/'horlbeck_regularization_check_20261018/inputs'
    split=json.loads((source/'split.json').read_text())
    with np.load(source/'allowed_inputs.npz',allow_pickle=False) as z:
        genes=z['genes'].astype(str);singles=z['singles'];edges=z['edges']
        pool=z['train_pool_indices'];responses=z['train_pool_responses']
    dev=np.asarray(split['train_indices_by_budget']['0.20'],int)
    folds=np.asarray(split['innerfold_by_budget']['0.20'],int)
    formal=set(split['test_indices']);lookup={int(i):j for j,i in enumerate(pool)}
    assert len(dev)==632 and len(pool)==2528 and not(set(pool)&formal)
    summary={}
    for fold in (0,1,2):
        evaluation=dev[folds==fold];low=dev[folds!=fold];evset=set(evaluation)
        high=np.asarray([i for i in pool if i not in evset],int)
        assert set(low)<=set(high) and not(set(high)&evset) and not((set(high)|evset)&formal)
        assert len(low)+len(evaluation)==632 and len(high)+len(evaluation)==2528
        high_lookup={int(i):j for j,i in enumerate(high)}
        inner=[]
        for g,h in edges[high]:
            x,y=sorted((str(genes[g]),str(genes[h])))
            inner.append(int.from_bytes(hashlib.sha256(('wc_spectral_smoke_v1|'+x+'|'+y).encode()).digest()[:8],'big')%3)
        case=ROOT/'cases'/f'outer{fold}';out=case/'inputs';out.mkdir(parents=True,exist_ok=True)
        train=dict(genes=genes,singles=singles,edges=edges[high],y=responses[[lookup[int(i)] for i in high]],global_ids=high,
            low_positions=np.asarray([high_lookup[int(i)] for i in low]),inner_fold=np.asarray(inner))
        ev=dict(edges=edges[evaluation],y=responses[[lookup[int(i)] for i in evaluation]],global_ids=evaluation)
        if fold==0:
            for name,expected in [('training.npz',train),('evaluation.npz',ev)]:
                with np.load(out/name,allow_pickle=False) as saved:
                    for key,value in expected.items():assert np.array_equal(saved[key],value)
        else:
            np.savez_compressed(out/'training.npz',**train);np.savez_compressed(out/'evaluation.npz',**ev)
        summary[str(fold)]={'train_low':len(low),'train_high':len(high),'evaluation':len(evaluation),
            'low_subset_high':True,'excluded_current_evaluation':True,'excluded_original_formal_test':True,
            'input_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in out.glob('*.npz')}}
    dump(ROOT/'INPUT_PROVENANCE.json',{'source_sha256':{name:hashlib.sha256((source/name).read_bytes()).hexdigest() for name in ('allowed_inputs.npz','split.json')},
        'development_global_ids':dev.tolist(),'development_fold':folds.tolist(),'formal_test_ids':sorted(formal),'pool_ids':pool.tolist(),
        'folds':summary,'formal_outcomes_accessed':False,'Jurkat_accessed':False})
    print(json.dumps(summary))
if __name__=='__main__':main()
