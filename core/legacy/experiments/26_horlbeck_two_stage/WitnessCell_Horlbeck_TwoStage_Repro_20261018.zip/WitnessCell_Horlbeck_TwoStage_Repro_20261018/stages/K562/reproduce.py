"""Recompute all three development folds from packaged inputs in a new directory."""
from pathlib import Path
import shutil,subprocess,json,sys,os
ROOT=Path(__file__).resolve().parent
def main():
    dest=ROOT/'reproduction'
    if dest.exists():raise SystemExit('reproduction exists; explicitly choose/remove that output directory before rerunning')
    dest.mkdir();shutil.copytree(ROOT/'core',dest/'core',ignore=shutil.ignore_patterns('__pycache__'))
    for name in ('run_experiment.py','score_all.py','INPUT_PROVENANCE.json'):
        shutil.copy2(ROOT/name,dest/name)
    for fold in (0,1,2):
        case=dest/'cases'/f'outer{fold}';case.mkdir(parents=True)
        shutil.copytree(ROOT/'cases'/f'outer{fold}'/'inputs',case/'inputs')
    plan=json.loads((ROOT/'PLAN.json').read_text())
    plan['new_folds']=[0,1,2]
    plan['reproduction_note']='Execution-only change: recompute all three folds instead of reusing the previously completed smoke fold. All scientific rules and core hashes unchanged.'
    (dest/'PLAN.json').write_text(json.dumps(plan,indent=2))
    env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1')
    for name in ('run_experiment.py','score_all.py'):
        subprocess.run([sys.executable,name],cwd=dest,env=env,check=True)
    original=json.loads((ROOT/'SUMMARY.json').read_text());new=json.loads((dest/'SUMMARY.json').read_text())
    error=max(abs(original['aggregate'][b]['models'][m]['mse_pooled']-new['aggregate'][b]['models'][m]['mse_pooled']) for b in ('low','high') for m in original['aggregate'][b]['models'])
    assert error<1e-12
    check={'full_threefold_entrypoint_passed':True,'maximum_aggregate_mse_difference':error,'reproduction_fit_seconds':json.loads((dest/'FIT_TIMING.json').read_text())['total_new_fit_seconds']}
    (ROOT/'REPRODUCTION_CHECK.json').write_text(json.dumps(check,indent=2))
    print(json.dumps(check))
if __name__=='__main__':main()
