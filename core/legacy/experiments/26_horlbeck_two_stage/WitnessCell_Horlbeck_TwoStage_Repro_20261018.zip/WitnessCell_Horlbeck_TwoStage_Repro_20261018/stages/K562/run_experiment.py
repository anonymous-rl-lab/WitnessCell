"""Complete folds 1/2 with byte-identical final smoke fitting code."""
import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
from pathlib import Path
import sys,json,hashlib,time,datetime
import numpy as np
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'core'))
import run_smoke as runner
def dump(p,x):p.write_text(json.dumps(x,indent=2))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    plan=json.loads((ROOT/'PLAN.json').read_text());start=time.monotonic();deadline=start+plan['new_fit_budget_seconds']
    for name,h in plan['core_sha256'].items():assert sha(ROOT/'core'/name)==h
    provenance=json.loads((ROOT/'INPUT_PROVENANCE.json').read_text())
    for fold in (0,1,2):
        for name,h in provenance['folds'][str(fold)]['input_sha256'].items():assert sha(ROOT/'cases'/f'outer{fold}'/'inputs'/name)==h
    times={}
    try:
        for fold in plan['new_folds']:
            began=time.monotonic();case=ROOT/'cases'/f'outer{fold}';runner.ROOT=case
            with np.load(case/'inputs/training.npz',allow_pickle=False) as z:data={k:z[k] for k in z.files}
            with np.load(case/'inputs/evaluation.npz',allow_pickle=False) as z:query_edges=z['edges'];query_ids=z['global_ids']
            assert not(set(data['global_ids'])&set(query_ids))
            for budget in ('low','high'):
                (case/'results'/budget/'inner_models').mkdir(parents=True,exist_ok=True)
                runner.run_budget(budget,data,query_edges,query_ids,plan,deadline)
            times[str(fold)]=time.monotonic()-began
        paths=[ROOT/'cases'/f'outer{f}'/'results'/b/name for f in (0,1,2) for b in ('low','high') for name in ('predictions.npz','selection.json')]
        dump(ROOT/'PREDICTIONS_LOCKED.json',{'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'new_fold_evaluation_labels_scored':False,'fold0_previously_scored_in_smoke':True,
            'files':{str(p.relative_to(ROOT)):sha(p) for p in paths},'core_sha256':plan['core_sha256'],
            'plan_sha256':sha(ROOT/'PLAN.json'),'input_provenance_sha256':sha(ROOT/'INPUT_PROVENANCE.json'),
            'run_experiment_sha256':sha(Path(__file__))})
    finally:
        dump(ROOT/'FIT_TIMING.json',{'new_fold_seconds':times,'total_new_fit_seconds':time.monotonic()-start,'limit':plan['new_fit_budget_seconds']})
if __name__=='__main__':main()
