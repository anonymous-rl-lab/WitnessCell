"""Score locked three-fold development predictions; sum SSE, project within fold."""
import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
from pathlib import Path
import hashlib,json,datetime
import numpy as np
ROOT=Path(__file__).resolve().parent
METHODS=('M0','M0_repeat_mean','rank1_selected','spectral_selected','rank1_regularized','spectral_regularized')
def dump(p,v):p.write_text(json.dumps(v,indent=2,allow_nan=False))
def metrics(ss,ps,base,pbase,count):
    return {'sse_each':ss.tolist(),'sse_total':float(ss.sum()),'mse_each':(ss/count).tolist(),'mse_pooled':float(ss.sum()/(2*count)),
        'gain_each':(1-ss/base).tolist(),'gain_pooled':float(1-ss.sum()/base.sum()),
        'projected_sse_each':ps.tolist(),'projected_gain_each':(1-ps/pbase).tolist(),'projected_gain_pooled':float(1-ps.sum()/pbase.sum())}
def main():
    lock=json.loads((ROOT/'PREDICTIONS_LOCKED.json').read_text())
    for name,h in lock['files'].items():assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==h
    for name,h in lock['core_sha256'].items():assert hashlib.sha256((ROOT/'core'/name).read_bytes()).hexdigest()==h
    for name,key in [('PLAN.json','plan_sha256'),('INPUT_PROVENANCE.json','input_provenance_sha256'),('run_experiment.py','run_experiment_sha256')]:assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==lock[key]
    result={'utc_scored':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'three-fold K562 development completion; fold0 previously seen in smoke; no Jurkat','folds':{},'aggregate':{}}
    sums={budget:{m:{'sse':np.zeros(2),'psse':np.zeros(2)} for m in METHODS} for budget in ('low','high')}
    joined={budget:{'ids':[],'fold':[],'edges':[],'y':[],**{m:[] for m in METHODS}} for budget in ('low','high')}
    total=0;total_contrasts=0;fit_count=0;converged=0;probes=0
    for fold in (0,1,2):
        case=ROOT/'cases'/f'outer{fold}'
        with np.load(case/'inputs/evaluation.npz',allow_pickle=False) as z:y=z['y'];edges=z['edges'];ids=z['global_ids']
        X=np.zeros((len(edges),80));X[np.arange(len(edges)),edges[:,0]]=1;X[np.arange(len(edges)),edges[:,1]]=1
        U,s,_=np.linalg.svd(X,full_matrices=False);rank=int(np.sum(s>max(X.shape)*np.finfo(float).eps*s[0]));Q=U[:,:rank]
        def project(v):return v-Q@(Q.T@v)
        total+=len(y);total_contrasts+=len(y)-rank
        fr={'evaluation_pairs':len(y),'contrast_dimensions':len(y)-rank,'budgets':{}}
        for budget in ('low','high'):
            out=case/'results'/budget
            with np.load(out/'predictions.npz',allow_pickle=False) as z:pred={k:z[k] for k in z.files}
            assert np.array_equal(pred['edges'],edges) and np.array_equal(pred['global_ids'],ids)
            base=np.sum((y-pred['M0'])**2,axis=0);pbase=np.sum(project(y-pred['M0'])**2,axis=0)
            rows={}
            for name in METHODS:
                error=y-pred[name];ss=np.sum(error**2,axis=0);ps=np.sum(project(error)**2,axis=0)
                rows[name]=metrics(ss,ps,base,pbase,len(y));sums[budget][name]['sse']+=ss;sums[budget][name]['psse']+=ps
                joined[budget][name].append(pred[name])
            cv=json.loads((out/'inner_summary.json').read_text());sel=json.loads((out/'selection.json').read_text());split=json.loads((out/'split.json').read_text())
            nf=sum(len(r['diagnostics']) for r in cv['grid']);nc=sum(int(d['converged']) for r in cv['grid'] for d in r['diagnostics'])
            assert all(p['pass'] for p in cv['objective_probes'])
            fit_count+=nf;converged+=nc;probes+=len(cv['objective_probes'])
            fr['budgets'][budget]={'train_pairs':split['train_count'],'models':rows,'selection':sel,'inner_fit_count':nf,'inner_converged':nc,'objective_order_probes':len(cv['objective_probes'])}
            joined[budget]['ids'].append(ids);joined[budget]['fold'].append(np.full(len(ids),fold));joined[budget]['edges'].append(edges);joined[budget]['y'].append(y)
        result['folds'][str(fold)]=fr
    assert total==632
    for budget in ('low','high'):
        arrays={k:np.concatenate(v,axis=0) for k,v in joined[budget].items()};assert len(set(arrays['ids']))==632
        np.savez_compressed(ROOT/f'predictions_{budget}_all_folds.npz',**arrays)
        base=sums[budget]['M0']['sse'];pbase=sums[budget]['M0']['psse']
        models={m:metrics(sums[budget][m]['sse'],sums[budget][m]['psse'],base,pbase,total) for m in METHODS}
        result['aggregate'][budget]={'models':models,'n_unique_pairs':total,
            'positive_fold_counts':{m:sum(result['folds'][str(f)]['budgets'][budget]['models'][m]['gain_pooled']>0 for f in (0,1,2)) for m in METHODS},
            'positive_repeat_fold_counts':{m:sum(x>0 for f in (0,1,2) for x in result['folds'][str(f)]['budgets'][budget]['models'][m]['gain_each']) for m in METHODS}}
    lo=result['aggregate']['low']['models'];hi=result['aggregate']['high']['models']
    result['density_comparison']={m:{'high_vs_low_gain':1-hi[m]['sse_total']/lo[m]['sse_total']} for m in METHODS}
    result['checks']={'n_unique_pairs':total,'n_repeated_measurements':2*total,'sum_within_fold_contrast_dimensions':total_contrasts,'inner_fit_count':fit_count,'inner_converged':converged,'objective_order_probes_passed':probes,'all_new_fold_predictions_locked_before_scoring':True}
    dump(ROOT/'SUMMARY.json',result)
    print(json.dumps({'aggregate':result['aggregate'],'checks':result['checks'],'density_comparison':result['density_comparison']},indent=2))
if __name__=='__main__':main()
