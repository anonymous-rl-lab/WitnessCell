"""Independent read-only verification of three-fold spectral completion.

Does not import the fitting/scoring code or fit any new model. Reconstructs
saved predictions and objectives from equations, checks CV selection and
within-fold projection, and writes only INDEPENDENT_CHECK.json.
"""
import os
for _key in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS'):
    os.environ[_key] = '1'
from pathlib import Path
import hashlib
import json
import datetime
import numpy as np

ROOT = Path(__file__).resolve().parent
METHODS = ('M0', 'M0_repeat_mean', 'rank1_selected', 'spectral_selected',
           'rank1_regularized', 'spectral_regularized')
failures = []
counts = {}
maximum = {}

def check(condition, label):
    counts['assertions'] = counts.get('assertions', 0) + 1
    if not bool(condition):
        failures.append(label)

def close(actual, expected, label, tolerance=1e-10):
    actual, expected = np.asarray(actual), np.asarray(expected)
    if actual.shape != expected.shape:
        check(False, label + ': shape mismatch')
        return
    err = float(np.max(np.abs(actual-expected))) if actual.size else 0.
    maximum[label.split(':')[0]] = max(maximum.get(label.split(':')[0], 0.), err)
    check(np.isfinite(err) and err <= tolerance, label)

def read(path):
    return json.loads(path.read_text())

def npz(path):
    with np.load(path, allow_pickle=False) as z:
        return {key: z[key] for key in z.files}

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def base_prediction(models, edges, singles):
    """Independent scalar formula, with stored original scaling convention."""
    scales = np.std(singles, axis=0)
    scales[scales == 0] = 1.
    i, j = edges.T
    predictions = []
    for t, model in enumerate(models):
        a = np.asarray(model['a'])
        e, db, dc = [np.asarray(model[key]) for key in ('e', 'd_beta', 'd_c')]
        check(model['rank'] == 0 and model['alpha'] == 10., 'M0 fixed rule')
        close(a, singles[:, t]/scales[t], 'M0 units')
        ag, ah = a[i], a[j]
        y = (model['e0'] + e[i] + e[j] + .5*(ag+ah)
             + .5*((model['beta']+db[i])*ah + (model['beta']+db[j])*ag)
             + .5*((model['c']+dc[i])*ah**2 + (model['c']+dc[j])*ag**2))
        predictions.append(y*scales[t])
    return np.column_stack(predictions)

def objective(G, edges, residual, tau, nu):
    n = len(G)
    r = residual.mean(axis=1)
    return (float(np.mean((r-G[edges[:, 0], edges[:, 1]])**2))
            + tau/n*np.abs(np.linalg.eigvalsh(G)).sum()
            + nu/n**2*np.sum(G**2))

def loss_gradient(G, edges, r, nu):
    g = (2*nu/len(G)**2)*G
    i, j = edges.T
    error = (G[i, j]-r)/len(edges)
    g[i, j] += error
    g[j, i] += error
    return g

def model_check(G, details, edges, residual, family, tau, nu):
    n = len(G)
    close(G, G.T, 'matrix symmetry', 1e-11)
    check(np.isfinite(G).all(), 'finite matrix')
    obj = objective(G, edges, residual, tau, nu)
    close(obj, details['objective'], 'objective reconstruction', 1e-11)
    check(details['converged'] and not details['timed_out'], 'saved convergence')
    check(details['stationarity_relative'] <= 1.00001e-6, 'reported stationarity')
    r = residual.mean(axis=1)
    if family == 'rank1':
        u = np.asarray(details['u'])
        lam = details['lambda']
        close(G, lam*np.outer(u, u), 'rank1 reconstruction', 1e-11)
        close(np.linalg.norm(u), 1., 'rank1 normalization', 1e-10)
        gu = 2*lam*(loss_gradient(G, edges, r, 0.)@u)
        tangent = gu-u*np.dot(u, gu)
        rel = float(np.max(np.abs(tangent))/max(np.mean(r*r), 1e-12))
        maximum['rank1 independent relative gradient'] = max(maximum.get('rank1 independent relative gradient', 0.), rel)
        check(rel <= 1.02e-6, 'rank1 independent tangent gradient')
        prod = u[edges[:, 0]]*u[edges[:, 1]]
        numerator = float(np.mean(r*prod))
        expected_lambda = np.sign(numerator)*max(abs(numerator)-tau/(2*n), 0.)/(float(np.mean(prod**2))+nu/n**2)
        close(lam, expected_lambda, 'rank1 strength optimum', 1e-8)
    else:
        step = 1./(1./len(edges)+2*nu/n**2)
        z = G-step*loss_gradient(G, edges, r, nu)
        vals, vecs = np.linalg.eigh((z+z.T)/2)
        shrunk = np.sign(vals)*np.maximum(np.abs(vals)-step*tau/n, 0.)
        prox = (vecs*shrunk)@vecs.T
        denom = max(float(np.linalg.norm(loss_gradient(np.zeros_like(G), edges, r, 0.))), 1e-12)
        rel = float(np.linalg.norm(G-prox)/(step*denom))
        maximum['spectral independent relative proximal gradient'] = max(maximum.get('spectral independent relative proximal gradient', 0.), rel)
        check(rel <= 1.02e-6, 'spectral independent proximal stationarity')
        close(np.linalg.eigvalsh(G), details['eigenvalues'], 'saved eigenvalues', 1e-10)
    return obj

def correct(G, train_edges, query_edges):
    supported = np.bincount(train_edges.ravel(), minlength=len(G)) > 0
    i, j = query_edges.T
    return np.where(supported[i] & supported[j], G[i, j], 0.)

def summary_metrics(ss, ps, baseline, projected_baseline, n):
    return dict(sse_each=ss.tolist(), sse_total=float(ss.sum()), mse_each=(ss/n).tolist(),
        mse_pooled=float(ss.sum()/(2*n)), gain_each=(1-ss/baseline).tolist(),
        gain_pooled=float(1-ss.sum()/baseline.sum()), projected_sse_each=ps.tolist(),
        projected_gain_each=(1-ps/projected_baseline).tolist(),
        projected_gain_pooled=float(1-ps.sum()/projected_baseline.sum()))

def main():
    plan = read(ROOT/'PLAN.json')
    provenance = read(ROOT/'INPUT_PROVENANCE.json')
    saved_summary = read(ROOT/'SUMMARY.json')
    lock = read(ROOT/'PREDICTIONS_LOCKED.json')
    for filename, value in lock['files'].items():
        check(sha(ROOT/filename) == value, 'locked prediction hash: '+filename)
    for filename, value in lock['core_sha256'].items():
        check(sha(ROOT/'core'/filename) == value, 'locked core hash: '+filename)
        check(value == plan['core_sha256'][filename], 'plan core hash: '+filename)
    for filename, key in [('PLAN.json', 'plan_sha256'), ('INPUT_PROVENANCE.json', 'input_provenance_sha256'), ('run_experiment.py', 'run_experiment_sha256')]:
        check(sha(ROOT/filename) == lock[key], 'locked plan/provenance: '+filename)
    pool, formal = set(provenance['pool_ids']), set(provenance['formal_test_ids'])
    dev = set(provenance['development_global_ids'])
    check(len(pool) == 2528 and len(formal) == 632 and not pool & formal, 'original split disjoint')
    expected_assignment = dict(zip(provenance['development_global_ids'], provenance['development_fold']))
    aggregates = {b:{m:dict(ss=np.zeros(2), ps=np.zeros(2)) for m in METHODS} for b in ('low', 'high')}
    joined = {b:{k:[] for k in ('ids', 'fold', 'edges', 'y', *METHODS)} for b in ('low', 'high')}
    per_fold = {}
    eval_seen = set()
    total_dimensions = 0
    for fold in range(3):
        case = ROOT/'cases'/f'outer{fold}'
        data, evaluation = npz(case/'inputs/training.npz'), npz(case/'inputs/evaluation.npz')
        for filename in ('training.npz', 'evaluation.npz'):
            check(sha(case/'inputs'/filename) == provenance['folds'][str(fold)]['input_sha256'][filename], 'input hash')
        high_ids, low_ids = set(data['global_ids']), set(data['global_ids'][data['low_positions']])
        evaluation_ids = set(evaluation['global_ids'])
        check(len(evaluation_ids) == len(evaluation['global_ids']), 'unique evaluation IDs')
        check(not eval_seen & evaluation_ids, 'nonoverlapping outer evaluation pairs')
        eval_seen |= evaluation_ids
        check(high_ids == pool-evaluation_ids, 'high equals allowed pool minus evaluation')
        check(low_ids == dev-evaluation_ids, 'low equals dev minus evaluation')
        check(low_ids <= high_ids and not high_ids & formal, 'nested budgets and formal exclusion')
        check(not high_ids & evaluation_ids, 'current holdout exclusion')
        check(all(expected_assignment[int(i)] == fold for i in evaluation_ids), 'outer assignment')
        check(len({tuple(sorted(e)) for e in data['edges']}) == len(data['edges']), 'unique training pairs')
        check(len({tuple(sorted(e)) for e in evaluation['edges']}) == len(evaluation['edges']), 'unique evaluation pairs')
        check(not {tuple(sorted(e)) for e in data['edges']} & {tuple(sorted(e)) for e in evaluation['edges']}, 'pair identity exclusion')
        # Independently reproduce content-addressed inner split.
        expected_inner = []
        for i, j in data['edges']:
            pair = sorted([str(data['genes'][i]), str(data['genes'][j])])
            token = 'wc_spectral_smoke_v1|'+'|'.join(pair)
            expected_inner.append(int.from_bytes(hashlib.sha256(token.encode()).digest()[:8], 'big') % 3)
        close(data['inner_fold'], expected_inner, 'inner assignment', 0.)
        y, edges, ids = evaluation['y'], evaluation['edges'], evaluation['global_ids']
        X = np.zeros((len(edges), len(data['genes'])))
        X[np.arange(len(edges)), edges[:, 0]] = 1
        X[np.arange(len(edges)), edges[:, 1]] = 1
        rank = int(np.linalg.matrix_rank(X))
        total_dimensions += len(edges)-rank
        def project(error):
            return error-X@np.linalg.lstsq(X, error, rcond=None)[0]
        per_fold[str(fold)] = {}
        for budget in ('low', 'high'):
            out = case/'results'/budget
            pos = data['low_positions'] if budget == 'low' else np.arange(len(data['edges']))
            train_edges, train_y, folds = data['edges'][pos], data['y'][pos], data['inner_fold'][pos]
            pred = npz(out/'predictions.npz')
            close(pred['edges'], edges, 'prediction edge alignment', 0.)
            close(pred['global_ids'], ids, 'prediction ID alignment', 0.)
            split = read(out/'split.json')
            close(split['train_global_ids'], data['global_ids'][pos], 'recorded training IDs', 0.)
            close(split['inner_fold'], folds, 'recorded inner folds', 0.)
            models = read(out/'M0_models.json')
            baseline = base_prediction(models, edges, data['singles'])
            close(baseline, pred['M0'], 'outer M0 reconstruction', 1e-11)
            close(np.repeat(baseline.mean(axis=1)[:, None], 2, axis=1), pred['M0_repeat_mean'], 'average M0 reconstruction', 1e-11)
            train_residual = train_y-base_prediction(models, train_edges, data['singles'])
            cv, selection = read(out/'inner_summary.json'), read(out/'selection.json')
            base_oof = np.zeros_like(train_y)
            inner_cache = {}
            for f in range(3):
                tr, va = folds != f, folds == f
                bm = read(out/f'inner{f}_baseline.json')
                base_oof[va] = base_prediction(bm, train_edges[va], data['singles'])
                inner_cache[f] = (tr, va, train_y[tr]-base_prediction(bm, train_edges[tr], data['singles']))
            base_ss = np.sum((train_y-base_oof)**2, axis=0)
            close(base_ss, cv['M0_sse'], 'inner M0 SSE', 1e-9)
            independent_rows = []
            obj_by_key = {}
            for row in cv['grid']:
                family, key = row['family'], row['key']
                stored = npz(out/f'{key}_inner_predictions.npz')
                close(stored['y'], train_y, 'inner truth alignment', 0.)
                close(stored['edges'], train_edges, 'inner edge alignment', 0.)
                close(stored['baseline'], base_oof, 'inner baseline reconstruction', 1e-11)
                rebuilt = base_oof.copy()
                for details in row['diagnostics']:
                    f = details['inner_fold']; tr, va, residual = inner_cache[f]
                    G = npz(out/'inner_models'/f'{key}_f{f}.npz')['G']
                    tz = len(G)*np.max(np.abs(np.linalg.eigvalsh(loss_gradient(np.zeros_like(G), train_edges[tr], residual.mean(axis=1), 0.))))
                    close(tz, details['tau_zero'], 'tau zero reconstruction', 1e-11)
                    close(tz*row['fraction'], details['tau'], 'tau scaling', 1e-11)
                    obj_by_key[(family, row['fraction'], row['nu'], f)] = model_check(G, details, train_edges[tr], residual, family, details['tau'], row['nu'])
                    rebuilt[va] += correct(G, train_edges[tr], train_edges[va])[:, None]
                    counts['inner_fits'] = counts.get('inner_fits', 0)+1
                close(rebuilt, stored['pred'], 'inner prediction reconstruction', 1e-11)
                ss = np.sum((train_y-rebuilt)**2, axis=0)
                close(ss, row['sse'], 'inner candidate SSE', 1e-9)
                close(ss.sum(), row['total'], 'inner pooled SSE', 1e-9)
                check(row['eligible'] == all(d['converged'] for d in row['diagnostics']), 'CV eligibility')
                independent_rows.append(dict(key=key, family=family, fraction=row['fraction'], nu=row['nu'], total=float(ss.sum()), eligible=row['eligible']))
            for probe in cv['objective_probes']:
                k = (probe['fraction'], probe['nu'], probe['inner_fold'])
                gap = obj_by_key[('spectral', *k)]-obj_by_key[('rank1', *k)]
                close(gap, probe['spectral_minus_rank1_objective'], 'objective order gap', 1e-11)
                check(gap <= probe['tolerance'] and probe['pass'], 'convex objective order')
                counts['objective_order_probes'] = counts.get('objective_order_probes', 0)+1
            for family in ('rank1', 'spectral'):
                candidates = [r for r in independent_rows if r['family'] == family and r['eligible']]
                best = min(candidates, key=lambda r:(r['total'], -r['fraction'], -r['nu']))
                use = best['total'] < base_ss.sum()-1e-12*max(1., base_ss.sum())
                check(selection[family]['best_regularized'] == best['key'], 'best inner candidate')
                check(selection[family]['selected'] == (best['key'] if use else 'G0'), 'inner-only G0 choice')
                G = pred[family+'_G']; details = read(out/f'{family}_model.json')
                model_check(G, details, train_edges, train_residual, family, details['tau'], details['nu'])
                corrected = baseline+correct(G, train_edges, edges)[:, None]
                close(corrected, pred[family+'_regularized'], 'outer correction reconstruction', 1e-11)
                close(corrected if use else baseline, pred[family+'_selected'], 'outer selection reconstruction', 1e-11)
                counts['outer_refits'] = counts.get('outer_refits', 0)+1
            if budget == 'low':
                for t in range(2):
                    old = ROOT/'references'/'old_M0'/f'real_k562_rep{t+1}_outer{fold}'
                    old_inputs = npz(old/'inputs.npz')
                    close(old_inputs['assessment_edges'], edges, 'old M0 pair alignment', 0.)
                    close(old_inputs['train_edges'], train_edges, 'old M0 training alignment', 0.)
                    # Prior regularization bundle stored scaled predictions.
                    old_scale = float(np.std(data['singles'][:, t]))
                    close(old_inputs['a'], data['singles'][:, t]/old_scale, 'old M0 singles units', 0.)
                    close(old_inputs['assessment_y'], y[:, t]/old_scale, 'old M0 truth units', 0.)
                    close(npz(old/'M0_assessment_predictions.npz')['predictions']*old_scale,
                          pred['M0'][:, t], 'old M0 prediction match', 1e-11)
            ss0 = np.sum((y-baseline)**2, axis=0)
            ps0 = np.sum(project(y-baseline)**2, axis=0)
            fold_metrics = {}
            for method in METHODS:
                error = y-pred[method]
                ss, ps = np.sum(error**2, axis=0), np.sum(project(error)**2, axis=0)
                aggregates[budget][method]['ss'] += ss
                aggregates[budget][method]['ps'] += ps
                values = summary_metrics(ss, ps, ss0, ps0, len(y))
                for key, val in values.items():
                    close(val, saved_summary['folds'][str(fold)]['budgets'][budget]['models'][method][key], 'fold score '+key, 1e-9)
                fold_metrics[method] = values
                joined[budget][method].append(pred[method])
            per_fold[str(fold)][budget] = fold_metrics
            for key, value in [('ids', ids), ('fold', np.full(len(ids), fold)), ('edges', edges), ('y', y)]:
                joined[budget][key].append(value)
    check(eval_seen == dev and len(eval_seen) == 632, 'complete distinct development coverage')
    result_aggregates = {}
    for budget in ('low', 'high'):
        packed = npz(ROOT/f'predictions_{budget}_all_folds.npz')
        for key, items in joined[budget].items():
            close(np.concatenate(items, axis=0), packed[key], 'joined array '+key, 1e-11)
        result_aggregates[budget] = {}
        b = aggregates[budget]['M0']
        for method, numbers in aggregates[budget].items():
            values = summary_metrics(numbers['ss'], numbers['ps'], b['ss'], b['ps'], 632)
            for key, val in values.items():
                close(val, saved_summary['aggregate'][budget]['models'][method][key], 'aggregate score '+key, 1e-9)
            result_aggregates[budget][method] = values
    counts['unique_assessment_pairs'] = len(eval_seen)
    counts['within_fold_contrast_dimensions'] = total_dimensions
    check(counts['inner_fits'] == 288 and counts['objective_order_probes'] == 144, 'expected fit counts')
    for key in ('M0', 'rank1_selected', 'spectral_selected'):
        value = 1-result_aggregates['high'][key]['sse_total']/result_aggregates['low'][key]['sse_total']
        close(value, saved_summary['density_comparison'][key]['high_vs_low_gain'], 'density comparison', 1e-11)
    result = dict(status='PASS' if not failures else 'FAIL', utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        verification='independent formula reconstruction; no fitting; no imports of core or scoring implementation',
        counts=counts, maximum_absolute_discrepancies=maximum, failures=failures,
        aggregate=result_aggregates, per_fold=per_fold,
        limitations=['K562 development analysis; fold 0 previously inspected; not independent confirmation.',
                     'Projection removes free additive endpoints, not every possible common nonlinear baseline.',
                     'This checks current inputs and preserved files; it does not independently certify historical access events.'])
    (ROOT/'INDEPENDENT_CHECK.json').write_text(json.dumps(result, indent=2, allow_nan=False))
    print(json.dumps(dict(status=result['status'], counts=counts, failures=failures, maxima=maximum), indent=2))
    if failures:
        raise SystemExit(1)

if __name__ == '__main__':
    main()
