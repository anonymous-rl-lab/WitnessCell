"""Read-only verification of the compact two-stage reproduction package.

Only NumPy and the standard library are used. No training or network access.
Removed CV matrices are checked against the explicit omission list, not silently
treated as verified. Full CV prediction reconstruction follows a fresh rerun.
"""
import os
for _key in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS'):
    os.environ[_key] = '1'
from pathlib import Path
import argparse
import datetime
import hashlib
import json
import sys
import numpy as np

ROOT = Path(__file__).resolve().parent
COUNTS = {}
FAILURES = []
MAXIMUM = {}


def check(condition, label):
    COUNTS['assertions'] = COUNTS.get('assertions', 0) + 1
    if not bool(condition):
        FAILURES.append(label)


def close(actual, expected, label, tolerance=1e-10):
    a, b = np.asarray(actual), np.asarray(expected)
    check(a.shape == b.shape, label + ': shape')
    if a.shape != b.shape:
        return
    if a.dtype.kind in 'OUS' or b.dtype.kind in 'OUS':
        check(np.array_equal(a, b), label)
        return
    err = float(np.max(np.abs(a-b))) if a.size else 0.
    MAXIMUM[label.split(':')[0]] = max(MAXIMUM.get(label.split(':')[0], 0.), err)
    check(np.isfinite(err) and err <= tolerance, label)


def read(p):
    return json.loads(p.read_text())


def npz(p):
    with np.load(p, allow_pickle=False) as z:
        return {k: z[k] for k in z.files}


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def check_hashes(base, entries, omitted=None):
    omitted = omitted or {}
    for name, value in entries.items():
        expected = value if isinstance(value, str) else value['sha256']
        p = base/name
        if p.is_file():
            check(sha(p) == expected, 'retained file hash: ' + str(p.relative_to(ROOT)))
            COUNTS['retained_hash_checks'] = COUNTS.get('retained_hash_checks', 0)+1
            if isinstance(value, dict) and 'bytes' in value:
                check(p.stat().st_size == value['bytes'], 'retained file size: '+name)
        else:
            check(name in omitted, 'unexplained missing file: '+name)
            if name in omitted:
                check(expected == omitted[name]['sha256'], 'omitted source hash: '+name)
                COUNTS['documented_omission_references'] = COUNTS.get('documented_omission_references', 0)+1


def source_integrity():
    for source in read(ROOT/'SOURCE_ARCHIVES.json')['source_archives']:
        base = ROOT/'stages'/source['stage']
        omitted = {x['path']: x for x in source['omitted_files']}
        check(len(omitted) == len(source['omitted_files']), 'unique omission paths')
        for name in omitted:
            check('inner_models' in Path(name).parts or name.endswith('_inner_predictions.npz'), 'only regenerable CV arrays omitted')
            check(not (base/name).exists(), 'omission declaration matches absence')
        for name in ('ORIGINAL_MANIFEST.json', 'ORIGINAL_PACKAGE_MANIFEST.json'):
            if (base/name).exists():
                manifest = read(base/name)
                check_hashes(base, manifest.get('files', manifest), omitted)
        lock = read(base/'PREDICTIONS_LOCKED.json')
        check_hashes(base, lock['files'], omitted)
        plan = read(base/'PLAN.json')
        check_hashes(base/'core', plan['core_sha256'])
        if source['stage'] == 'Jurkat':
            freeze = read(base/'FREEZE.json')
            check_hashes(base, freeze['files'])
            check(sha(base/'FREEZE.json') == lock['freeze_sha256'], 'Jurkat freeze chain')
            check(sha(base/'INPUT_PROVENANCE.json') == lock['input_provenance_sha256'], 'Jurkat input chain')
            check_hashes(base, read(base/'INPUT_PROVENANCE.json')['file_sha256'])
        else:
            for name, key in [('PLAN.json', 'plan_sha256'), ('INPUT_PROVENANCE.json', 'input_provenance_sha256'), ('run_experiment.py', 'run_experiment_sha256')]:
                check(sha(base/name) == lock[key], 'K562 protocol chain '+name)


def baseline(models, edges, singles):
    scale = np.std(singles, axis=0)
    scale[scale == 0] = 1.
    i, j = edges.T
    columns = []
    for t, model in enumerate(models):
        check(model['rank'] == 0 and model['alpha'] == 10., 'fixed M0 rule')
        a, e, db, dc = [np.asarray(model[k]) for k in ('a', 'e', 'd_beta', 'd_c')]
        close(a, singles[:, t]/scale[t], 'M0 normalization')
        ag, ah = a[i], a[j]
        z = (model['e0'] + e[i]+e[j]+.5*(ag+ah)
             + .5*((model['beta']+db[i])*ah+(model['beta']+db[j])*ag)
             + .5*((model['c']+dc[i])*ah**2+(model['c']+dc[j])*ag**2))
        columns.append(z*scale[t])
    return np.column_stack(columns)


def fit_outputs(data, edges, ids, out, budget):
    train = data['edges'][data['low_positions']] if budget == 'low' else data['edges']
    p = npz(out/'predictions.npz')
    close(p['edges'], edges, 'prediction edge alignment', 0.)
    close(p['global_ids'], ids, 'prediction ID alignment', 0.)
    models = read(out/'M0_models.json')
    b = baseline(models, edges, data['singles'])
    close(b, p['M0'], 'final M0 reconstruction')
    close(p['M0_repeat_mean'], np.repeat(b.mean(axis=1)[:, None], 2, axis=1), 'repeat mean reconstruction')
    cv, selection = read(out/'inner_summary.json'), read(out/'selection.json')
    check(len(cv['grid']) == 16, 'complete two-family grid')
    check(all(x['pass'] for x in cv['objective_probes']), 'saved objective order probes')
    base_sse = np.asarray(cv['M0_sse'])
    for row in cv['grid']:
        close(sum(row['sse']), row['total'], 'inner pooled SSE')
        close(1-np.asarray(row['sse'])/base_sse, row['gain_each'], 'inner gains')
        check(len(row['diagnostics']) == 3, 'three inner validation folds')
    supported = np.bincount(train.ravel(), minlength=len(data['genes'])) > 0
    for family in ('rank1', 'spectral'):
        best = min((r for r in cv['grid'] if r['family'] == family and r['eligible']), key=lambda r: (r['total'], -r['fraction'], -r['nu']))
        use = best['total'] < base_sse.sum()-1e-12*max(1., base_sse.sum())
        check(selection[family]['best_regularized'] == best['key'], 'inner-only best regularized choice')
        check(selection[family]['selected'] == (best['key'] if use else 'G0'), 'inner-only G0 selection')
        G = p[family+'_G']
        details = read(out/(family+'_model.json'))
        close(G, G.T, 'symmetric final correction')
        check(details['converged'] and selection[family]['final_converged'], 'final convergence recorded')
        if family == 'rank1':
            u = np.asarray(details['u'])
            close(G, details['lambda']*np.outer(u, u), 'rank-one matrix reconstruction')
            close(np.linalg.norm(u), 1., 'rank-one scale')
        else:
            close(np.linalg.eigvalsh(G), details['eigenvalues'], 'spectral eigenvalues')
        correction = np.where(supported[edges[:, 0]] & supported[edges[:, 1]], G[edges[:, 0], edges[:, 1]], 0.)
        close(b+correction[:, None], p[family+'_regularized'], 'final regularized prediction')
        close(b+correction[:, None] if use else b, p[family+'_selected'], 'final selected prediction')
    COUNTS['final_budget_models'] = COUNTS.get('final_budget_models', 0)+2
    return p


def scores(y, edges, predictions, n):
    X = np.zeros((len(edges), n))
    X[np.arange(len(edges)), edges[:, 0]] = 1
    X[np.arange(len(edges)), edges[:, 1]] = 1
    U, s, _ = np.linalg.svd(X, full_matrices=False)
    rank = int(np.sum(s > max(X.shape)*np.finfo(float).eps*s[0]))
    Q = U[:, :rank]
    result = {}
    for name, pred in predictions.items():
        err = y-pred
        result[name] = (np.sum(err*err, axis=0), np.sum((err-Q@(Q.T@err))**2, axis=0))
    return result, len(edges)-rank


def check_score(ss, ps, base, pbase, n, saved):
    values = dict(sse_each=ss, mse_each=ss/n, mse_pooled=ss.sum()/(2*n), gain_each=1-ss/base,
                  gain_pooled=1-ss.sum()/base.sum(), projected_sse_each=ps,
                  projected_gain_each=1-ps/pbase, projected_gain_pooled=1-ps.sum()/pbase.sum())
    for key, value in values.items():
        close(value, saved[key], 'score reconstruction: '+key, 1e-9)


def check_inner_assignment(data):
    folds = []
    for i, j in data['edges']:
        names = sorted([str(data['genes'][i]), str(data['genes'][j])])
        folds.append(int.from_bytes(hashlib.sha256(('wc_spectral_smoke_v1|'+'|'.join(names)).encode()).digest()[:8], 'big') % 3)
    close(data['inner_fold'], folds, 'content-defined inner folds', 0.)


def k562():
    root = ROOT/'stages/K562'
    prov, summary = read(root/'INPUT_PROVENANCE.json'), read(root/'SUMMARY.json')
    pool, formal, dev = [set(prov[k]) for k in ('pool_ids', 'formal_test_ids', 'development_global_ids')]
    check(len(pool) == 2528 and len(formal) == len(dev) == 632 and not pool & formal, 'K562 original pool separation')
    methods = tuple(summary['aggregate']['high']['models'])
    totals = {b: {m: [np.zeros(2), np.zeros(2)] for m in methods} for b in ('low', 'high')}
    seen, dimensions = set(), 0
    for fold in range(3):
        case = root/'cases'/('outer'+str(fold))
        data, truth = npz(case/'inputs/training.npz'), npz(case/'inputs/evaluation.npz')
        for name, expected in prov['folds'][str(fold)]['input_sha256'].items():
            check(sha(case/'inputs'/name) == expected, 'K562 input digest')
        high, low, test = set(data['global_ids']), set(data['global_ids'][data['low_positions']]), set(truth['global_ids'])
        check(high == pool-test and low == dev-test and low <= high and not high & formal, 'K562 nested budgets and exclusion')
        check(not seen & test, 'K562 disjoint evaluation folds')
        seen |= test
        check(not set(map(tuple, data['edges'])) & set(map(tuple, truth['edges'])), 'K562 training/query pair exclusion')
        check_inner_assignment(data)
        for budget in ('low', 'high'):
            p = fit_outputs(data, truth['edges'], truth['global_ids'], case/'results'/budget, budget)
            sc, d = scores(truth['y'], truth['edges'], {m:p[m] for m in methods}, len(data['genes']))
            if budget == 'low': dimensions += d
            for m, (ss, ps) in sc.items():
                check_score(ss, ps, *sc['M0'], len(truth['y']), summary['folds'][str(fold)]['budgets'][budget]['models'][m])
                totals[budget][m][0] += ss; totals[budget][m][1] += ps
    check(seen == dev, 'K562 all 632 unique evaluation pairs')
    check(dimensions == summary['checks']['sum_within_fold_contrast_dimensions'], 'K562 projection dimensions')
    for budget in totals:
        for m, (ss, ps) in totals[budget].items():
            check_score(ss, ps, *totals[budget]['M0'], 632, summary['aggregate'][budget]['models'][m])
    return {b: {m:summary['aggregate'][b]['models'][m]['gain_pooled'] for m in ('rank1_selected', 'spectral_selected')} for b in totals}


def jurkat():
    root = ROOT/'stages/Jurkat'
    data, query, truth = [npz(root/p) for p in ('inputs/training.npz', 'inputs/query.npz', 'sealed/evaluation_truth.npz')]
    plan, summary = read(root/'PLAN.json'), read(root/'SUMMARY.json')
    genes = read(root/'protocol/genes.json')
    check(len(genes) == len(data['genes']) == 79, 'Jurkat 79 genes')
    close(data['genes'], genes, 'Jurkat gene identities')
    original = read(root/'protocol/original_k562_80genes.json')
    close(genes, [g for g in original if g != 'GINS4'], 'only GINS4 excluded for availability')
    check(set(query) == {'edges', 'global_ids'}, 'Jurkat trainer query has no outcomes')
    for key in query: close(query[key], truth[key], 'Jurkat query/truth alignment')
    train, test = set(map(str, data['global_ids'])), set(map(str, query['global_ids']))
    check(len(train) == 2464 and len(test) == 617 and not train & test, 'Jurkat training/test identity exclusion')
    check(not set(map(tuple, data['edges'])) & set(map(tuple, truth['edges'])), 'Jurkat pair exclusion')
    salt = plan['outer_split']['salt']
    ordered = sorted(train|test, key=lambda s:(hashlib.sha256((salt+'|pair|'+s).encode()).hexdigest(), s))
    check(set(ordered[:617]) == test, 'Jurkat frozen outer split')
    check_inner_assignment(data)
    p = fit_outputs(data, query['edges'], query['global_ids'], root/'results/high', 'high')
    methods = tuple(summary['models'])
    sc, d = scores(truth['y'], truth['edges'], {m:p[m] for m in methods}, 79)
    check(d == summary['test_contrast_dimension'], 'Jurkat projection dimension')
    loss = {m:(truth['y']-p[m])**2 for m in methods}
    draws = npz(root/'results/node_reweighting_draws.npz')
    spec = plan['uncertainty']; rng = np.random.default_rng(spec['seed'])
    regenerated = {m:[] for m in methods}; attempts = 0
    while len(regenerated['M0']) < spec['draws'] and attempts < spec['max_attempts']:
        attempts += 1
        freq = rng.multinomial(79, np.repeat(1/79, 79))
        w = freq[truth['edges'][:, 0]]*freq[truth['edges'][:, 1]]
        denominator = float(w@loss['M0'].sum(axis=1))
        if denominator <= 0: continue
        for m in methods: regenerated[m].append(float(1-(w@loss[m].sum(axis=1))/denominator))
    check(attempts == summary['bootstrap_attempts'], 'Jurkat reweighting attempts')
    for m, (ss, ps) in sc.items():
        row = summary['models'][m]
        check_score(ss, ps, *sc['M0'], 617, row)
        close(draws[m], regenerated[m], 'Jurkat exact reweighting draws', 1e-12)
        check(len(draws[m]) == spec['draws'], 'Jurkat draw count')
        close(np.quantile(draws[m], spec['quantiles']), row['node_reweighting_95_interval'], 'Jurkat interval reconstruction')
        deletion = []
        for g in range(79):
            keep = np.all(truth['edges'] != g, axis=1)
            deletion.append(1-loss[m][keep].sum()/loss['M0'][keep].sum())
        close(deletion, row['delete_one_gene_gain'], 'Jurkat 79 node-deletion sensitivities')
        check(sum(v > 0 for v in deletion) == row['delete_one_gene_positive'], 'Jurkat node-deletion positive count')
    primary = summary['models']['rank1_selected']
    direction = primary['gain_pooled'] > 0 and all(v > 0 for v in primary['gain_each'])
    check(direction == summary['primary_decision']['direction_replication'], 'Jurkat primary direction decision')
    check((direction and primary['node_reweighting_95_interval'][0] > 0) == summary['primary_decision']['conditional_interval_support'], 'Jurkat conditional interval decision')
    return {m:summary['models'][m]['gain_pooled'] for m in ('rank1_selected', 'spectral_selected')}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, help='Optional new JSON output path; otherwise stdout only')
    args = parser.parse_args()
    manifest_present = (ROOT/'PACKAGE_MANIFEST.json').exists()
    if manifest_present:
        manifest = read(ROOT/'PACKAGE_MANIFEST.json')
        check_hashes(ROOT, manifest.get('files', manifest))
    source_integrity()
    results = {'K562': k562(), 'Jurkat': jurkat()}
    report = dict(status='PASS' if not FAILURES else 'FAIL', utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  package_manifest_checked=manifest_present, counts=COUNTS, maximum_absolute_discrepancies=MAXIMUM,
                  gains=results, failures=FAILURES,
                  scope='Read-only retained-file integrity, final-model reconstruction, fixed split/selection checks, score and Jurkat reweighting reproduction; no retraining.',
                  limitation='Omitted CV fitted matrices and candidate arrays are recorded, not numerically reverified here. Run reproduce.py for full regeneration and original independent verification. Historical timestamps are records, not an independent guarantee of past data access.')
    rendered = json.dumps(report, indent=2, allow_nan=False)
    if args.out:
        target = args.out.resolve()
        if target.exists(): raise RuntimeError('Choose a new --out path; verification never overwrites existing files')
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(rendered+'\n')
    print(rendered)
    return 1 if FAILURES else 0


if __name__ == '__main__':
    sys.exit(main())
