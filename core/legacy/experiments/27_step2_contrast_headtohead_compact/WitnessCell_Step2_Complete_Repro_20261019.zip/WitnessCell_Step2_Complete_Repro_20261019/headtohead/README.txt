WitnessCell 第二步：55 组合 RNA 同台比较的精简精准复算模块

一、一次运行
  python reproduce.py --output reproduced
依赖：Python 3.9+、NumPy。运行不安装环境、不访问网络、不训练神经网络。
输出三套 FINAL_PK_TABLE、ALL_SEED_METRICS、逐折/逐矩形评分、M1/R 全部 4,995 基因收益、矩形胜出次数及 REPRODUCTION_CHECK.json。
包含原始尺度、训练组合方差标准化、固定十个基因剔除三个版本；所有方法、三个神经模型种子均保留。M0/M1/R 是固定输出，不把它们重复计成三个独立实验。

二、精简保存的是什么
loss_blocks_float64.npz 由原始真值和模型预测直接计算，未使用结果表反推：
  • 各折、模型、尺度的完整响应平方误差与端点投影平方误差；
  • 每个留出矩形的平方误差；
  • 相同权重下真实矩形及投影能量；
  • 固定 32 基因连续分组的未量化 float64 求和贡献；
  • M1、R 每折全部 4,995 个基因的原尺度收益，逐基因完整保留；
  • 完整基因 ID、固定剔除掩码、各折训练方差和权重、关联矩阵及矩形算子。
每个尺度先按原定义逐坐标乘权重，再分组；不能把一个尺度的结果换权重冒充另一个尺度。
reproduce.py 从这些细粒度贡献重算各项指标及排名，再对照 expected/ 中的原表；expected/ 只用于验证，不参与计算。
全部 378 个核心数值及 864 个主表数值一致，最大绝对差约 2.84e-14，仅为 float64 求和顺序误差。没有降低精度或量化。
reference_means.npz 原样保存原始评分输入中 70 条件 × 4,995 非靶基因的均值，用于独立核对真值和重算训练方差。

三、原始逐预测复算（使用既有原始结果 ZIP，不重复打入 v22）
先解压 WitnessCell_HeadToHead_Results_20261018T193222.zip。将参数指向含 formal_runs/ 的目录：
  python rescore_from_predictions.py --results-dir /path/to/extracted/results --output raw_reproduced
该入口直接读取原始 aligned NPZ 中七种方法的预测和真值，使用 reference_means 独立核对真值、重算训练方差，并再对照 30 份未对齐的 GEARS/scouter 原预测 NPZ。M0/M1/R 的完整预测已包含在 aligned NPZ 中。30 份原神经预测及 15 份 aligned 文件的 SHA-256 与来源记录一致。
原始结果 ZIP 没有历史 evaluation_only.npz 或 m1_r/fold_*/PREDICTIONS.npz；它们的评分所需均值和最终预测已由上述资产完整覆盖。原始预测重算也核对 378+864 个值，全部 4,995 基因的收益逐元素一致。

四、训练溯源与边界
training_source/ 包含 M0/M1/R、GEARS 0.1.2 上游与运行代码、scouter 上游与运行代码、评分和种子汇总代码。
training_trace/ 保留三种子 × 五折 × 两神经模型的 30 份正式训练完成记录、完整 epoch 历史、选模设置、运行身份；不混入 smoke。
设计、划分、固定十基因名单、依赖列表及来源身份保留在 design/、SOURCE_FILES.json 等。
小包精准复现的是已完成实验的评分、比较和诊断，不是重新训练，也不是从平方误差还原有符号预测。重训仍需要原训练 cells.h5、GO 资源、GenePT 嵌入及对应软件环境；这些大资产不因小包存在而被宣称已经包含。原结果包也未保存全部最终模型权重。参考 training_source 和来源记录获取原训练输入。
extract_from_original_vectors.py 可从完整原始 run+original 输入重新生成 float64 贡献，参数为 --run、--original、--output。

五、科学范围
55 个组合、五折、11 个共享端点的矩形、15 个逐折端点消去维度；三个种子测量优化变化，不能作为独立生物重复。该面板是多轮方法开发数据；它与 12 个发布划分不是同一个测试集，不混合排名。
R 的矩形误差较 M0 改善 15.96%，较 GEARS 均值改善 10.81%；其前十基因占全部正收益约 92.13%。标准化或剔除十基因后，相对 M0 的矩形收益基本消失，这些结果全部保留。
GEARS/scouter 与固定 M1/R 的内层选模预算不同，原始协议和选择历史完整保留。scouter 两个种子 fold0 的早期 checkpoint 主导其完整响应误差，因此不能由该成绩推断其所有设置的能力上限。
