#!/usr/bin/env python3
"""Extract non-quantized loss sufficient statistics FROM original prediction and truth arrays.
Not a table copy. Full vectors remain in the original archives. See README.
"""
import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
from pathlib import Path
import numpy as np,json,hashlib,itertools,argparse,shutil
p=argparse.ArgumentParser();p.add_argument('--run',type=Path,required=True);p.add_argument('--original',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
RUN=a.run;ORIG=a.original;OUT=a.output;OUT.mkdir(parents=True,exist_ok=True)
sha=lambda x:hashlib.sha256(Path(x).read_bytes()).hexdigest()
source=[]
def record(path,role):
 source.append(dict(role=role,path=str(path),bytes=path.stat().st_size,sha256=sha(path)))
def cp(path,rel):
 dest=OUT/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(path,dest);record(path,str(rel))
roles=json.loads((RUN/'data/common_roles.json').read_text());drop=json.loads((RUN/'scoring/DROP10_FIXED.json').read_text())['genes']
with np.load(ORIG/'data/evaluation_only.npz',allow_pickle=False) as z:
 cs=list(z['conditions'].astype(str));original_mask=z['score_gene_mask'];genes=z['genes'][original_mask].astype(str);means=z['means'][:,original_mask];ctrl=means[cs.index('control')]
record(ORIG/'data/evaluation_only.npz','original evaluation source')
np.savez_compressed(OUT/'reference_means.npz',conditions=np.array(cs),genes=genes,means=means,original_gene_mask=original_mask)
models=['additive','saturation_only','M0','M1','R','GEARS','scouter'];instances=[(m,0) for m in models[:5]]+[(m,s) for m in models[5:] for s in range(3)]
variants=['raw','training_condition_variance','drop_fixed_top10'];groups=[(i,min(i+32,len(genes))) for i in range(0,len(genes),32)]
arrays={'genes':genes,'original_score_gene_mask':original_mask,'fixed_drop10_mask':np.isin(genes,drop),'group_bounds':np.array(groups)};geometry=[]
def grouped(v):
 return np.array([np.sum(v[...,lo:hi],dtype=np.float64) for lo,hi in groups],dtype=np.float64)
def loadpred(path,key,conds,absmean=False):
 with np.load(path,allow_pickle=False) as z:
  c=list(z['conditions'].astype(str));g=list(z['genes'].astype(str));assert set(c)==set(conds)
  pred=z[key][[c.index(q) for q in conds]][:,[g.index(q) for q in genes]].astype(np.float64)
 return pred-ctrl if absmean else pred
for f in roles['folds']:
 fi=f['fold'];conds=f['test_conditions'];y=means[[cs.index(c) for c in conds]]-ctrl
 nodes=sorted({g for c in conds for g in c.split('+')});X=np.array([[int(g in c.split('+')) for g in nodes] for c in conds],float)
 C=[]
 for block in f['test_rectangle_blocks']:
  idx=[conds.index(q) for q in block];valid=[]
  for v in itertools.product((-1.,1.),repeat=3):
   v=np.array((1.,)+v)
   if np.max(np.abs(v@X[idx]))==0:valid.append(v)
  assert len(valid)==1
  row=np.zeros(len(conds));row[idx]=valid[0];C.append(row)
 C=np.array(C);cy=C@y
 def projected(z):return z-X@np.linalg.lstsq(X,z,rcond=None)[0]
 py=projected(y);tr=[cs.index(c) for c in f['outer_train_conditions'] if '+' in c]
 var=np.var(means[tr],axis=0,ddof=1);floor=np.quantile(var[var>0],.01);stdw=1/np.maximum(var,floor)
 arrays[f'fold{fi}_X']=X;arrays[f'fold{fi}_C']=C;arrays[f'fold{fi}_training_variance']=var;arrays[f'fold{fi}_standardization_weight']=stdw
 meta=dict(fold=fi,conditions=conds,nodes=nodes,rectangles=f['test_rectangle_blocks'],contrast_dimension=int(len(conds)-np.linalg.matrix_rank(X)),variance_floor=float(floor));geometry.append(meta)
 orig=ORIG/f'm1_r/fold_{fi}/PREDICTIONS.npz';record(orig,'deterministic original predictions')
 baseerr=None
 for ix,(m,s) in enumerate(instances):
  if m in models[:5]:pred=loadpred(orig,f'pred_effect_{m}',conds)
  else:
   path=RUN/(f'formal_runs/seed_{s}/GEARS/fold_{fi}/refit/predictions.npz' if m=='GEARS' else f'formal_runs/seed_{s}/scouter/fold_{fi}/prediction.npz')
   record(path,f'{m} seed{s} fold{fi} original predictions');pred=loadpred(path,'pred_mean_'+m,conds,True)
  err=pred-y;ce=C@err;pe=projected(err)
  if m=='M0':baseerr=ce**2
  if m in ('M1','R'):arrays[f'fold{fi}_{m}_gene_C_SSE_gain']=np.sum(baseerr-ce**2,axis=0)
  for vi,v in enumerate(variants):
   w=stdw if vi==1 else (~np.isin(genes,drop)).astype(float) if vi==2 else np.ones(len(genes))
   prefix=f'f{fi}_i{ix}_v{vi}'
   arrays[prefix+'_response_blocks']=grouped(err**2*w)
   arrays[prefix+'_projection_blocks']=grouped(pe**2*w)
   arrays[prefix+'_rectangle_blocks']=np.array([grouped(c**2*w) for c in ce])
   if ix==0:
    arrays[f'f{fi}_v{vi}_C_truth_blocks']=grouped(cy**2*w)
    arrays[f'f{fi}_v{vi}_projection_truth_blocks']=grouped(py**2*w)
np.savez_compressed(OUT/'loss_blocks_float64.npz',**arrays)
(OUT/'geometry.json').write_text(json.dumps(dict(instances=instances,variants=variants,geometry=geometry,genes=len(genes),group_size=32),indent=2)+'\n')
# Fixed design, expectations, provenance: expectations are checked only after independent calculation.
for rel in ('data/common_roles.json','data/selection_validation_geometry.json','data/inference_controls.json','protocol.json','scoring/DROP10_FIXED.json','runtime/requirements.formal.txt'):
 cp(RUN/rel,Path('design')/rel)
for s in range(3):
 cp(RUN/f'formal_runs/seed_{s}/scores/SUMMARY_TABLE.csv',f'expected/seed_{s}_SUMMARY_TABLE.csv')
 for fi in range(5):record(RUN/f'formal_runs/seed_{s}/scores/fold_{fi}_aligned.npz','complete aligned original predictions')
 for rel in ('SEED_COMPLETE.json','scores/SUMMARY.json'):cp(RUN/f'formal_runs/seed_{s}'/rel,Path('training_trace')/f'seed_{s}'/rel)
for rel in (RUN/'formal_runs/final_summary').glob('*.csv'):cp(rel,Path('expected')/rel.name)
# All three seed x five fold final training identities, selections and epoch logs; exclude smoke and heavy arrays.
for s in range(3):
 for m in ('GEARS','scouter'):
  for f in range(5):
   root=RUN/f'formal_runs/seed_{s}/{m}/fold_{f}'
   for path in root.rglob('*.json'):
    if 'string_fix_originals' not in path.parts:cp(path,Path('training_trace')/path.relative_to(RUN/'formal_runs'))
# Original methods and upstream source (no environments, binaries, notebook/image demos or large data).
for rel in ('code','gears','scouter','m1_r'):
 for path in (ORIG/rel).rglob('*'):
  if path.is_file() and (path.suffix=='.py' or path.name in ('LICENSE','README.md')) and not any(x in path.parts for x in ('__pycache__','runs','results','demo')):
   cp(path,Path('training_source')/path.relative_to(ORIG))
for rel in ('run_formal.py','package_results.py','scoring/score_head_to_head.py','scoring/summarize_seeds.py'):
 cp(RUN/rel,Path('training_source')/rel)
for rel in ('m1_r/REPRODUCTION.json','m1_r/SOURCE_HISTORY.json','gears/cache/graph_identity.json','gears/assets/go_graph_reconstruction.json','gears/assets/archive_asset_provenance.json','scouter/PROVENANCE.json','scouter/assets/embedding_subset.json'):
 if (ORIG/rel).exists():cp(ORIG/rel,Path('training_source')/rel)
for f in range(5):cp(ORIG/f'm1_r/fold_{f}/FIT.json',f'training_trace/deterministic/fold_{f}/FIT.json')
(OUT/'SOURCE_FILES.json').write_text(json.dumps(source,indent=2)+'\n')
print(json.dumps({'bytes_float64_statistics':(OUT/'loss_blocks_float64.npz').stat().st_size,'source_files':len(source),'all_statistics_from_original_vectors':True}))
