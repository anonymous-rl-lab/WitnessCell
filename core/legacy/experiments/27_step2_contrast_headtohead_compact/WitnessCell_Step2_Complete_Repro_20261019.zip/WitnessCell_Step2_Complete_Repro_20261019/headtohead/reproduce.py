#!/usr/bin/env python3
"""Recompute all reported scores from float64 block-level loss contributions; NumPy only."""
import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
import argparse,csv,json
from pathlib import Path
import numpy as np
MODELS=['additive','saturation_only','M0','M1','R','GEARS','scouter']
VARIANTS=['raw','training_condition_variance','drop_fixed_top10']
METRICS=['C_MSE','C_ratio_vs_additive','C_ratio_vs_M0','C_gain_over_M0','response_MSE','response_ratio_vs_additive','response_ratio_vs_M0','response_gain_over_M0','projection_ratio']
ROOT=Path(__file__).resolve().parent

def readcsv(p):
 with Path(p).open(newline='') as f:return list(csv.DictReader(f))
def writecsv(p,rows):
 with Path(p).open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def summarize(rows):
 out=[]
 for s in range(3):
  for v in VARIANTS:
   def vals(m):return [r for r in rows if r['seed']==s and r['variant']==v and r['model']==m]
   b=vals('M0');a=vals('additive')
   for m in MODELS:
    d=vals(m);csse=sum(r['C_SSE'] for r in d);rsse=sum(r['response_SSE'] for r in d);psse=sum(r['projection_SSE'] for r in d)
    cr=csse/sum(r['C_SSE'] for r in b);rr=rsse/sum(r['response_SSE'] for r in b)
    out.append(dict(seed=s,variant=v,model=m,C_MSE=csse/sum(r['rectangles']*r['genes'] for r in d),C_ratio_vs_additive=csse/sum(r['C_truth_energy'] for r in d),C_ratio_vs_M0=cr,C_gain_over_M0=1-cr,response_MSE=rsse/sum(r['conditions']*r['genes'] for r in d),response_ratio_vs_additive=rsse/sum(r['response_SSE'] for r in a),response_ratio_vs_M0=rr,response_gain_over_M0=1-rr,projection_ratio=psse/sum(r['projection_truth_energy'] for r in d)))
 return out

def tables(agg,out):
 seeds=[];names=['FINAL_PK_TABLE.csv','FINAL_PK_TABLE_STANDARDIZED.csv','FINAL_PK_TABLE_DROP10.csv']
 for v,name in zip(VARIANTS,names):
  rows=[]
  for m in MODELS:
   ss=[0] if m in MODELS[:5] else [0,1,2];d=[r for r in agg if r['variant']==v and r['model']==m and r['seed'] in ss]
   row=dict(model=m,variant=v,status='COMPLETE',realization_count=len(ss),realization_type='one_fixed_deterministic_output' if len(ss)==1 else 'three_optimization_seeds',conditions=55,rectangles=11,contrast_dimension=15,genes=4985 if v==VARIANTS[2] else 4995)
   for metric in METRICS:
    x=[r[metric] for r in d];row.update({metric+'_mean':sum(x)/len(x),metric+'_min':min(x),metric+'_max':max(x)})
   row['range_interpretation']='No stochastic repeats' if len(ss)==1 else 'Optimization-seed range; not biological confidence interval';rows.append(row)
   for r in d:seeds.append(dict(model=m,variant=v,optimization_seed='fixed' if len(ss)==1 else r['seed'],**{k:r[k] for k in METRICS}))
  writecsv(out/name,rows)
 writecsv(out/'ALL_SEED_METRICS.csv',seeds)

def check(agg,out):
 differences=[]
 keys=['C_MSE','response_MSE','projection_ratio','C_ratio_vs_additive','C_gain_over_M0','response_gain_over_M0']
 for s in range(3):
  expected={(r['variant'],r['model']):r for r in readcsv(ROOT/f'expected/seed_{s}_SUMMARY_TABLE.csv')}
  for r in agg:
   if r['seed']!=s:continue
   for k in keys:differences.append(abs(r[k]-float(expected[r['variant'],r['model']][k])))
 tablediff=[]
 for name in ['FINAL_PK_TABLE.csv','FINAL_PK_TABLE_STANDARDIZED.csv','FINAL_PK_TABLE_DROP10.csv','ALL_SEED_METRICS.csv']:
  actual=readcsv(out/name);expected=readcsv(ROOT/'expected'/name);assert len(actual)==len(expected)
  for a,b in zip(actual,expected):
   assert a['model']==b['model'] and a['variant']==b['variant']
   for k in METRICS:
    for col in ([k] if name=='ALL_SEED_METRICS.csv' else [k+'_mean',k+'_min',k+'_max']):tablediff.append(abs(float(a[col])-float(b[col])))
 maxdiff=max(differences+tablediff);return dict(passed=bool(maxdiff<1e-10),comparisons=len(differences),additional_table_comparisons=len(tablediff),max_abs_diff=maxdiff,precision='Original float64; no quantization. Grouping can alter the final sum only by roundoff.')

def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--output',type=Path,default=ROOT/'reproduced');args=ap.parse_args();out=args.output;out.mkdir(parents=True,exist_ok=True)
 meta=json.loads((ROOT/'geometry.json').read_text());z=np.load(ROOT/'loss_blocks_float64.npz',allow_pickle=False);ixmap={(m,s):i for i,(m,s) in enumerate(meta['instances'])};rows=[];rect=[]
 for s in range(3):
  for f in meta['geometry']:
   fi=f['fold']
   for vi,v in enumerate(VARIANTS):
    ng=4985 if vi==2 else 4995
    for m in MODELS:
     ix=ixmap[m,0 if m in MODELS[:5] else s];p=f'f{fi}_i{ix}_v{vi}';ce=z[p+'_rectangle_blocks']
     rows.append(dict(seed=s,fold=fi,variant=v,model=m,conditions=len(f['conditions']),genes=ng,rectangles=len(f['rectangles']),contrast_dimension=f['contrast_dimension'],response_SSE=float(z[p+'_response_blocks'].sum()),C_SSE=float(ce.sum()),projection_SSE=float(z[p+'_projection_blocks'].sum()),C_truth_energy=float(z[f'f{fi}_v{vi}_C_truth_blocks'].sum()),projection_truth_energy=float(z[f'f{fi}_v{vi}_projection_truth_blocks'].sum())))
     for ri,block in enumerate(f['rectangles']):rect.append(dict(seed=s,fold=fi,rectangle=ri,variant=v,model=m,C_MSE=float(ce[ri].sum()/ng),conditions='|'.join(block)))
 agg=summarize(rows);writecsv(out/'independent_per_fold.csv',rows);writecsv(out/'independent_summary.csv',agg);writecsv(out/'independent_per_rectangle.csv',rect);tables(agg,out)
 gains=[];concentration={};genes=z['genes'].astype(str);drop=z['fixed_drop10_mask']
 for m in ['M1','R']:
  vv=[]
  for f in meta['geometry']:
   vals=z[f"fold{f['fold']}_{m}_gene_C_SSE_gain"];vv.append(vals)
   gains.extend(dict(fold=f['fold'],model=m,gene=str(g),C_SSE_gain=float(x)) for g,x in zip(genes,vals))
  x=np.sum(vv,axis=0);order=np.argsort(-x);pos=x[x>0].sum();neg=-x[x<0].sum()
  concentration[m]=dict(improved_genes=int((x>0).sum()),top10_positive_share=float(x[order[:10]].sum()/pos),negative_cancellation_fraction=float(neg/pos),top10_genes=genes[order[:10]].tolist(),fixed10_positive_share=float(x[drop].sum()/pos))
 writecsv(out/'independent_gene_gains.csv',gains)
 # Winner counts per seed/method computed from rectangle error contributions.
 wins=[]
 for s in range(3):
  for m in ['M0','M1','GEARS','scouter']:
   a={(r['fold'],r['rectangle']):r['C_MSE'] for r in rect if r['seed']==s and r['variant']=='raw' and r['model']=='R'}
   b={(r['fold'],r['rectangle']):r['C_MSE'] for r in rect if r['seed']==s and r['variant']=='raw' and r['model']==m}
   wins.append(dict(seed=s,model='R',comparator=m,rectangles=len(a),wins=sum(a[k]<b[k] for k in a),ties=sum(a[k]==b[k] for k in a)))
 writecsv(out/'R_rectangle_wins.csv',wins)
 checkdata=check(agg,out);training=[]
 for s in range(3):
  for m in ['GEARS','scouter']:
   for f in range(5):
    p=ROOT/f'training_trace/seed_{s}/{m}/fold_{f}'/('refit/COMPLETE.json' if m=='GEARS' else 'COMPLETE.json');assert p.is_file();training.append(str(p.relative_to(ROOT)))
 checkdata.update(concentration=concentration,final_neural_runs=len(training),scope='55 unique combinations; 5 folds; 11 dependent rectangles; 15 fold-specific projection dimensions; seeds are optimization repetitions, not biological replicates',reproduction_level='Frozen-score/statistical-contribution reproduction, not vector recovery or neural retraining')
 (out/'REPRODUCTION_CHECK.json').write_text(json.dumps(checkdata,indent=2)+'\n');print(json.dumps(checkdata,indent=2));assert checkdata['passed']
if __name__=='__main__':main()
