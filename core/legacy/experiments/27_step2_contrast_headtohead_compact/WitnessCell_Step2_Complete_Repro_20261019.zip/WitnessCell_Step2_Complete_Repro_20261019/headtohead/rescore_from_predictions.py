#!/usr/bin/env python3
"""Re-score the original, full AutoDL prediction vectors. Requires extracted 80MB results ZIP.
The compact means reference independently checks truth and recalculates train-only variance.
Aligned predictions contain original deterministic M0/M1/R. Each neural vector is additionally
checked against its unaligned original per-model NPZ. No stored metric is used in calculation.
"""
import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
from pathlib import Path
import argparse,json,hashlib,itertools
import numpy as np
from reproduce import MODELS,VARIANTS,ROOT,writecsv,summarize,tables,check

def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--results-dir',type=Path,required=True);ap.add_argument('--output',type=Path,required=True);args=ap.parse_args();run=args.results_dir;out=args.output;out.mkdir(parents=True,exist_ok=True)
 assert (run/'formal_runs/seed_0/scores/fold_0_aligned.npz').is_file(),'Pass extracted archive root containing formal_runs/'
 roles=json.loads((ROOT/'design/data/common_roles.json').read_text());drop=json.loads((ROOT/'design/scoring/DROP10_FIXED.json').read_text())['genes']
 with np.load(ROOT/'reference_means.npz',allow_pickle=False) as z:
  cs=list(z['conditions'].astype(str));genes=z['genes'].astype(str);means=z['means'];ctrl=means[cs.index('control')]
 stats=np.load(ROOT/'loss_blocks_float64.npz',allow_pickle=False);sourcehash={}
 for rec in json.loads((ROOT/'SOURCE_FILES.json').read_text()):
  if 'original predictions' in rec['role'] and '/formal_runs/' in rec['path']:sourcehash['formal_runs/'+rec['path'].split('/formal_runs/',1)[1]]=rec['sha256']
 rows=[];rect=[];gains=[];maxpoint=0.;maxvar=0.;neuralchecked=0
 for s in range(3):
  for f in roles['folds']:
   fi=f['fold'];conds=f['test_conditions'];y=means[[cs.index(c) for c in conds]]-ctrl
   nodes=sorted({g for c in conds for g in c.split('+')});X=np.array([[int(g in c.split('+')) for g in nodes] for c in conds],float);C=[]
   for block in f['test_rectangle_blocks']:
    idx=[conds.index(q) for q in block];valid=[]
    for v in itertools.product((-1.,1.),repeat=3):
     v=np.array((1.,)+v)
     if np.max(np.abs(v@X[idx]))==0:valid.append(v)
    assert len(valid)==1;row=np.zeros(len(conds));row[idx]=valid[0];C.append(row)
   C=np.array(C);cy=C@y
   def projected(a):return a-X@np.linalg.lstsq(X,a,rcond=None)[0]
   py=projected(y);dim=len(conds)-np.linalg.matrix_rank(X)
   pred={}
   aligned_rel=f'formal_runs/seed_{s}/scores/fold_{fi}_aligned.npz'
   assert hashlib.sha256((run/aligned_rel).read_bytes()).hexdigest()==sourcehash[aligned_rel], 'Aligned prediction identity changed'
   with np.load(run/aligned_rel,allow_pickle=False) as z:
    assert list(z['conditions'].astype(str))==conds and np.array_equal(z['genes'].astype(str),genes)
    maxpoint=max(maxpoint,float(np.max(abs(z['truth_effect']-y))))
    for m in MODELS:pred[m]=z[f'pred_effect_{m}']
   for m,rel,key in [('GEARS',f'formal_runs/seed_{s}/GEARS/fold_{fi}/refit/predictions.npz','pred_mean_GEARS'),('scouter',f'formal_runs/seed_{s}/scouter/fold_{fi}/prediction.npz','pred_mean_scouter')]:
    path=run/rel
    assert hashlib.sha256(path.read_bytes()).hexdigest()==sourcehash[rel],f'Original prediction identity changed: {rel}'
    with np.load(path,allow_pickle=False) as z:
     cc=list(z['conditions'].astype(str));gg=list(z['genes'].astype(str));pp=z[key][[cc.index(c) for c in conds]][:,[gg.index(g) for g in genes]].astype(float)-ctrl
    maxpoint=max(maxpoint,float(np.max(abs(pp-pred[m]))));neuralchecked+=1
   tr=[cs.index(c) for c in f['outer_train_conditions'] if '+' in c];var=np.var(means[tr],axis=0,ddof=1);floor=np.quantile(var[var>0],.01);stdw=1/np.maximum(var,floor)
   maxvar=max(maxvar,float(np.max(abs(stdw-stats[f'fold{fi}_standardization_weight']))))
   for vi,v in enumerate(VARIANTS):
    keep=~np.isin(genes,drop) if vi==2 else np.ones(len(genes),bool);w=stdw[keep] if vi==1 else np.ones(sum(keep))
    for m,prediction in pred.items():
     e=(prediction-y)[:,keep];ce=C@e;pe=projected(e)
     rows.append(dict(seed=s,fold=fi,variant=v,model=m,conditions=len(conds),genes=int(sum(keep)),rectangles=len(C),contrast_dimension=int(dim),response_SSE=float(np.sum(e**2*w)),C_SSE=float(np.sum(ce**2*w)),projection_SSE=float(np.sum(pe**2*w)),C_truth_energy=float(np.sum(cy[:,keep]**2*w)),projection_truth_energy=float(np.sum(py[:,keep]**2*w))))
     for i,(err,block) in enumerate(zip(ce,f['test_rectangle_blocks'])):rect.append(dict(seed=s,fold=fi,rectangle=i,variant=v,model=m,C_MSE=float(np.mean(err**2*w)),conditions='|'.join(block)))
   if s==0:
    for m in ['M1','R']:
     g=np.sum((C@(pred['M0']-y))**2-(C@(pred[m]-y))**2,axis=0)
     assert np.array_equal(g,stats[f'fold{fi}_{m}_gene_C_SSE_gain'])
     gains.extend(dict(fold=fi,model=m,gene=gene,C_SSE_gain=float(v)) for gene,v in zip(genes,g))
 agg=summarize(rows);tables(agg,out);writecsv(out/'independent_per_fold.csv',rows);writecsv(out/'independent_summary.csv',agg);writecsv(out/'independent_per_rectangle.csv',rect);writecsv(out/'independent_gene_gains.csv',gains)
 result=check(agg,out);result.update(raw_original_neural_arrays_verified=neuralchecked,max_truth_and_prediction_alignment_difference=maxpoint,max_recomputed_training_weight_difference=maxvar,all_4995_gene_gains_identical=True,reproduction_level='Full prediction-array rescoring, including independently extracted truth and recomputed train-only variance')
 result['passed']=bool(result['passed'] and maxpoint==0 and maxvar==0 and neuralchecked==30)
 (out/'REPRODUCTION_CHECK.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2));assert result['passed']
if __name__=='__main__':main()
