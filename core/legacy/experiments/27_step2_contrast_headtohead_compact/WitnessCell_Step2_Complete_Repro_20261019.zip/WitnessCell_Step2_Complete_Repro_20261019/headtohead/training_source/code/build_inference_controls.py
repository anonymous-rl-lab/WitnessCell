"""Freeze the same control-cell set for both neural prediction adapters."""
from pathlib import Path
import json,numpy as np,h5py
out=Path(__file__).resolve().parents[1]/'data'
with h5py.File(out/'cells.h5') as f:
 names=f['condition_names'][:].astype(str);codes=f['condition_index'][:];control=np.flatnonzero(codes==list(names).index('control'));ids=f['cell_names'][:].astype(str)
p=np.random.default_rng(20261018).permutation(control)
report={'seed':20261018,'sampling':'One permutation of all control cell rows, without replacement; first64validation, first300test, capped by available count. Same indices for both neuralmodels and allfolds.','available_control_count':len(control),'validation_cell_indices':p[:min(64,len(p))].tolist(),'test_cell_indices':p[:min(300,len(p))].tolist(),'validation_cell_names':ids[p[:min(64,len(p))]].tolist(),'test_cell_names':ids[p[:min(300,len(p))]].tolist(),'index_scope':'0-based rows in cells.h5','selected_using_response_data':False}
(out/'inference_controls.json').write_text(json.dumps(report,indent=2)+'\n')
print('Shared control cells:',len(report['validation_cell_indices']),'validation,',len(report['test_cell_indices']),'test')
