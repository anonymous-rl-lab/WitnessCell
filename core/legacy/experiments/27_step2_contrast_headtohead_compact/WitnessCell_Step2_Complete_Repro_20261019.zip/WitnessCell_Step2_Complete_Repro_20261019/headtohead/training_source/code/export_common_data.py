"""Materialize exact frozen Wessels 55-combination task, without model selection."""
import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
from pathlib import Path
import sys,json,hashlib,time
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
WORK=ROOT.parent
DEPS=WORK/'confirmation_20261018/measurement/python_deps'
if DEPS.exists():sys.path.insert(0,str(DEPS))
import h5py
SOURCE=WORK/'takeover_20261018/partner/WitnessCell_Partner_Component_Run_20261018'
CONTRACT=WORK/'takeover_20261018/v20/grn_repo_v20/experiments/22_metric_calibration_stress/assets/formal_contracts/Wessels.phase_m_contract.npz'
H5AD=WORK/'takeover_20261018/confirmation_20261018/inputs/Wessels.h5ad'
def sha(p):
 h=hashlib.sha256()
 with open(p,'rb') as f:
  for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
 return h.hexdigest()
def dump(p,x):Path(p).write_text(json.dumps(x,indent=2,ensure_ascii=False,allow_nan=False)+'\n')
def strs(x):return np.asarray(x).astype(str)
def main():
 start=time.monotonic();out=ROOT/'data';out.mkdir(exist_ok=True)
 design=json.loads((SOURCE/'model/frozen_inputs/B_FROZEN_DESIGN.json').read_text())
 singles=design['allowed_singles'];pairs=design['complete_RNA_single_pairs'];names=['control']+singles+pairs
 assert len(names)==70 and len(set(names))==70
 with np.load(CONTRACT,allow_pickle=False) as z:
  cgenes=strs(z['genes']);cc=strs(z['conditions']);means=z['full_means'];var=z['full_variances'];counts=z['full_counts'];h1=z['first_means'];h2=z['second_means'];h1n=z['first_counts'];h2n=z['second_counts']
 target_genes=sorted({g for c in cc if '+' in c for g in c.split('+')})
 mask=~np.isin(cgenes,target_genes);assert len(cgenes)==5020 and mask.sum()==4995
 lookup={c:i for i,c in enumerate(cc)};ci=np.array([lookup[c] for c in names]);nm={c:i for i,c in enumerate(names)}
 with h5py.File(H5AD,'r') as f:
  genes=strs(f['var/_index'][:]);assert np.array_equal(genes,cgenes)
  cats=strs(f['obs/perturbation/categories'][:]);conds=cats[f['obs/perturbation/codes'][:]]
  cell_names=strs(f['obs/_index'][:]);take=np.flatnonzero(np.isin(conds,names));selected=conds[take]
  xx=f['X'][take].astype(np.float32)
  codes=np.array([nm[c] for c in selected],dtype=np.int16)
  assert xx.shape[1]==len(genes)
  maxdiff=0.;details=[]
  for c in names:
   vals=xx[codes==nm[c]];cm=vals.astype(float).mean(axis=0);diff=float(abs(cm-means[lookup[c]]).max());maxdiff=max(maxdiff,diff)
   assert len(vals)==int(counts[lookup[c]])
   if diff>1e-6:raise ValueError((c,'raw/contract mean drift',diff))
   details.append({'condition':c,'cells':len(vals),'max_abs_cell_mean_vs_contract':diff})
  tmp=out/'cells.h5.tmp'
  with h5py.File(tmp,'w') as fo:
   fo.create_dataset('X',data=xx,compression='gzip',compression_opts=1,chunks=(64,len(genes)))
   fo.create_dataset('condition_index',data=codes)
   fo.create_dataset('condition_names',data=np.array(names,dtype='S'))
   fo.create_dataset('genes',data=genes.astype('S'))
   fo.create_dataset('cell_names',data=cell_names[take].astype('S'))
   fo.create_dataset('source_cell_index',data=take)
   fo.create_dataset('score_gene_mask',data=mask)
   fo.attrs['expression']='Original Wessels.h5ad X (logNor), no re-normalization'
   fo.attrs['warning']='Contains all fixed task cells; trainers must enforce common_roles.json. No outer test cells may enter training/validation/network construction.'
  tmp.replace(out/'cells.h5')
 np.savez_compressed(out/'evaluation_only.npz',conditions=np.array(names),genes=cgenes,means=means[ci],variances=var[ci],counts=counts[ci],first_means=h1[ci],second_means=h2[ci],first_counts=h1n[ci],second_counts=h2n[ci],score_gene_mask=mask,all_panel_targets=np.array(target_genes))
 folds=[]
 for f in design['outer_folds']:
  outer_train=['control']+singles+f['train_pairs'];test=f['test_pairs'];inner=f['inner_test_pairs'][0]
  selection_train=['control']+singles+[c for c in f['train_pairs'] if c not in inner]
  assert not set(outer_train)&set(test) and set(selection_train)|set(inner)==set(outer_train)
  folds.append({'fold':f['fold'],'outer_train_conditions':outer_train,'test_conditions':test,'selection_train_conditions':selection_train,'selection_validation_conditions':inner,'original_inner_validation_folds':f['inner_test_pairs'],'test_rectangle_blocks':f['test_rectangle_blocks'],'outer_train_cell_count':int(np.isin(selected,outer_train).sum()),'selection_train_cell_count':int(np.isin(selected,selection_train).sum()),'selection_validation_cell_count':int(np.isin(selected,inner).sum()),'test_cell_count':int(np.isin(selected,test).sum())})
 roles={'dataset':'Wessels frozen 55 combination development panel','conditions':names,'single_conditions':singles,'combination_conditions':pairs,'source_gene_count':5020,'score_gene_count':4995,'excluded_target_genes':target_genes,'cell_count':len(take),'folds':folds,'selection_protocol':'For GEARS/scouter use original inner fold0 only for epoch selection, then reinitialize and fit ALL outer training conditions for selected epoch count. M0/M1/R preserve original three-inner-fold tuning. No outer test data for preprocessing, graph construction, fitting, or checkpoint choice. All methods have the same outer allowed observations.','primary_scoring':'11 original same-fit held-out rectangles; aggregate squared contrast errors. Do not project cross-fold stitched predictions.','historical_panel_status':'Repeatedly exposed development panel; this is a new matched competitor experiment, not independent biological confirmation.'}
 dump(out/'common_roles.json',roles);dump(out/'frozen_original_design.json',design)
 meta={'status':'EXACT_TASK_EXPORTED','elapsed_seconds':time.monotonic()-start,'source_h5ad_sha256':sha(H5AD),'source_contract_sha256':sha(CONTRACT),'source_design_sha256':sha(SOURCE/'model/frozen_inputs/B_FROZEN_DESIGN.json'),'cells_sha256':sha(out/'cells.h5'),'evaluation_sha256':sha(out/'evaluation_only.npz'),'roles_sha256':sha(out/'common_roles.json'),'raw_contract_max_abs_mean_difference':maxdiff,'conditions':details,'shape':list(xx.shape),'all_panel_target_count':len(target_genes),'all_panel_targets_in_readouts':int((~mask).sum())}
 dump(out/'EXPORT_VERIFICATION.json',meta);print(json.dumps({k:v for k,v in meta.items() if k!='conditions'},indent=2))
if __name__=='__main__':main()
