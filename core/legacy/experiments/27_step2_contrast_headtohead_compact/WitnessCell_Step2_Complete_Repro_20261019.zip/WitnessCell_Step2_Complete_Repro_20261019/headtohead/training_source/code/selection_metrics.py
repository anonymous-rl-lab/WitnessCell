"""Frozen training-internal epoch scoring shared by GEARS and scouter.

Matches global_pair_model.available_blocks exactly: retain every original
picked rectangle wholly contained in the validation condition set. This does
not enumerate new rectangles from the graph or inspect any outer-test values.
Only NumPy is needed for numerical work.
"""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import hashlib
import json
import numpy as np


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def build_validation_geometry(roles, original_design, fold):
    matches = [f for f in roles['folds'] if int(f['fold']) == int(fold)]
    if len(matches) != 1:
        raise ValueError('Fold must identify exactly one role record')
    role = matches[0]
    conditions = role['selection_validation_conditions']
    if len(conditions) != len(set(conditions)):
        raise ValueError('Duplicate validation condition')
    if set(conditions) & set(role['test_conditions']):
        raise ValueError('Outer test condition entered validation')
    if not set(conditions).issubset(role['outer_train_conditions']):
        raise ValueError('Validation condition outside allowed training data')
    lookup = {c: i for i, c in enumerate(conditions)}
    blocks = []
    for number, block in enumerate(original_design['model_panel_geometry']['picked']):
        if not set(block).issubset(lookup):
            continue
        nodes = sorted({g for c in block for g in c.split('+')})
        x = np.array([[float(g in c.split('+')) for g in nodes] for c in block])
        signs = None
        # This order and sign convention match frozen global_pair_model.py.
        for candidate in ((1,-1,-1,1),(1,-1,1,-1),(1,1,-1,-1)):
            if np.max(np.abs(np.asarray(candidate) @ x)) < 1e-10:
                signs = candidate
                break
        if signs is None:
            raise ValueError('Frozen block is not an alternating rectangle')
        blocks.append({'original_rectangle': number, 'conditions': list(block),
                       'indices': [lookup[c] for c in block], 'signs': list(signs)})
    if not blocks:
        raise ValueError('No original complete validation rectangle: no fallback permitted')
    return {'fold': int(fold), 'conditions': list(conditions), 'rectangles': blocks,
            'rectangle_count': len(blocks), 'score_gene_count': int(roles['score_gene_count'])}


def write_geometry(data_dir):
    data_dir = Path(data_dir)
    roles_path = data_dir/'common_roles.json'
    design_path = data_dir/'frozen_original_design.json'
    roles = json.loads(roles_path.read_text())
    original_design = json.loads(design_path.read_text())
    record = {
        'created_utc': datetime.now(timezone.utc).isoformat(),
        'purpose': 'Pre-formal common neural epoch criterion; pilot timing did not select outer-test outcomes.',
        'primary': 'Equal-weight C-MSE over all original frozen picked rectangles wholly inside fixed inner validation fold 0, on frozen 4995 non-target readouts.',
        'secondary': 'Condition-mean full-response MSE, exact C-MSE tie-break only; then earliest epoch.',
        'no_rectangle_rule': 'Fail; no fallback to a different endpoint.',
        'geometry_uses': 'Condition identities and original frozen picked blocks only; no expression values.',
        'common_roles_sha256': sha(roles_path),
        'original_design_sha256': sha(design_path),
        'selection_function_sha256': sha(__file__),
        'folds': [build_validation_geometry(roles, original_design, f['fold']) for f in roles['folds']]
    }
    path = data_dir/'selection_validation_geometry.json'
    if path.exists():
        existing = json.loads(path.read_text())
        for k in ('common_roles_sha256','original_design_sha256','selection_function_sha256','folds'):
            if existing[k] != record[k]:
                raise ValueError(f'Existing geometry differs: {k}; do not silently overwrite')
        return existing
    temporary = path.with_suffix('.json.tmp')
    temporary.write_text(json.dumps(record, indent=2, ensure_ascii=False)+'\n')
    temporary.replace(path)
    return record


def load_validation_geometry(data_dir, fold):
    data_dir = Path(data_dir)
    record = json.loads((data_dir/'selection_validation_geometry.json').read_text())
    expected = {'common_roles_sha256': sha(data_dir/'common_roles.json'),
                'original_design_sha256': sha(data_dir/'frozen_original_design.json'),
                'selection_function_sha256': sha(__file__)}
    for key, value in expected.items():
        if record[key] != value:
            raise ValueError(f'Validation geometry identity mismatch: {key}')
    return next(g for g in record['folds'] if int(g['fold']) == int(fold))


def validation_metrics(prediction, truth, conditions, score_mask, geometry):
    """Both arrays must be condition-by-gene on the same expression scale.

    Absolute means and control effects give the same metrics when matched.
    The supplied condition order must match the frozen validation list exactly.
    """
    prediction, truth = np.asarray(prediction, float), np.asarray(truth, float)
    conditions = list(map(str, conditions))
    score_mask = np.asarray(score_mask, bool)
    if conditions != geometry['conditions']:
        raise ValueError('Validation order differs from frozen geometry')
    if prediction.shape != truth.shape or prediction.shape != (len(conditions),len(score_mask)):
        raise ValueError('Prediction/truth/gene-mask shape mismatch')
    if int(score_mask.sum()) != geometry['score_gene_count']:
        raise ValueError('Scored gene count differs from frozen task')
    if not np.all(np.isfinite(prediction)) or not np.all(np.isfinite(truth)):
        raise ValueError('Nonfinite validation input')
    errors = prediction[:,score_mask]-truth[:,score_mask]
    squared = []
    for block in geometry['rectangles']:
        contrast_error = np.asarray(block['signs'],float) @ errors[block['indices']]
        squared.append(np.mean(contrast_error**2))
    if not squared:
        raise ValueError('No validation rectangles; fallback forbidden')
    return {'validation_C_MSE': float(np.mean(squared)),
            'validation_condition_mean_mse': float(np.mean(errors**2)),
            'validation_rectangles': len(squared)}


def selection_key(metrics, epoch):
    """Lexicographic rule: C-MSE, then full MSE, then earliest epoch."""
    return (metrics['validation_C_MSE'], metrics['validation_condition_mean_mse'], int(epoch))


if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--data', type=Path, default=Path(__file__).resolve().parents[1]/'data')
    args = ap.parse_args()
    result = write_geometry(args.data)
    print(json.dumps({'path': str(args.data/'selection_validation_geometry.json'),
                      'folds': [{'fold': f['fold'], 'validation_conditions': len(f['conditions']),
                                 'rectangles': f['rectangle_count']} for f in result['folds']]},indent=2))
