# GEARS comparison adapter

This adapter imports `GEARS_Model` and `loss_fct` from the unmodified official
`cell-gears==0.1.2` PyPI wheel retained in `vendor/`. It does not replace GEARS
with an additive model, generic neural network, or reimplementation.

The shared comparison supplies 55 double-perturbation conditions, 14 measured
singles and controls, with the original five outer folds preserved. GEARS
receives every cell in the permitted training conditions and all 5,020 genes.
Evaluation is restricted by the common fixed mask to 4,995 non-target genes.
The inner validation split is the original inner-fold-0 split. Once schedule
and epoch are selected, a new initialization is fitted on all outer-training
conditions for the selected number of epochs. No test expression is used in
training, graph construction, selection or prediction.

The model retains hidden size 64, one GO and one coexpression SGConv layer,
all 9,853 GO-supported essential perturbation genes, and the official training
loss: fourth-power error plus the 0.1 direction term, with per-condition
zero-expression coordinates excluded. Adam starts at 0.001 with weight decay
0.0005 and gradient-value clipping at 1.0. Controls map to themselves; other
training cells receive one fixed random control input. Training shuffles cells
and drops the incomplete last batch, matching the official loader.

The original schedule halves the learning rate after every epoch. A separately
identified slower schedule can use `--schedule-step 5`; this is a training
schedule sensitivity, not an architectural modification. Selection uses contrast MSE on the three complete original frozen rectangles
inside each inner validation split, over the shared 4,995-gene mask. Full
condition-mean MSE is an exact-score tie-breaker and diagnostic. It does not
use test DEGs or any outer-test score. The original M1 penalty was selected
using the same rectangle objective.

GO assets are restored exactly from the v20 lossless store. The public Harvard
Dataverse downloads returned HTTP 403. The GO graph is therefore reconstructed
by the official source's Jaccard rule, with explicit provenance and tie ordering;
it must not be represented as byte-identical to the unavailable published CSV.
The coexpression graph follows the official controls-plus-training-singles rule.

Prediction preserves an unusual detail of the pinned official forward method:
the coexpression edge indices affect the first repeated gene block, whereas
other blocks receive only self-loops. Naive microbatching would change the mean.
The adapter uses a verified two-offset identity to reproduce the original
single-batch mean over the same 300 control inputs without allocating a huge
300-cell activation tensor. The pilot verifies this identity against a literal
64-control forward pass and retains the maximum coordinate difference.

Example bounded pilot:

```bash
head_to_head_20261018/runtime/venv/bin/python \
  head_to_head_20261018/gears/run_gears.py \
  --mode pilot --fold 0 --epochs 2 --max-train-seconds 120 \
  --out head_to_head_20261018/gears/runs/pilot/fold0
```

A partial pilot is only a runtime and code check. It does not count as a trained
competitor, and its predictions must not enter the comparison table.

Completed epochs write `epoch_checkpoint.pt` atomically. Resume with
`--resume /same/run/epoch_checkpoint.pt`; fold, seed, role hashes, adapter hash,
training schedule and selection-function identity must match. A bounded pilot
that stops midway through its first epoch is not a formal resumable fit.
