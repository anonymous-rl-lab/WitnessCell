#!/usr/bin/env python3
"""Shared-protocol adapter around unmodified cell-gears 0.1.2 model and loss.

Only orchestration is changed: condition-level inner validation, optional slower
LR schedule, and final refit on every allowed outer-training condition. Neither
outer-test RNA nor evaluation_only.npz is read during selection or fitting.
"""
from __future__ import annotations
import argparse, hashlib, json, os, pickle, random, sys, time
from pathlib import Path
from types import SimpleNamespace
import h5py
import numpy as np
import pandas as pd
import torch

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE/'vendor/source'))
from gears.model import GEARS_Model
from gears.utils import loss_fct, GeneSimNetwork, np_pearson_cor
sys.path.insert(0, str(HERE.parent/'code'))
from selection_metrics import load_validation_geometry, validation_metrics, selection_key


def sha(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for b in iter(lambda:f.read(1<<20),b''):h.update(b)
    return h.hexdigest()


def save_json(p,j):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
    q=p.with_suffix(p.suffix+'.tmp');q.write_text(json.dumps(j,indent=2,allow_nan=False)+'\n');q.replace(p)


def decode(a):return np.asarray([v.decode() if isinstance(v,bytes) else str(v) for v in a])


def make_graphs(data_path,assets,cache,threads):
    cache.mkdir(parents=True,exist_ok=True)
    cache_path=cache/'graphs.pt'
    with h5py.File(data_path,'r') as f:
        genes=decode(f['genes'][:]);conditions=decode(f['condition_names'][:]);ci=f['condition_index'][:]
        allowed=np.where(np.isin(ci,[i for i,c in enumerate(conditions) if '+' not in c]))[0]
        X=f['X'][allowed].astype(np.float64)
    gene2go=pickle.load(open(assets/'gene2go_all.pkl','rb'))
    essential=pickle.load(open(assets/'essential_all_data_pert_genes.pkl','rb'))
    perts=np.unique([p for p in essential if p in gene2go])
    missing=sorted({g for c in conditions if c!='control' for g in c.split('+')} - set(perts))
    if missing: raise ValueError(f'GO missing required perturbation genes: {missing}')
    identity={'cells_sha256':sha(data_path),'gene2go_sha256':sha(assets/'gene2go_all.pkl'),
              'essential_sha256':sha(assets/'essential_all_data_pert_genes.pkl'),
              'go_csv_sha256':sha(assets/'go_essential_all/go_essential_all_top21.csv'),
              'coexpression_rule':'official controls plus all measured singles, absolute Pearson, top21 per target, threshold >0.4',
              'go_rule':'official default essential universe; Jaccard >0.1, top21 per target'}
    if cache_path.exists() and json.load(open(cache/'graph_identity.json'))==identity:
        payload=torch.load(cache_path,weights_only=False,map_location='cpu')
        return payload
    tic=time.monotonic()
    corr=np_pearson_cor(X,X);corr[np.isnan(corr)]=0;corr=np.abs(corr)
    indices=np.argsort(corr,axis=1)[:,-21:]
    rows=np.repeat(np.arange(len(genes)),21);cols=indices.reshape(-1)
    vals=corr[rows,cols];keep=vals>0.4
    edges=pd.DataFrame({'source':genes[cols[keep]],'target':genes[rows[keep]],'importance':vals[keep]})
    net=GeneSimNetwork(edges,genes,{g:i for i,g in enumerate(genes)})
    go=pd.read_csv(assets/'go_essential_all/go_essential_all_top21.csv')
    gonet=GeneSimNetwork(go,perts,{g:i for i,g in enumerate(perts)})
    payload={'genes':genes,'perts':perts,'G_coexpress':net.edge_index,'G_coexpress_weight':net.edge_weight,
             'G_go':gonet.edge_index,'G_go_weight':gonet.edge_weight}
    torch.save(payload,cache_path);save_json(cache/'graph_identity.json',identity)
    print(json.dumps({'graph_seconds':time.monotonic()-tic,'genes':len(genes),'perts':len(perts),'coexpression_edges':int(net.edge_index.shape[1]),'go_edges':int(gonet.edge_index.shape[1])}),flush=True)
    return payload


def load_data(data_path,role,mode):
    train_names=role['outer_train_conditions'] if mode=='refit' else role['selection_train_conditions']
    val_names=[] if mode=='refit' else role['selection_validation_conditions']
    with h5py.File(data_path,'r') as f:
        names=decode(f['condition_names'][:]); ci=f['condition_index'][:]; genes=decode(f['genes'][:]);mask=f['score_gene_mask'][:]
        train_ids=np.where(np.isin(ci,[np.where(names==n)[0][0] for n in train_names]))[0]
        control_ids=np.where(ci==np.where(names=='control')[0][0])[0]
        # Only permitted training and inner-validation RNA is loaded here.
        Xtrain=f['X'][train_ids].astype(np.float32)
        Xctrl=f['X'][control_ids].astype(np.float32)
        val_mean={n:f['X'][np.where(ci==np.where(names==n)[0][0])[0]].astype(np.float64).mean(0) for n in val_names}
    return {'Xtrain':Xtrain,'train_labels':names[ci[train_ids]],'Xctrl':Xctrl,'ctrl':Xctrl.mean(0,dtype=np.float64),
            'val_mean':val_mean,'genes':genes,'mask':mask,'train_names':train_names,'val_names':val_names,
            'control_ids':control_ids,'train_ids':train_ids}


def config(graph,device):
    return {'hidden_size':64,'num_go_gnn_layers':1,'num_gene_gnn_layers':1,'decoder_hidden_size':16,
            'uncertainty':False,'uncertainty_reg':1,'direction_lambda':0.1,
            'G_go':graph['G_go'],'G_go_weight':graph['G_go_weight'],'G_coexpress':graph['G_coexpress'],
            'G_coexpress_weight':graph['G_coexpress_weight'],'device':device,'num_genes':len(graph['genes']),
            'num_perts':len(graph['perts']),'no_perturb':False}


def make_batch(X,pert_idx,device):
    n,g=X.shape
    return SimpleNamespace(x=torch.as_tensor(X,device=device).reshape(-1,1),
                           pert_idx=pert_idx,batch=torch.arange(n,device=device).repeat_interleave(g))


@torch.no_grad()
def predict_means(model,conditions,ctrls,pert_map,device,verify=False):
    """Exact algebraic control averaging for the pinned official forward pass.

    Expression enters only through final +x. In official v0.1.2, GO applies to
    perturbation embeddings and coexpression edges apply to the first gene
    block; remaining repeated blocks receive only SGConv self-loops. Hence
    first-cell and remaining-cell offsets differ, but are each independent of x.
    A two-cell evaluation preserves both offsets; weighting 1/N and (N-1)/N
    reproduces the original one-batch-N mean. Ordinary microbatch averaging
    would change the model and is deliberately not used.
    """
    model.eval();out=[];checks=[];n=len(ctrls)
    for c in conditions:
        indices=[pert_map[g] for g in c.split('+')] if c!='control' else [-1]
        two=ctrls[:min(2,n)]
        p=model(make_batch(two,[indices]*len(two),device)).cpu().numpy().astype(np.float64)
        delta=p-two.astype(np.float64)
        pred=ctrls.mean(axis=0,dtype=np.float64)+delta[0]/n
        if n>1:pred+=delta[1]*(n-1)/n
        if verify:
            full=model(make_batch(ctrls,[indices]*n,device)).cpu().numpy().mean(axis=0,dtype=np.float64)
            err=float(np.max(np.abs(full-pred)))
            if err>5e-5:raise AssertionError(f'Official batch mean equivalence failed: {err}')
            checks.append({'condition':c,'n_controls':n,'max_abs_error':err})
        out.append(pred)
    if verify:return np.asarray(out),checks
    return np.asarray(out)


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--data',type=Path,default=HERE.parent/'data/cells.h5')
    p.add_argument('--roles',type=Path,default=HERE.parent/'data/common_roles.json')
    p.add_argument('--assets',type=Path,default=HERE/'assets')
    p.add_argument('--out',type=Path,required=True)
    p.add_argument('--fold',type=int,default=0)
    p.add_argument('--mode',choices=['pilot','select','refit'],default='pilot')
    p.add_argument('--epochs',type=int,default=2)
    p.add_argument('--schedule-step',type=int,default=1)
    p.add_argument('--patience',type=int,default=10)
    p.add_argument('--seed',type=int,default=0)
    p.add_argument('--batch-size',type=int,default=32)
    p.add_argument('--threads',type=int,default=4)
    p.add_argument('--device',default='cpu')
    p.add_argument('--max-train-seconds',type=float,default=0)
    p.add_argument('--max-steps',type=int,default=0)
    p.add_argument('--validation-controls',type=int,default=64)
    p.add_argument('--prediction-controls',type=int,default=300)
    p.add_argument('--predict-test',action='store_true')
    p.add_argument('--resume',type=Path,help='Resume a completed-epoch checkpoint from this same run')
    a=p.parse_args();a.out.mkdir(parents=True,exist_ok=True)
    if a.predict_test and a.mode!='refit':raise ValueError('Test predictions require refit mode')
    torch.set_num_threads(a.threads);torch.set_num_interop_threads(1)
    random.seed(a.seed);np.random.seed(a.seed);torch.manual_seed(a.seed)
    roles=json.load(open(a.roles));role=next(r for r in roles['folds'] if r['fold']==a.fold)
    graph=make_graphs(a.data,a.assets,HERE/'cache',a.threads)
    d=load_data(a.data,role,a.mode);assert np.array_equal(d['genes'],graph['genes'])
    geometry=load_validation_geometry(a.data.parent,a.fold)
    pert_map={g:i for i,g in enumerate(graph['perts'])}
    pert_idx=[[pert_map[g] for g in c.split('+')] if c!='control' else [-1] for c in d['train_labels']]
    ctrls=d['Xctrl'];rng=np.random.default_rng(a.seed)
    paired_ctrl=ctrls[rng.integers(0,len(ctrls),size=len(d['Xtrain']))].copy()
    control_training=d['train_labels']=='control';paired_ctrl[control_training]=d['Xtrain'][control_training]
    ctrlperm=np.random.default_rng(20261018).permutation(len(ctrls))
    valctrl=ctrls[ctrlperm[:min(a.validation_controls,len(ctrls))]]
    testctrl=ctrls[ctrlperm[:min(a.prediction_controls,len(ctrls))]]
    filt={c:np.flatnonzero(d['Xtrain'][d['train_labels']==c].mean(0)!=0) for c in d['train_names'] if c!='control'}
    model=GEARS_Model(config(graph,a.device)).to(a.device)
    optim=torch.optim.Adam(model.parameters(),lr=0.001,weight_decay=0.0005)
    scheduler=torch.optim.lr_scheduler.StepLR(optim,step_size=a.schedule_step,gamma=0.5)
    ctrl_tensor=torch.as_tensor(d['ctrl'],dtype=torch.float32,device=a.device)
    meta={'model':'GEARS','official_package':'cell-gears==0.1.2','wheel_sha256':sha(HERE/'vendor/cell_gears-0.1.2-py3-none-any.whl'),
          'model_source_sha256':sha(HERE/'vendor/source/gears/model.py'),'loss_source_sha256':sha(HERE/'vendor/source/gears/utils.py'),
          'adapter_sha256':sha(__file__),'roles_sha256':sha(a.roles),'cells_sha256':sha(a.data),'fold':a.fold,'mode':a.mode,
          'seed':a.seed,'epochs_cap':a.epochs,'schedule_step':a.schedule_step,'batch_size':a.batch_size,'threads':a.threads,
          'train_conditions':d['train_names'],'validation_conditions':d['val_names'],'test_conditions':role['test_conditions'],
          'train_cell_count':len(d['Xtrain']),'validation_control_source_indices':d['control_ids'][ctrlperm[:len(valctrl)]].tolist(),
          'prediction_control_source_indices':d['control_ids'][ctrlperm[:len(testctrl)]].tolist(),
          'validation_criterion':'frozen original complete inner-validation rectangle C-MSE on4995non-targetgenes; fullMSE exact tie-break'
          ,'selection_metrics_sha256':sha(HERE.parent/'code/selection_metrics.py'),
          'training_loss':'officialfourthpower+direction0.1, nonzerotrainingconditiongenes',
          'pairing':'onefixedrandomcontrolpertraincell;controlsmaptoself;drop_last=Trueofficial',
          'outer_test_RNA_loaded':False,'device':a.device,'torch_version':torch.__version__,
          'inference_control_average':'exacttwooffsetfactorizationofpinnedofficialsinglebatchforward; verifiedagainst64controlfullbatch'}
    save_json(a.out/'run_metadata.json',meta)
    history=[];best_val=float('inf');best_full_val=None;best_key=(float('inf'),float('inf'),float('inf'));best_epoch=None;stale=0;steps=0;train_elapsed=0.;start=time.monotonic();interrupted=False;start_epoch=0
    if a.resume:
        ck=torch.load(a.resume,weights_only=False,map_location=a.device)
        if ck.get('partial',True):raise ValueError('Only completed-epoch checkpoints may be resumed')
        for key in ['fold','mode','seed','schedule_step','batch_size','roles_sha256','cells_sha256','adapter_sha256','selection_metrics_sha256']:
            if ck['run_metadata'][key]!=meta[key]:raise ValueError(f'Resume identity mismatch: {key}')
        model.load_state_dict(ck['model_state']);optim.load_state_dict(ck['optimizer_state']);scheduler.load_state_dict(ck['scheduler_state'])
        rng.bit_generator.state=ck['rng_state'];torch.set_rng_state(ck['torch_rng_state'].cpu())
        history=ck['history'];start_epoch=ck['completed_epochs'];best_val=ck['best_val'];best_full_val=ck['best_full_val'];best_key=tuple(ck['best_key']);best_epoch=ck['best_epoch'];stale=ck['stale'];steps=ck['steps'];train_elapsed=ck['train_seconds']
    for epoch in range(start_epoch,a.epochs):
        model.train();order=rng.permutation(len(d['Xtrain']));losses=[];epoch_start=time.monotonic()
        for startidx in range(0,len(order)-a.batch_size+1,a.batch_size):
            ids=order[startidx:startidx+a.batch_size];batch=make_batch(paired_ctrl[ids],[pert_idx[i] for i in ids],a.device)
            y=torch.as_tensor(d['Xtrain'][ids],device=a.device);optim.zero_grad();tic=time.monotonic()
            pred=model(batch);loss_labels=np.where(d['train_labels'][ids]=='control','ctrl',d['train_labels'][ids]);loss=loss_fct(pred,y,loss_labels,ctrl_tensor,0.1,filt)
            loss.backward();torch.nn.utils.clip_grad_value_(model.parameters(),1.0);optim.step()
            elapsed=time.monotonic()-tic;train_elapsed+=elapsed;steps+=1;losses.append(float(loss.detach()))
            if steps<=3 or steps%20==0:print(json.dumps({'epoch':epoch+1,'step':steps,'step_seconds':elapsed,'train_loss':losses[-1],'train_elapsed':train_elapsed}),flush=True)
            if (a.max_steps and steps>=a.max_steps) or (a.max_train_seconds and train_elapsed>=a.max_train_seconds):interrupted=True;break
        epoch_seconds=time.monotonic()-epoch_start
        if interrupted:
            history.append({'epoch':epoch+1,'partial_epoch':True,'train_steps':len(losses),'train_loss':float(np.mean(losses)),'train_seconds':epoch_seconds})
            break
        scheduler.step();row={'epoch':epoch+1,'partial_epoch':False,'train_steps':len(losses),'train_loss':float(np.mean(losses)),'train_seconds':epoch_seconds,'next_lr':optim.param_groups[0]['lr']}
        if d['val_names']:
            tic=time.monotonic();prediction=predict_means(model,d['val_names'],valctrl,pert_map,a.device)
            truth=np.stack([d['val_mean'][c] for c in d['val_names']]);metrics=validation_metrics(prediction,truth,d['val_names'],d['mask'],geometry)
            key=selection_key(metrics,epoch+1);val=float(metrics['validation_C_MSE'])
            row.update(metrics);row.update(validation_mse=metrics['validation_condition_mean_mse'],validation_seconds=time.monotonic()-tic)
            if key<best_key:
                best_val=val;best_full_val=metrics['validation_condition_mean_mse'];best_key=key;best_epoch=epoch+1;stale=0;tmp_best=a.out/'best_model.pt.tmp';torch.save(model.state_dict(),tmp_best);tmp_best.replace(a.out/'best_model.pt')
            else:stale+=1
        history.append(row);save_json(a.out/'training_history.json',history);print(json.dumps(row),flush=True)
        epoch_checkpoint={'model_state':model.state_dict(),'optimizer_state':optim.state_dict(),'scheduler_state':scheduler.state_dict(),
                          'rng_state':rng.bit_generator.state,'torch_rng_state':torch.get_rng_state(),'history':history,
                          'partial':False,'completed_epochs':epoch+1,'best_val':best_val,'best_full_val':best_full_val,'best_key':best_key,'best_epoch':best_epoch,'stale':stale,
                          'steps':steps,'train_seconds':train_elapsed,'run_metadata':meta}
        tmp_checkpoint=a.out/'epoch_checkpoint.pt.tmp';torch.save(epoch_checkpoint,tmp_checkpoint);tmp_checkpoint.replace(a.out/'epoch_checkpoint.pt')
        if a.mode=='select' and stale>=a.patience:break
    if a.mode=='pilot' and d['val_names']:
        tic=time.monotonic();_,checks=predict_means(model,d['val_names'][:2],valctrl,pert_map,a.device,verify=True)
        save_json(a.out/'inference_equivalence.json',{'checks':checks,'wall_seconds':time.monotonic()-tic})
    tmp_last=a.out/'last_checkpoint.pt.tmp'
    torch.save({'model_state':model.state_dict(),'optimizer_state':optim.state_dict(),'scheduler_state':scheduler.state_dict(),
                'rng_state':rng.bit_generator.state,'torch_rng_state':torch.get_rng_state(),'history':history},tmp_last)
    tmp_last.replace(a.out/'last_checkpoint.pt')
    save_json(a.out/'training_history.json',history)
    status={'completed_epochs':sum(not r['partial_epoch'] for r in history),'partial':interrupted,'total_steps':steps,'train_seconds':train_elapsed,
            'wall_seconds':time.monotonic()-start,'best_epoch':best_epoch,'best_validation_mse':best_full_val,'best_validation_score':None if best_epoch is None else best_val,
            'seconds_per_training_step':train_elapsed/steps if steps else None,'steps_per_full_epoch':len(d['Xtrain'])//a.batch_size,
            'estimated_training_seconds_per_epoch':(train_elapsed/steps)*(len(d['Xtrain'])//a.batch_size) if steps else None,
            'test_predictions_written':False}
    if a.predict_test and not interrupted:
        tic=time.monotonic();pred=predict_means(model,role['test_conditions'],testctrl,pert_map,a.device)
        tmp=a.out/'predictions.npz.tmp'
        with open(tmp,'wb') as f:np.savez_compressed(f,conditions=np.asarray(role['test_conditions']),genes=d['genes'],pred_mean_GEARS=pred,pred_effect_GEARS=pred-d['ctrl'][None,:],control_mean=d['ctrl'])
        tmp.replace(a.out/'predictions.npz');status.update(test_predictions_written=True,prediction_seconds=time.monotonic()-tic)
    save_json(a.out/'status.json',status);print(json.dumps(status),flush=True)

if __name__=='__main__':main()
