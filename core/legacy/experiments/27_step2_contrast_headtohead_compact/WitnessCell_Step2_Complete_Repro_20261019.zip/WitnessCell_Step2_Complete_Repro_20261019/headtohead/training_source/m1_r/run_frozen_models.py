"""Refit unchanged M0/M1/R with outer test response arrays zeroed."""
import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
from pathlib import Path
import json,time,hashlib
import numpy as np
from global_pair_model import make_dataset,fit_outer
ROOT=Path(__file__).resolve().parents[1]

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,x):Path(p).write_text(json.dumps(x,indent=2,ensure_ascii=False,allow_nan=False)+'\n')
def save_npz(path,**arrays):
 tmp=path.with_suffix('.tmp.npz');np.savez_compressed(tmp,**arrays)
 with np.load(tmp,allow_pickle=False) as z:
  for key in z.files:_=z[key]
 tmp.replace(path)

def main():
 t0=time.monotonic();data=ROOT/'data';out=ROOT/'m1_r';dsg=json.loads((data/'frozen_original_design.json').read_text());roles=json.loads((data/'common_roles.json').read_text())
 with np.load(data/'evaluation_only.npz') as z:
  con=z['conditions'].astype(str);genes=z['genes'].astype(str);keep=z['score_gene_mask'];m=z['means'][:,keep];a=z['first_means'][:,keep];b=z['second_means'][:,keep]
 genes=genes[keep];lut={v:i for i,v in enumerate(con)};ctrl=m[lut['control']];pairs=dsg['complete_RNA_single_pairs'];plut={p:i for i,p in enumerate(pairs)}
 single={s:m[lut[s]]-ctrl for s in dsg['allowed_singles']}
 with np.load(out/'HISTORICAL_REFERENCE.npz') as z:oldpairs=z['pairs'].astype(str);old={k:z[k] for k in ['M0','M1','R']};assert list(oldpairs)==pairs
 reports=[]
 for f in dsg['outer_folds']:
  start=time.monotonic();fi=f['fold'];dest=out/f'fold_{fi}';dest.mkdir(exist_ok=True)
  tr=np.array([plut[p] for p in f['train_pairs']]);q=np.array([plut[p] for p in f['test_pairs']]);inner=[np.array([plut[p] for p in g]) for g in f['inner_test_pairs']]
  # Deliberately erase all outer-test responses before any fitting call.
  response=np.zeros((len(pairs),len(genes)));response[tr]=np.array([m[lut[p]]-ctrl for p in f['train_pairs']])
  d=make_dataset(pairs,single,response,dsg['model_panel_geometry']['picked'])
  assert np.max(abs(d.y[q]))==0
  pred,meta=fit_outer(d,tr,q,inner)
  xt=d.x[tr];P=np.eye(len(tr))-xt@np.linalg.pinv(xt)
  aa=P@np.array([a[lut[p]] for p in f['train_pairs']]);bb=P@np.array([b[lut[p]] for p in f['train_pairs']]);num=np.sum(aa*bb,axis=0);den=.5*np.sum(aa*aa+bb*bb,axis=0)
  w=np.divide(num,den,out=np.zeros_like(num),where=den>0).clip(0,1);pred['R']=pred['M0']+w*(pred['M1']-pred['M0'])
  diffs={k:float(np.max(abs(pred[k]-old[k][q]))) for k in old}
  if max(diffs.values())>1e-12:raise ValueError(('Historical prediction drift',fi,diffs))
  save_npz(dest/'PREDICTIONS.npz',conditions=np.array(f['test_pairs']),genes=genes,control=ctrl,weights=w,**{'pred_effect_'+k:v for k,v in pred.items()})
  report={'fold':fi,'seconds':time.monotonic()-start,'test_responses_erased_before_fit':True,'historical_max_abs_difference':diffs,'fit':meta}
  dump(dest/'FIT.json',report);reports.append(report)
  # Fold-specific full test annihilator, never across separately trained outer folds.
  nodes=sorted({g for p in f['test_pairs'] for g in p.split('+')});nlut={g:i for i,g in enumerate(nodes)};X=np.zeros((len(q),len(nodes)))
  for j,p in enumerate(f['test_pairs']):
   for g in p.split('+'):X[j,nlut[g]]=1
  U,s,V=np.linalg.svd(X,full_matrices=True);rank=int(np.sum(s>max(X.shape)*np.finfo(float).eps*s[0]));basis=U[:,rank:]
  save_npz(data/f'fold_{fi}_contrast_basis.npz',conditions=np.array(f['test_pairs']),nodes=np.array(nodes),X=X,basis=basis,projector=basis@basis.T,rank_X=np.array(rank),d=np.array(len(q)-rank))
  print(json.dumps({'fold':fi,'seconds':report['seconds'],'historical_max_abs_difference':diffs,'projection_d':len(q)-rank}),flush=True)
 summary={'status':'FROZEN_MODELS_EXACTLY_REPRODUCED','elapsed_seconds':time.monotonic()-t0,'outer_folds':5,'source_core_sha256':sha(out/'global_pair_model.py'),'script_sha256':sha(__file__),'test_response_use':'Each outer test response was replaced with zero before fit_outer. Single measurements remain allowed, including test endpoints.','max_abs_historical_difference':max(v for r in reports for v in r['historical_max_abs_difference'].values()),'predictions_semantics':'pred_effect_MODEL are control-subtracted conditional means on fixed4995readouts; add control to compare absolute means.'}
 dump(out/'REPRODUCTION.json',summary);print(json.dumps(summary,indent=2))
if __name__=='__main__':main()
