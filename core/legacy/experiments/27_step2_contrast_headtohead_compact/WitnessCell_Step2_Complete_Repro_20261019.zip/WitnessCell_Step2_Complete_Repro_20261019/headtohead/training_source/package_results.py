#!/usr/bin/env python3
"""Collect completed predictions, training logs, all score tables and provenance."""
from pathlib import Path
import argparse,datetime,hashlib,json,zipfile
ROOT=Path(__file__).resolve().parent

def sha(p):
 h=hashlib.sha256()
 with open(p,'rb') as f:
  for b in iter(lambda:f.read(8<<20),b''):h.update(b)
 return h.hexdigest()
def main():
 a=argparse.ArgumentParser();a.add_argument('--runs',type=Path,default=ROOT/'formal_runs');a.add_argument('--include-checkpoints',action='store_true');a.add_argument('--output',type=Path);args=a.parse_args()
 run=json.loads((args.runs/'RUN_COMPLETE.json').read_text());protocol=json.loads((ROOT/'protocol.json').read_text())
 completed=set(run['completed_requested_seeds']);required=set(protocol['seeds'])
 if not run.get('all_frozen_seeds_completed') or not (args.runs/'final_summary/SUMMARY_COMPLETE.json').is_file():raise RuntimeError('Complete all three frozen seeds and final summary before packaging')
 for seed in required:
  if not (args.runs/f'seed_{seed}/SEED_COMPLETE.json').exists():raise RuntimeError(f'Seed {seed} not complete; results package is not final')
 stamp=datetime.datetime.now().strftime('%Y%m%dT%H%M%S');output=args.output or ROOT/f'WitnessCell_HeadToHead_Results_{stamp}.zip'
 paths=[p for p in args.runs.rglob('*') if p.is_file() and p.name!='.run.lock' and '.tmp' not in p.name and not any('.incomplete_' in part for part in p.parts) and (args.include_checkpoints or p.suffix!='.pt')]
 for part in ['protocol.json','run_formal.py','bootstrap_env.py','package_results.py','run_autodl.sh','runtime/requirements.formal.txt','data/common_roles.json','data/inference_controls.json','data/selection_validation_geometry.json','scoring/score_head_to_head.py','scoring/summarize_seeds.py','scoring/DROP10_FIXED.json']:
  paths.append(ROOT/part)
 files=sorted(set(paths));manifest={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'All fixedseed predictions/logs/scores; no bestseed selection or ensemble','checkpoints_included':args.include_checkpoints,'required_seeds':sorted(required),'files':[{'path':str(p.relative_to(ROOT)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in files]}
 temp=output.with_suffix('.tmp.zip')
 with zipfile.ZipFile(temp,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=1,allowZip64=True) as z:
  for p in files:z.write(p,str(p.relative_to(ROOT)))
  z.writestr('RESULTS_MANIFEST.json',json.dumps(manifest,indent=2)+'\n')
 with zipfile.ZipFile(temp) as z:
  if z.testzip() is not None:raise RuntimeError('Results ZIP failed integrity check')
 temp.replace(output);print(json.dumps({'path':str(output),'bytes':output.stat().st_size,'sha256':sha(output)},indent=2))
if __name__=='__main__':main()
