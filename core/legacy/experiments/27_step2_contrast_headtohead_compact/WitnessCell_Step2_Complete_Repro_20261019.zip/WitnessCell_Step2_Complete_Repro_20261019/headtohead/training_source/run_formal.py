#!/usr/bin/env python3
"""Sequential, resumable matched GEARS/scouter experiment; no outcome-driven tuning."""
from __future__ import annotations
import argparse,datetime,fcntl,hashlib,json,os,subprocess,sys,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent

def sha(p):
 h=hashlib.sha256()
 with open(p,'rb') as f:
  for b in iter(lambda:f.read(8<<20),b''):h.update(b)
 return h.hexdigest()
def dump(p,x):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);tmp=p.with_name(p.name+'.tmp')
 tmp.write_text(json.dumps(x,indent=2,ensure_ascii=False,allow_nan=False)+'\n');tmp.replace(p)
def stamp():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def rel(p):return str(Path(p).resolve().relative_to(ROOT))
def read(p):return json.loads(Path(p).read_text())
def verify_prediction(p,model,fold):
 import numpy as np,h5py
 with zipfile.ZipFile(p) as z:
  if z.testzip() is not None:raise ValueError(f'Corrupt prediction archive: {p}')
 roles=read(ROOT/'data/common_roles.json')['folds'][fold]
 with h5py.File(ROOT/'data/cells.h5','r') as h:genes=h['genes'].asstr()[:]
 with np.load(p,allow_pickle=False) as z:
  for k in z.files:_=z[k]
  if list(z['conditions'].astype(str))!=roles['test_conditions']:raise ValueError('Prediction condition identity/order changed')
  if not np.array_equal(z['genes'].astype(str),genes):raise ValueError('Prediction gene identity/order changed')
  arr=z['pred_mean_'+model]
  if arr.shape!=(len(roles['test_conditions']),len(genes)) or not np.isfinite(arr).all():raise ValueError('Invalid prediction shape or values')
 return {'file':rel(p),'sha256':sha(p),'conditions':len(roles['test_conditions']),'genes':len(genes)}

def verify_gears(where,mode,fold,seed,epochs,step,smoke=False):
 status=read(where/'status.json');meta=read(where/'run_metadata.json');history=read(where/'training_history.json')
 for key,value in {'mode':mode,'fold':fold,'seed':seed,'epochs_cap':epochs,'schedule_step':step}.items():
  if meta[key]!=value:raise ValueError(f'GEARS metadata mismatch {key}')
 if status['completed_epochs']!=sum(not r['partial_epoch'] for r in history):raise ValueError('GEARS history mismatch')
 if smoke:
  if status['test_predictions_written'] or (where/'predictions.npz').exists():raise ValueError('Smoke predicted outer test')
 else:
  if status['partial'] or status['completed_epochs']<1:raise ValueError('Incomplete GEARS fit')
  if mode=='select':
   if not 1<=status['best_epoch']<=status['completed_epochs']:raise ValueError('Invalid GEARS epoch choice')
   if status['test_predictions_written']:raise ValueError('Selection produced outer test prediction')
  elif mode=='refit':
   if status['completed_epochs']!=epochs or not status['test_predictions_written']:raise ValueError('Incomplete GEARS refit')
   verify_prediction(where/'predictions.npz','GEARS',fold)
 return status

def verify_scouter(where,mode,fold,seed,epochs,extension):
 c=read(where/'completion.json');config=read(where/'config.json')
 for k,v in {'mode':mode,'fold':fold,'seed':seed,'epochs':epochs,'extension':extension}.items():
  if config[k]!=v:raise ValueError(f'Scouter metadata mismatch {k}')
 if mode=='pilot':
  if c['outer_test_predicted'] or (where/'prediction.npz').exists():raise ValueError('Smoke predicted outer test')
 else:
  if not c['outer_test_predicted']:raise ValueError('Incomplete scouter run')
  sel=read(where/'selection/selection.json');hist=read(where/'selection/history.json');refit=read(where/'refit/history.json')
  if not 1<=sel['best_epoch']<=len(hist) or len(refit)!=sel['best_epoch']:raise ValueError('Scouter selected/refit epochs mismatch')
  if len(hist)!=sel['epochs_run'] or len(hist) not in (epochs,epochs+extension):raise ValueError('Scouter extension mismatch')
  pp=where/'prediction.npz';verify_prediction(pp,'scouter',fold)
  if sha(pp)!=c['prediction_sha256']:raise ValueError('Scouter prediction hash mismatch')
 return c

def run_stage(where,cmd,identity,validate,restart=False):
 """Resume only a verified completed stage. Never use partial weights."""
 where=Path(where);marker=where/'COMPLETE.json'
 expected={'command':cmd,'identity':identity}
 if marker.exists():
  old=read(marker)
  if old['expected']!=expected:raise ValueError(f'Completed stage differs from current frozen command/input: {where}')
  for row in old['artifacts']:
   f=where/row['path']
   if not f.is_file() or sha(f)!=row['sha256']:raise ValueError(f'Completed artifact missing/changed: {f}')
  result=validate(where);print(f'RESUME verified: {rel(where)}',flush=True);return result
 if where.exists() and any(where.iterdir()):
  if not restart:raise RuntimeError(f'Incomplete/unverified stage exists: {where}. Inspect logs, then use --restart-incomplete to archive and rerun from initialization.')
  target=where.with_name(where.name+'.incomplete_'+datetime.datetime.now().strftime('%Y%m%dT%H%M%S%f'))
  where.rename(target);print(f'Preserved incomplete attempt: {rel(target)}',flush=True)
 where.mkdir(parents=True,exist_ok=True);dump(where/'TASK.json',{'started_utc':stamp(),'expected':expected})
 log=where/'driver.log';print('RUN '+ ' '.join(cmd),flush=True)
 with log.open('w') as f:
  proc=subprocess.Popen([sys.executable,*cmd],cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,bufsize=1)
  try:
   for line in proc.stdout:f.write(line);f.flush();print(line.rstrip(),flush=True)
   rc=proc.wait()
  except BaseException:
   proc.terminate();proc.wait();raise
 if rc:raise RuntimeError(f'Stage failed with exit {rc}: {where}; see driver.log')
 result=validate(where)
 artifacts=[{'path':str(p.relative_to(where)),'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(where.rglob('*')) if p.is_file() and p.name!='COMPLETE.json']
 dump(marker,{'completed_utc':stamp(),'expected':expected,'artifacts':artifacts})
 return result

def build_identity(protocol):
 files=['data/cells.h5','data/common_roles.json','data/inference_controls.json','gears/run_gears.py','gears/vendor/source/gears/model.py','gears/vendor/source/gears/utils.py','gears/assets/gene2go_all.pkl','gears/assets/essential_all_data_pert_genes.pkl','gears/assets/go_essential_all/go_essential_all_top21.csv','scouter/run_scouter.py','scouter/upstream/scouter/_model.py','scouter/upstream/scouter/_datasets.py','scouter/upstream/scouter/_utils.py','scouter/assets/embedding_subset.npz','scoring/score_head_to_head.py','scoring/summarize_seeds.py','scoring/DROP10_FIXED.json','data/evaluation_only.npz','m1_r/global_pair_model.py','m1_r/run_frozen_models.py','code/selection_metrics.py','data/selection_validation_geometry.json']
 for i in range(5):files.append(f'm1_r/fold_{i}/PREDICTIONS.npz')
 identity={'protocol_sha256':sha(protocol),'orchestrator_sha256':sha(__file__),'files':{p:sha(ROOT/p) for p in files}}
 return identity

def main():
 ap=argparse.ArgumentParser(description=__doc__)
 ap.add_argument('--protocol',type=Path,default=ROOT/'protocol.json');ap.add_argument('--device',choices=['auto','cpu','cuda'],default='auto')
 ap.add_argument('--seeds',nargs='+',type=int,default=[0,1,2]);ap.add_argument('--smoke',action='store_true');ap.add_argument('--smoke-max-seconds',type=float,default=120)
 ap.add_argument('--allow-cpu',action='store_true');ap.add_argument('--restart-incomplete',action='store_true');ap.add_argument('--output-root',type=Path,default=ROOT/'formal_runs')
 a=ap.parse_args();a.output_root=a.output_root.resolve()
 if not a.output_root.is_relative_to(ROOT):raise ValueError('Keep output-root inside the portable experiment directory')
 import torch
 device=('cuda' if torch.cuda.is_available() else 'cpu') if a.device=='auto' else a.device
 if device=='cuda' and not torch.cuda.is_available():raise RuntimeError('CUDA requested but unavailable; check bootstrap and GPU driver')
 if not a.smoke and device=='cpu' and not a.allow_cpu:raise RuntimeError('Formal CPU run refused because bounded timing predicts excessive cost. Use GPU or explicitly --allow-cpu.')
 if not a.protocol.is_file():
  if a.smoke:a.protocol=ROOT/'protocol.template.json'
  else:raise FileNotFoundError('Missing frozen protocol.json; do not run formal from a draft')
 protocol=read(a.protocol)
 if not a.smoke and protocol.get('status')!='FROZEN':raise ValueError('Formal requires protocol status FROZEN')
 if not a.smoke and not protocol.get('expected_sha256'):raise ValueError('Formal protocol needs expected_sha256 map')
 for filename,digest in protocol.get('expected_sha256',{}).items():
  if sha(ROOT/filename)!=digest:raise ValueError(f'Frozen source/input changed: {filename}')
 if len(set(a.seeds))!=len(a.seeds) or not set(a.seeds)<=set(protocol['seeds']):raise ValueError('Seeds must be a nonduplicated subset of frozen seeds')
 a.output_root.mkdir(parents=True,exist_ok=True)
 lock=(a.output_root/'.run.lock').open('a')
 try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 except BlockingIOError:raise RuntimeError('Another orchestrator is already using this output directory')
 identity=build_identity(a.protocol);identity['device']=device
 dump(a.output_root/('SMOKE_STARTED.json' if a.smoke else 'FORMAL_STARTED.json'),{'started_utc':stamp(),'identity':identity,'requested_seeds':a.seeds,'smoke':a.smoke})
 g=protocol['GEARS'];s=protocol['scouter'];baseflags=['--device',device]
 if a.smoke:
  seed=a.seeds[0];fold=0;w=a.output_root/'smoke'/f'seed_{seed}'
  gp=w/'GEARS';cmd=['gears/run_gears.py','--mode','pilot','--fold','0','--seed',str(seed),'--epochs','2','--schedule-step','1','--threads',str(g['threads']),'--batch-size',str(g['batch_size']),'--max-train-seconds',str(a.smoke_max_seconds),'--out',rel(gp),*baseflags]
  run_stage(gp,cmd,identity,lambda p:verify_gears(p,'pilot',fold,seed,2,1,True),a.restart_incomplete)
  sp=w/'scouter';cmd=['scouter/run_scouter.py','--mode','pilot','--fold','0','--seed',str(seed),'--epochs','2','--extension','0','--threads',str(s['threads']),'--batch-size',str(s['batch_size']),'--loss-lambda',str(s['loss_lambda']),'--max-seconds',str(a.smoke_max_seconds),'--output',rel(sp),*baseflags]
  run_stage(sp,cmd,identity,lambda p:verify_scouter(p,'pilot',fold,seed,2,0),a.restart_incomplete)
  dump(w/'SMOKE_COMPLETE.json',{'completed_utc':stamp(),'outer_test_predicted':False,'note':'Bounded engineering run; partial epochs are allowed and do not constitute scientific results.'});return
 for seed in a.seeds:
  specs=[];seedroot=a.output_root/f'seed_{seed}'
  for fold in range(5):
   gw=seedroot/'GEARS'/f'fold_{fold}';candidates=[]
   for sch in g['schedules']:
    step=sch['step_size'];epochs=sch['epochs_cap'];where=gw/f'select_step{step}'
    cmd=['gears/run_gears.py','--mode','select','--fold',str(fold),'--seed',str(seed),'--epochs',str(epochs),'--schedule-step',str(step),'--patience',str(g['patience']),'--threads',str(g['threads']),'--batch-size',str(g['batch_size']),'--out',rel(where),*baseflags]
    status=run_stage(where,cmd,identity,lambda p,ep=epochs,st=step:verify_gears(p,'select',fold,seed,ep,st),a.restart_incomplete)
    candidates.append({'step_size':step,'epoch':status['best_epoch'],'validation_score':status['best_validation_score'],'validation_mse':status['best_validation_mse'],'selection_path':rel(where)})
   chosen=min(candidates,key=lambda r:(r['validation_score'],r['validation_mse'],r['step_size'],r['epoch']))
   dump(gw/'SELECTION.json',{'rule':'Lowest fixed4995gene inner-validation same-fit rectangle C-MSE; ties choose lower full-response MSE, smaller schedule step, then earlier epoch. No outer test scores.','candidates':candidates,'chosen':chosen})
   where=gw/'refit';epochs=chosen['epoch'];step=chosen['step_size']
   cmd=['gears/run_gears.py','--mode','refit','--fold',str(fold),'--seed',str(seed),'--epochs',str(epochs),'--schedule-step',str(step),'--threads',str(g['threads']),'--batch-size',str(g['batch_size']),'--predict-test','--out',rel(where),*baseflags]
   run_stage(where,cmd,identity,lambda p:verify_gears(p,'refit',fold,seed,epochs,step),a.restart_incomplete)
   specs.append({'model':'GEARS','fold':fold,'path':rel(where/'predictions.npz'),'key':'pred_mean_GEARS','semantics':'absolute_mean'})
   where=seedroot/'scouter'/f'fold_{fold}'
   cmd=['scouter/run_scouter.py','--mode','formal','--fold',str(fold),'--seed',str(seed),'--epochs',str(s['epochs']),'--extension',str(s['extension']),'--threads',str(s['threads']),'--batch-size',str(s['batch_size']),'--loss-lambda',str(s['loss_lambda']),'--output',rel(where),*baseflags]
   run_stage(where,cmd,identity,lambda p:verify_scouter(p,'formal',fold,seed,s['epochs'],s['extension']),a.restart_incomplete)
   specs.append({'model':'scouter','fold':fold,'path':rel(where/'prediction.npz'),'key':'pred_mean_scouter','semantics':'absolute_mean'})
  # Only complete five-fold outputs enter a score table. Never ensemble seeds.
  spec=a.output_root/f'neural_specs_seed{seed}.json';dump(spec,specs)
  scorewhere=seedroot/'scores'
  cmd=['scoring/score_head_to_head.py','--prediction-spec',rel(spec),'--frozen-protocol',rel(a.protocol),'--output',rel(scorewhere)]
  def scorecheck(p):
   summary=read(p/'SUMMARY.json')
   if summary['status']!='COMPLETE_MATCHED_COMPARISON':raise ValueError('Incomplete common score table')
   return summary
  run_stage(scorewhere,cmd,identity,scorecheck,a.restart_incomplete)
  verification=seedroot/'independent_verification'
  cmd=['review/verify_head_to_head.py','--results',rel(scorewhere),'--output',rel(verification/'VERIFICATION.json')]
  def independentcheck(p):
   report=read(p/'VERIFICATION.json')
   if report['status']!='PASS':raise ValueError('Independent numerical verification failed')
   if report['scored_summary_sha256']!=sha(scorewhere/'SUMMARY.json'):raise ValueError('Independent verification refers to another score table')
   return report
  run_stage(verification,cmd,identity,independentcheck,a.restart_incomplete)
  dump(seedroot/'SEED_COMPLETE.json',{'completed_utc':stamp(),'seed':seed,'folds':5,'neural_prediction_files':10,'ensemble':False,'scores':rel(scorewhere),'protocol_sha256':sha(a.protocol),'independent_verification':rel(verification/'VERIFICATION.json')})
 all_done=all((a.output_root/f'seed_{seed}/SEED_COMPLETE.json').is_file() for seed in protocol['seeds'])
 if all_done:
  where=a.output_root/'final_summary'
  cmd=['scoring/summarize_seeds.py','--run-root',rel(a.output_root),'--protocol',rel(a.protocol),'--output',rel(where)]
  def aggregatecheck(p):
   summary=read(p/'FINAL_PK_SUMMARY.json')
   if summary['status']!='COMPLETED_ALL_THREE_SEEDS':raise ValueError('Incomplete all-seed summary')
   return summary
  run_stage(where,cmd,identity,aggregatecheck,a.restart_incomplete)
 dump(a.output_root/'RUN_COMPLETE.json',{'completed_utc':stamp(),'completed_requested_seeds':a.seeds,'all_frozen_seeds_completed':all_done,'ensemble':False,'note':'Inspect all fixed metrics and all seeds; no seed selection. This is the previously exposed Wessels development panel.'})
if __name__=='__main__':main()
