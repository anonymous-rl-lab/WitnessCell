"""Matched, same-fit Wessels RNA scoring. No training or model selection.

Default invocation scores only frozen M0/M1/R and their common baselines.
Neural predictions are accepted only through an explicit prediction-spec JSON
and a supplied frozen protocol. Never use a global projection on stitched OOF.
"""
import os
for _k in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ[_k] = "1"
import argparse
import csv
import hashlib
import json
import time
import zipfile
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
MODELS = ("additive", "saturation_only", "M0", "M1", "R", "GEARS", "scouter")
VARIANTS = ("raw", "training_condition_variance", "drop_fixed_top10")


def sha(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for b in iter(lambda: f.read(8 * 1024 * 1024), b""):
            h.update(b)
    return h.hexdigest()


def dump(path, value):
    path = Path(path)
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False) + "\n")
    tmp.replace(path)


def save_npz(path, **arrays):
    path = Path(path)
    tmp = path.with_name(path.name + ".tmp")
    with tmp.open("wb") as f:
        np.savez_compressed(f, **arrays)
    with zipfile.ZipFile(tmp) as z:
        assert z.testzip() is None
    with np.load(tmp, allow_pickle=False) as z:
        for k in z.files:
            z[k]
    tmp.replace(path)


def write_csv(path, rows):
    if not rows:
        return
    keys = list(dict.fromkeys(k for r in rows for k in r))
    tmp = Path(str(path) + ".tmp")
    with tmp.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=keys)
        writer.writeheader()
        writer.writerows(rows)
    tmp.replace(path)


def ratio(a, b):
    return float(a / b) if b > 0 else None


def incidence(conditions):
    ends = [str(c).split("+") for c in conditions]
    assert all(len(p) == 2 and p[0] != p[1] for p in ends)
    nodes = sorted(set(g for p in ends for g in p))
    return np.array([[g in p for g in nodes] for p in ends], dtype=float), nodes


def contrast_sign(x):
    for v in ((1, -1, -1, 1), (1, -1, 1, -1), (1, 1, -1, -1)):
        s = np.array(v, dtype=float)
        if np.array_equal(s @ x, np.zeros(x.shape[1])):
            return s
    raise ValueError("Four edges do not form a valid alternating rectangle")


def load_prediction(path, key, semantics, conditions, genes, control):
    with np.load(path, allow_pickle=False) as z:
        pc = z["conditions"].astype(str).tolist()
        pg = z["genes"].astype(str).tolist()
        assert len(pc) == len(set(pc)) and len(pg) == len(set(pg))
        assert set(pc) == set(conditions), (str(path), "test condition mismatch")
        assert set(genes).issubset(pg), (str(path), "readout genes missing")
        y = np.asarray(z[key], dtype=float)
        assert y.shape == (len(pc), len(pg)), (str(path), key, y.shape)
        y = y[[pc.index(c) for c in conditions]][:, [pg.index(g) for g in genes]]
        assert np.all(np.isfinite(y)), (str(path), "nonfinite prediction")
        if semantics == "absolute_mean":
            y = y - control
        elif semantics != "control_effect":
            raise ValueError("Prediction semantics must be absolute_mean or control_effect")
    return y


def default_prediction_specs():
    ans = []
    for fi in range(5):
        p = ROOT / "m1_r" / f"fold_{fi}" / "PREDICTIONS.npz"
        if p.exists():
            for model in MODELS[:5]:
                ans.append(dict(model=model, fold=fi, path=str(p),
                                key=f"pred_effect_{model}", semantics="control_effect"))
    return ans


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--prediction-spec", type=Path,
                    help="JSON list of model/fold/path/key/semantics records; appended to default baselines")
    ap.add_argument("--frozen-protocol", type=Path,
                    help="Required for GEARS/scouter formal scores; no pilot output should be supplied")
    ap.add_argument("--output", type=Path, default=ROOT / "scoring" / "baseline_results")
    args = ap.parse_args()
    start = time.monotonic()
    roles_path = ROOT / "data" / "common_roles.json"
    eval_path = ROOT / "data" / "evaluation_only.npz"
    roles = json.loads(roles_path.read_text())
    drop_path = Path(__file__).with_name("DROP10_FIXED.json")
    drop = json.loads(drop_path.read_text())
    specs = default_prediction_specs()
    if args.prediction_spec:
        specs += json.loads(args.prediction_spec.read_text())
    if any(s["model"] in ("GEARS", "scouter") for s in specs):
        if not args.frozen_protocol or not args.frozen_protocol.is_file():
            raise ValueError("Neural model scoring requires a frozen formal protocol")
    by_fold = {}
    sources = []
    for s in specs:
        assert s["model"] in MODELS, s
        key = (int(s["fold"]), s["model"])
        if key in by_fold:
            raise ValueError(f"Duplicate prediction {key}")
        by_fold[key] = s
        sources.append({**s, "sha256": sha(s["path"])})
    with np.load(eval_path, allow_pickle=False) as z:
        all_conditions = z["conditions"].astype(str).tolist()
        mask = z["score_gene_mask"].astype(bool)
        genes = z["genes"].astype(str)[mask]
        means = np.asarray(z["means"], dtype=float)[:, mask]
        half1 = np.asarray(z["first_means"], dtype=float)[:, mask]
        half2 = np.asarray(z["second_means"], dtype=float)[:, mask]
    assert len(genes) == 4995
    control = means[all_conditions.index("control")]
    eval_lookup = {c: i for i, c in enumerate(all_conditions)}
    out = args.output
    out.mkdir(parents=True, exist_ok=True)
    fold_rows, rectangle_rows, condition_rows, geometry = [], [], [], []
    coverage = {model: [] for model in MODELS}
    block_counter = 0
    retained_drop = ~np.isin(genes, drop["genes"])
    assert int(retained_drop.sum()) == 4985
    for f in roles["folds"]:
        fi = int(f["fold"])
        conditions = f["test_conditions"]
        idx = [eval_lookup[c] for c in conditions]
        truth = means[idx] - control
        x, nodes = incidence(conditions)
        u, sv, _ = np.linalg.svd(x, full_matrices=True)
        rank = int((sv > max(x.shape) * np.finfo(float).eps * sv[0]).sum())
        basis = u[:, rank:]
        expected = (5, 4, 2, 2, 2)[fi]
        assert basis.shape[1] == expected
        assert np.max(abs(basis.T @ x)) < 1e-12
        local = {c: i for i, c in enumerate(conditions)}
        rect_ids, rect_signs, rect_numbers = [], [], []
        for block in f["test_rectangle_blocks"]:
            bi = np.array([local[c] for c in block])
            rect_ids.append(bi)
            rect_signs.append(contrast_sign(x[bi]))
            rect_numbers.append(block_counter)
            block_counter += 1
        c_truth = np.stack([s @ truth[b] for b, s in zip(rect_ids, rect_signs)])
        train_combinations = [c for c in f["outer_train_conditions"] if "+" in c]
        train_variance = np.var(means[[eval_lookup[c] for c in train_combinations]], axis=0, ddof=1)
        positive = train_variance[train_variance > 0]
        floor = float(np.quantile(positive, .01))
        variance = np.maximum(train_variance, floor)
        predictors = {}
        for model in MODELS:
            if (fi, model) in by_fold:
                s = by_fold[(fi, model)]
                predictors[model] = load_prediction(s["path"], s["key"], s["semantics"],
                                                   conditions, genes.tolist(), control)
                coverage[model].append(fi)
        assert all(k in predictors for k in ("additive", "M0")), "Baselines must exist for every scored fold"
        # Direct measured-single reference validates control and additive semantics.
        explicit_additive = np.stack([sum(means[eval_lookup[g]] - control for g in c.split("+")) for c in conditions])
        assert np.max(abs(predictors["additive"] - explicit_additive)) < 1e-12
        c_preds = {m: np.stack([s @ y[b] for b, s in zip(rect_ids, rect_signs)]) for m, y in predictors.items()}
        assert np.max(abs(c_preds["additive"])) < 1e-12
        save_npz(out / f"fold_{fi}_aligned.npz", conditions=np.array(conditions), genes=genes,
                 truth_effect=truth, control=control, incidence=x, nodes=np.array(nodes), contrast_basis=basis,
                 rectangle_indices=np.array(rect_ids), rectangle_signs=np.array(rect_signs),
                 rectangle_numbers=np.array(rect_numbers), C_truth=c_truth,
                 training_condition_variance=train_variance, training_variance_floor=np.array(floor),
                 fixed_top10_keep=retained_drop,
                 **{f"pred_effect_{m}": y for m, y in predictors.items()},
                 **{f"C_pred_{m}": y for m, y in c_preds.items()})
        geometry.append({"fold": fi, "test_conditions": len(conditions), "test_nodes": len(nodes),
                         "incidence_rank": rank, "contrast_dimension": basis.shape[1],
                         "rectangles": len(rect_ids), "training_combinations_for_scale": len(train_combinations),
                         "variance_floor": floor, "variance_floor_gene_count": int((train_variance < floor).sum()),
                         "truth_projection_energy": float(np.sum((basis.T @ truth) ** 2)),
                         "technical_half_cross_projection_energy": float(np.sum((basis.T @ half1[idx]) * (basis.T @ half2[idx]))),
                         "technical_halves_are_not_biological_replicates": True})
        for variant in VARIANTS:
            keep = retained_drop if variant == "drop_fixed_top10" else np.ones(len(genes), bool)
            weight = 1 / variance[keep] if variant == "training_condition_variance" else np.ones(keep.sum())
            yy = truth[:, keep]
            cy = c_truth[:, keep]
            py = basis.T @ yy
            denom_c = float(np.sum(cy * cy * weight))
            denom_p = float(np.sum(py * py * weight))
            calc = {}
            for model, prediction in predictors.items():
                err = prediction[:, keep] - yy
                ce = c_preds[model][:, keep] - cy
                pe = basis.T @ err
                full_per = np.sum(err * err * weight, axis=1)
                rect_per = np.sum(ce * ce * weight, axis=1)
                calc[model] = {"full_SSE": float(full_per.sum()), "C_SSE": float(rect_per.sum()),
                               "projection_SSE": float(np.sum(pe * pe * weight)),
                               "full_per": full_per, "rect_per": rect_per}
            for model, scores in calc.items():
                row = {"variant": variant, "fold": fi, "model": model, "genes": int(keep.sum()),
                       "conditions": len(conditions), "rectangles": len(rect_ids), "contrast_dimension": basis.shape[1],
                       "response_SSE": scores["full_SSE"], "response_coordinates": int(yy.size),
                       "response_MSE": scores["full_SSE"] / yy.size,
                       "response_ratio_vs_M0": ratio(scores["full_SSE"], calc["M0"]["full_SSE"]),
                       "response_ratio_vs_additive": ratio(scores["full_SSE"], calc["additive"]["full_SSE"]),
                       "C_SSE": scores["C_SSE"], "C_coordinates": int(cy.size),
                       "C_MSE": scores["C_SSE"] / cy.size,
                       "C_zero_prediction_SSE": denom_c,
                       "C_ratio_vs_additive": ratio(scores["C_SSE"], denom_c),
                       "C_ratio_vs_M0": ratio(scores["C_SSE"], calc["M0"]["C_SSE"]),
                       "projection_SSE": scores["projection_SSE"], "projection_zero_prediction_SSE": denom_p,
                       "projection_ratio": ratio(scores["projection_SSE"], denom_p)}
                fold_rows.append(row)
                for j, bn in enumerate(rect_numbers):
                    rectangle_rows.append({"variant": variant, "fold": fi, "rectangle": bn, "model": model,
                                           "conditions": "|".join(conditions[i] for i in rect_ids[j]),
                                           "signs": "|".join(str(int(v)) for v in rect_signs[j]),
                                           "genes": int(keep.sum()), "C_MSE": float(scores["rect_per"][j] / keep.sum()),
                                           "C_ratio_vs_M0": ratio(scores["rect_per"][j], calc["M0"]["rect_per"][j]),
                                           "C_truth_energy": float(np.sum(cy[j] * cy[j] * weight))})
                for j, condition in enumerate(conditions):
                    condition_rows.append({"variant": variant, "fold": fi, "condition": condition, "model": model,
                                           "genes": int(keep.sum()), "response_MSE": float(scores["full_per"][j] / keep.sum()),
                                           "response_ratio_vs_M0": ratio(scores["full_per"][j], calc["M0"]["full_per"][j])})
    assert block_counter == 11
    summary_rows = []
    for variant in VARIANTS:
        m0 = [r for r in fold_rows if r["variant"] == variant and r["model"] == "M0"]
        additive = [r for r in fold_rows if r["variant"] == variant and r["model"] == "additive"]
        m0_c = sum(r["C_SSE"] for r in m0)
        m0_full = sum(r["response_SSE"] for r in m0)
        additive_full = sum(r["response_SSE"] for r in additive)
        for model in MODELS:
            selected = [r for r in fold_rows if r["variant"] == variant and r["model"] == model]
            row = {"variant": variant, "model": model, "status": "COMPLETE" if len(selected) == 5 else "PENDING",
                   "available_folds": len(selected), "required_folds": 5}
            if len(selected) == 5:
                cs = sum(r["C_SSE"] for r in selected)
                rs = sum(r["response_SSE"] for r in selected)
                ps = sum(r["projection_SSE"] for r in selected)
                cp = sum(r["C_zero_prediction_SSE"] for r in selected)
                pp = sum(r["projection_zero_prediction_SSE"] for r in selected)
                row.update(conditions=sum(r["conditions"] for r in selected),
                           rectangles=sum(r["rectangles"] for r in selected), genes=selected[0]["genes"],
                           contrast_dimension=sum(r["contrast_dimension"] for r in selected),
                           C_MSE=cs/sum(r["C_coordinates"] for r in selected),
                           C_ratio_vs_additive=ratio(cs, cp), C_ratio_vs_M0=ratio(cs, m0_c),
                           C_gain_over_M0=1-cs/m0_c,
                           response_MSE=rs/sum(r["response_coordinates"] for r in selected),
                           response_ratio_vs_additive=ratio(rs, additive_full), response_ratio_vs_M0=ratio(rs, m0_full),
                           response_gain_over_M0=1-rs/m0_full,
                           projection_ratio=ratio(ps, pp), projection_SSE=ps, projection_truth_energy=pp,
                           rectangles_better_than_M0=sum(r["C_ratio_vs_M0"] < 1 for r in rectangle_rows
                                                        if r["variant"] == variant and r["model"] == model))
            summary_rows.append(row)
    write_csv(out / "SUMMARY_TABLE.csv", summary_rows)
    write_csv(out / "MAIN_TABLE_raw.csv", [r for r in summary_rows if r["variant"] == "raw"])
    write_csv(out / "PER_FOLD.csv", fold_rows)
    write_csv(out / "PER_RECTANGLE.csv", rectangle_rows)
    write_csv(out / "PER_CONDITION.csv", condition_rows)
    summary = {"status": "COMPLETE_MATCHED_COMPARISON" if all(len(coverage[m]) == 5 for m in MODELS) else "PARTIAL_MODEL_COVERAGE",
               "elapsed_seconds": time.monotonic()-start, "task": roles["dataset"], "coverage": coverage,
               "inputs": {"roles": sha(roles_path), "evaluation": sha(eval_path), "fixed_drop10": sha(drop_path),
                          "script": sha(__file__), "frozen_protocol": sha(args.frozen_protocol) if args.frozen_protocol else None},
               "prediction_sources": sources, "geometry": geometry, "summary": summary_rows,
               "scope": "11 fixed rectangles and 55 held-out combinations on a repeatedly exposed development panel; not 12 official benchmark splits.",
               "primary": "Raw C-MSE with every rectangle's four predictions from the same outer fit; equal rectangle and readout weight.",
               "projection_aggregation": "Sum fold-specific projected squared errors / sum fold-specific projected truth energies; never global projection of stitched OOF outputs.",
               "variance_standardization": "Readout-wise variance of outer-training combination condition means (ddof=1); floor at 1st percentile of positive variances. Same denominator for all models in each fold.",
               "fixed_top10_status": drop,
               "inference": "Descriptive point estimates. Rectangles share endpoints; outer folds share training data. No independent-replicate p-values."}
    dump(out / "SUMMARY.json", summary)
    print(json.dumps({"status": summary["status"], "elapsed_seconds": summary["elapsed_seconds"],
                      "coverage": coverage, "raw": [r for r in summary_rows if r["variant"] == "raw"]}, indent=2))


if __name__ == "__main__":
    main()
