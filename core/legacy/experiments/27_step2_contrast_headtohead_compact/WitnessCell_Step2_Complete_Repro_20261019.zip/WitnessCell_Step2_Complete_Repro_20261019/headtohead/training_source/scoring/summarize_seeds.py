#!/usr/bin/env python3
"""Summarize all three fixed optimization seeds; never ensemble predictions.

Refuses missing, partial, mismatched or altered seed results. Optimization ranges
are descriptive and are not confidence intervals over biological replicates.
"""
from __future__ import annotations

import argparse
import csv
import datetime
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
EXPECTED_SEEDS = (0, 1, 2)
MODELS = ("additive", "saturation_only", "M0", "M1", "R", "GEARS", "scouter")
DETERMINISTIC = set(MODELS[:5])
VARIANTS = ("raw", "training_condition_variance", "drop_fixed_top10")
METRICS = ("C_MSE", "C_ratio_vs_additive", "C_ratio_vs_M0", "C_gain_over_M0",
           "response_MSE", "response_ratio_vs_additive", "response_ratio_vs_M0",
           "response_gain_over_M0", "projection_ratio")


def read(path):
    return json.loads(Path(path).read_text())


def sha(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for b in iter(lambda: f.read(8 << 20), b""):
            h.update(b)
    return h.hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def resolve(path):
    p = Path(path)
    return p if p.is_absolute() else ROOT / p


def dump(path, obj):
    tmp = Path(str(path) + ".tmp")
    tmp.write_text(json.dumps(obj, indent=2, ensure_ascii=False, allow_nan=False) + "\n")
    tmp.replace(path)


def csvwrite(path, rows):
    tmp = Path(str(path) + ".tmp")
    with tmp.open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)
    tmp.replace(path)


def load_completed(run_root, protocol_path):
    """Read all scientific inputs before writing any final result artifact."""
    require(protocol_path.is_file(), f"Missing frozen protocol: {protocol_path}")
    protocol = read(protocol_path)
    require(protocol.get("status") == "FROZEN", "A FROZEN protocol is required")
    require(tuple(protocol.get("seeds", [])) == EXPECTED_SEEDS,
            "Protocol must specify all and only seeds [0, 1, 2] in fixed order")
    require(tuple(protocol.get("outer_folds", [])) == (0, 1, 2, 3, 4), "Outer fold identity changed")
    protocol_sha = sha(protocol_path)
    missing = []
    for seed in EXPECTED_SEEDS:
        sr = run_root / f"seed_{seed}"
        for p in (sr / "SEED_COMPLETE.json", sr / "scores" / "SUMMARY.json", sr / "scores" / "COMPLETE.json"):
            if not p.is_file():
                missing.append(str(p))
    require(not missing, "Not all three seeds are complete; missing: " + ", ".join(missing))
    rows = {}
    sources = []
    input_identity = None
    baseline_predictions = {}
    verified_files = {}
    for seed in EXPECTED_SEEDS:
        sr = run_root / f"seed_{seed}"
        marker_path = sr / "SEED_COMPLETE.json"
        summary_path = sr / "scores" / "SUMMARY.json"
        completion_path = sr / "scores" / "COMPLETE.json"
        marker, summary, completion = read(marker_path), read(summary_path), read(completion_path)
        require(marker.get("seed") == seed and marker.get("folds") == 5 and marker.get("neural_prediction_files") == 10,
                f"Seed {seed}: completion identity/coverage mismatch")
        require(marker.get("ensemble") is False, f"Seed {seed}: ensemble output is not the registered comparison")
        require(marker.get("protocol_sha256") == protocol_sha, f"Seed {seed}: protocol mismatch")
        require(resolve(marker["scores"]).resolve() == (sr / "scores").resolve(), f"Seed {seed}: score location mismatch")
        require(summary.get("status") == "COMPLETE_MATCHED_COMPARISON", f"Seed {seed}: incomplete model coverage")
        require(summary["inputs"].get("frozen_protocol") == protocol_sha, f"Seed {seed}: scored under another protocol")
        require(completion["expected"]["identity"]["protocol_sha256"] == protocol_sha,
                f"Seed {seed}: scoring stage protocol differs")
        recorded_summary = [r for r in completion["artifacts"] if r["path"] == "SUMMARY.json"]
        require(len(recorded_summary) == 1 and recorded_summary[0]["sha256"] == sha(summary_path),
                f"Seed {seed}: completed summary altered")
        for name in ("roles", "evaluation", "fixed_drop10", "script", "frozen_protocol"):
            require(name in summary["inputs"], f"Seed {seed}: missing input identity {name}")
        if input_identity is None:
            input_identity = summary["inputs"]
        require(summary["inputs"] == input_identity, f"Seed {seed}: data, scoring code or gene diagnostics differ")
        require(tuple(g["contrast_dimension"] for g in summary["geometry"]) == (5, 4, 2, 2, 2),
                f"Seed {seed}: projection fold identity mismatch")
        for model in MODELS:
            require(summary["coverage"].get(model) == [0, 1, 2, 3, 4], f"Seed {seed}: missing {model} folds")
        pred_identities = {}
        for source in summary["prediction_sources"]:
            key = (source["model"], int(source["fold"]))
            require(key not in pred_identities, f"Seed {seed}: duplicate source {key}")
            path = resolve(source["path"])
            require(path.is_file(), f"Seed {seed}: prediction missing {path}")
            if str(path) not in verified_files:
                verified_files[str(path)] = sha(path)
            require(verified_files[str(path)] == source["sha256"], f"Seed {seed}: prediction changed {path}")
            pred_identities[key] = (source["sha256"], source["key"], source["semantics"])
            if source["model"] in DETERMINISTIC:
                if key in baseline_predictions:
                    require(baseline_predictions[key] == pred_identities[key], f"Deterministic baseline {key} changed across seeds")
                baseline_predictions[key] = pred_identities[key]
        require(set(pred_identities) == {(m, f) for m in MODELS for f in range(5)},
                f"Seed {seed}: prediction-source coverage is not exactly 7 methods by 5 folds")
        per_seed = {}
        for row in summary["summary"]:
            key = (row["variant"], row["model"])
            require(key not in per_seed, f"Seed {seed}: duplicate score row {key}")
            require(row.get("status") == "COMPLETE" and row.get("available_folds") == 5,
                    f"Seed {seed}: incomplete score row {key}")
            require((row.get("conditions"), row.get("rectangles"), row.get("contrast_dimension")) == (55, 11, 15),
                    f"Seed {seed}: task geometry mismatch {key}")
            expected_genes = 4985 if row["variant"] == "drop_fixed_top10" else 4995
            require(row.get("genes") == expected_genes, f"Seed {seed}: readout count mismatch {key}")
            for metric in METRICS:
                val = row.get(metric)
                require(isinstance(val, (int, float)) and float("-inf") < val < float("inf"),
                        f"Seed {seed}: missing/nonfinite metric {key}/{metric}")
            per_seed[key] = row
        require(set(per_seed) == {(v, m) for v in VARIANTS for m in MODELS},
                f"Seed {seed}: score rows differ from registered variants/models")
        rows[seed] = per_seed
        sources.append({"seed": seed, "summary": str(summary_path), "summary_sha256": sha(summary_path),
                        "completion_sha256": sha(completion_path), "seed_marker_sha256": sha(marker_path)})
    for variant in VARIANTS:
        for model in DETERMINISTIC:
            baseline = rows[0][variant, model]
            for seed in EXPECTED_SEEDS[1:]:
                for metric in METRICS:
                    # These are precisely the same frozen outputs and scoring code.
                    require(rows[seed][variant, model][metric] == baseline[metric],
                            f"Deterministic baseline scores changed: {variant}/{model}/{metric}")
    return rows, sources, input_identity, protocol_sha


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--run-root", type=Path, default=ROOT / "formal_runs")
    ap.add_argument("--protocol", type=Path, default=ROOT / "protocol.json")
    ap.add_argument("--output", type=Path)
    args = ap.parse_args()
    run_root = args.run_root.resolve()
    output = args.output or run_root / "final_summary"
    try:
        rows, sources, identity, protocol_sha = load_completed(run_root, args.protocol)
    except (OSError, ValueError, KeyError, TypeError) as e:
        print(json.dumps({"status": "NOT_COMPLETED", "reason": str(e), "final_results_written": False}, ensure_ascii=False))
        raise SystemExit(2)
    tables = {}
    all_seed_rows = []
    for variant in VARIANTS:
        table = []
        for model in MODELS:
            deterministic = model in DETERMINISTIC
            # A deterministic result is one realization, not three replicates.
            selected_seeds = (0,) if deterministic else EXPECTED_SEEDS
            row = {"model": model, "variant": variant, "status": "COMPLETE",
                   "realization_count": len(selected_seeds),
                   "realization_type": "one_fixed_deterministic_output" if deterministic else "three_optimization_seeds",
                   "conditions": 55, "rectangles": 11, "contrast_dimension": 15,
                   "genes": 4985 if variant == "drop_fixed_top10" else 4995}
            for metric in METRICS:
                vals = [rows[s][variant, model][metric] for s in selected_seeds]
                row[metric + "_mean"] = sum(vals) / len(vals)
                row[metric + "_min"] = min(vals)
                row[metric + "_max"] = max(vals)
            row["range_interpretation"] = "No stochastic repeats" if deterministic else "Optimization-seed range; not biological confidence interval"
            table.append(row)
            for seed in selected_seeds:
                all_seed_rows.append({"model": model, "variant": variant,
                                      "optimization_seed": "fixed" if deterministic else seed,
                                      **{m: rows[seed][variant, model][m] for m in METRICS}})
        tables[variant] = table
    output.mkdir(parents=True, exist_ok=True)
    names = {"raw": "FINAL_PK_TABLE.csv", "training_condition_variance": "FINAL_PK_TABLE_STANDARDIZED.csv",
             "drop_fixed_top10": "FINAL_PK_TABLE_DROP10.csv"}
    for variant, name in names.items():
        csvwrite(output / name, tables[variant])
    csvwrite(output / "ALL_SEED_METRICS.csv", all_seed_rows)
    summary = {"status": "COMPLETED_ALL_THREE_SEEDS", "completed_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
               "seeds": list(EXPECTED_SEEDS), "protocol_sha256": protocol_sha, "common_input_identity": identity,
               "scorer_sha256": sha(__file__), "sources": sources, "tables": tables,
               "aggregation": "Arithmetic mean, minimum and maximum of per-seed metric values. Predictions are never averaged. Fixed deterministic results are represented once.",
               "inference": "Seed ranges measure optimization variation, not independent biological replication or confidence intervals.",
               "scope": "Repeatedly exposed Wessels55 development panel; not independent biological confirmation and not the 12 official benchmark splits."}
    dump(output / "FINAL_PK_SUMMARY.json", summary)
    artifacts = {p.name: sha(p) for p in [output / n for n in names.values()] + [output / "ALL_SEED_METRICS.csv", output / "FINAL_PK_SUMMARY.json"]}
    dump(output / "SUMMARY_COMPLETE.json", {"status": "COMPLETED_ALL_THREE_SEEDS", "seeds": list(EXPECTED_SEEDS),
                                           "protocol_sha256": protocol_sha, "artifacts": artifacts})
    print(json.dumps({"status": summary["status"], "output": str(output), "seeds": list(EXPECTED_SEEDS),
                      "neural_realizations_per_method": 3, "deterministic_realizations_per_method": 1}, ensure_ascii=False))


if __name__ == "__main__":
    main()
