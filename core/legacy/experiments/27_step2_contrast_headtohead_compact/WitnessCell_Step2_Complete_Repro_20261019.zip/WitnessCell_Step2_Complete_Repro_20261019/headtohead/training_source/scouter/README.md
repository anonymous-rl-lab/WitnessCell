# Scouter in the common Wessels head-to-head

The original Scouter `ScouterModel`, `BalancedDataset`, and `gears_loss` are imported directly from the pinned authors' repository. No replacement architecture is used.

- Repository: https://github.com/PancakeZoy/scouter
- Commit: fe2a73bdda02c9ec639bd55dabe758da2f7ff335
- Authors' reproduction repository: https://github.com/PancakeZoy/scouter_misc
- Reproduction commit inspected: 6f2c83e5a32505038060155ca8257fa094732e35
- Embedding: published GenePT v2, a supported choice in the authors' embedding table. This is explicitly **Scouter + GenePT v2**, not an assertion that the old scPerturBench run used the same embedding/version. The authors' current Norman reproduction script uses scELMo embeddings.
- Encoder: 5020 → 2048 → 512 → 64. The two perturbed-gene embeddings are summed, concatenated with encoded control expression, then passed through the 2048-unit nonlinear generator to 5020 outputs.
- Batch normalization, SELU, no dropout; Adam lr .001, exponential scheduler .9, batch 256, gradient norm clip 1.0. Loss gamma 0 and lambda .05 as in the authors' Norman reproduction script.

Changes restricted to experiment plumbing:

1. Fixed shared outer folds and inner validation identities replace the package's random split function.
2. Only outer-training expression rows are read. Outer-test expression is never passed to the learner. Nonzero masks come only from the cells currently used for training.
3. Training duration is selected on the shared 4995-gene validation rectangle C-MSE over the three original held-out inner rectangles, then the network is refit on all outer-training conditions for the selected duration. This matches the common prediction task. Full-response MSE is only an exact-tie secondary criterion, followed by earliest epoch. The package otherwise selects by its cell-level loss.
4. Best checkpoint tensors are cloned on save, avoiding the upstream `state_dict()` reference aliasing problem.
5. Validation predictions average the same fixed 64 control cells; final predictions average the same fixed 300 control cells, supplied in `data/inference_controls.json`. The same control sample is reused at every combination, so independent Monte Carlo noise cannot fabricate rectangle differences. This estimates a conditional mean with the original network.
6. All 5020 predicted genes are exported. The shared scorer uses the previously frozen 4995 non-target coordinates.

The 2-epoch pilot has an explicit wall-time cap and cannot emit outer-test predictions. Formal training first uses 40 epochs. A predeclared extension of 40 additional epochs applies only if the best validation epoch is among the final 5 and their best validation C-MSE is more than 1% lower than the best earlier epoch. No outer-test result is available for this decision.

This repeatedly studied Wessels panel remains a development comparison, even though all four methods use identical outer-test conditions. It is not a new external confirmation panel.
