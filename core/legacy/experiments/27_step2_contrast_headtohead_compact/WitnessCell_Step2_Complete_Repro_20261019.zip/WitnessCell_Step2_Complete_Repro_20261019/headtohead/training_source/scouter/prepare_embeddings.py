#!/usr/bin/env python3
"""Subset published GenePT embeddings to fixed target names, without RNA outcomes."""
import argparse,hashlib,json,pickle,os
from pathlib import Path
import numpy as np
import pandas as pd
p=argparse.ArgumentParser();p.add_argument('--source',required=True);p.add_argument('--roles',default='head_to_head_20261018/data/common_roles.json');p.add_argument('--output',default='head_to_head_20261018/scouter/assets/embedding_subset.npz');a=p.parse_args()
src=Path(a.source)
with src.open('rb') as f:o=pickle.load(f)
print(type(o),len(o),flush=True)
r=json.loads(Path(a.roles).read_text());names=sorted(set(g for c in r['conditions'] if c!='control' for g in c.split('+')))
missing=sorted(set(names)-set(o.index if isinstance(o,pd.DataFrame) else o));assert not missing,missing
e=o.loc[names] if isinstance(o,pd.DataFrame) else pd.DataFrame({n:o[n] for n in names}).T
e.index=e.index.astype(str)
x=e.loc[names].to_numpy(dtype=np.float32)
assert np.isfinite(x).all()
q=Path(a.output);q.parent.mkdir(exist_ok=True,parents=True);tmp=q.with_suffix('.tmp')
with tmp.open('wb') as f:np.savez_compressed(f,genes=np.array(names),embedding=x)
os.replace(tmp,q)
def sha(f):
 h=hashlib.sha256()
 with open(f,'rb') as q:
  while b:=q.read(1<<20):h.update(b)
 return h.hexdigest()
meta={'source':'GenePT v2 published embedding, official Scouter supported option','source_url':'https://zenodo.org/records/10833191/files/GenePT_emebdding_v2.zip?download=1','source_pickle_sha256':sha(src),'subset_sha256':sha(q),'genes':names,'shape':list(x.shape),'missing_genes':missing,'ctrl_embedding':'zero vector inserted by runner per official tutorial','selected_without_RNA_outcomes':True}
q.with_suffix('.json').write_text(json.dumps(meta,indent=2));print(json.dumps(meta,indent=2))
