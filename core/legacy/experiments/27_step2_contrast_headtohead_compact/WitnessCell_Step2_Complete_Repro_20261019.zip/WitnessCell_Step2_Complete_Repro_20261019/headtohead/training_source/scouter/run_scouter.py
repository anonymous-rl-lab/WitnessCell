#!/usr/bin/env python3
"""Pinned upstream Scouter network, loss and balanced cell sampler on common folds.
No outer-test expression rows are read by this program. Validation is used only
for selecting training duration; final fit uses every outer-training condition.
"""
from __future__ import annotations
import argparse, json, os, time, hashlib, random, sys, pickle
from pathlib import Path
import numpy as np
import h5py
import torch
from torch.utils.data import DataLoader
from scipy import sparse
import pandas as pd
import anndata as ad
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'upstream'))
sys.path.insert(0,str(HERE.parent/'code'))
from selection_metrics import load_validation_geometry, validation_metrics, selection_key
from scouter._model import ScouterModel
from scouter._datasets import BalancedDataset
from scouter._utils import gears_loss


def atomic_json(p,x):
 p=Path(p); p.parent.mkdir(parents=True,exist_ok=True)
 q=p.with_suffix(p.suffix+'.tmp');q.write_text(json.dumps(x,indent=2));os.replace(q,p)

def sha(p):
 h=hashlib.sha256()
 with open(p,'rb') as f:
  while b:=f.read(1<<20):h.update(b)
 return h.hexdigest()

def canon(c):
 return 'ctrl' if c=='control' else c if '+' in c else c+'+ctrl'

def set_seed(s):
 random.seed(s); np.random.seed(s);torch.manual_seed(s)
 if torch.cuda.is_available():torch.cuda.manual_seed_all(s)

def load_embeddings(path,pertnames):
 if path.suffix=='.npz':
  with np.load(path,allow_pickle=False) as z:
   names=z['genes'].astype(str).tolist();v=z['embedding']
  emb=pd.DataFrame(v,index=names)
 else:
  with open(path,'rb') as f:obj=pickle.load(f)
  emb=obj if isinstance(obj,pd.DataFrame) else pd.DataFrame(obj).T
 emb.index=emb.index.astype(str)
 if emb.index.duplicated().any():raise ValueError('Duplicated gene embeddings')
 needed=sorted(set(g for c in pertnames for g in canon(c).split('+')))
 emb.loc['ctrl']=np.zeros(emb.shape[1])
 missing=sorted(set(needed)-set(emb.index))
 if missing:raise ValueError(f'Missing required perturbation embeddings: {missing}')
 emb=emb.loc[needed].astype(np.float32)
 return emb

class Data:
 def __init__(self,root,fold,embedding):
  self.root=Path(root);self.roles=json.loads((self.root/'common_roles.json').read_text())['folds'][fold]
  self.validation_geometry=load_validation_geometry(self.root,fold)
  self.controls=json.loads((self.root/'inference_controls.json').read_text())
  # Read only allowed training/validation expression and unperturbed controls.
  with h5py.File(self.root/'cells.h5') as h:
   self.conditions=h['condition_names'].asstr()[:];self.genes=h['genes'].asstr()[:]
   ci=h['condition_index'][:];self.score_mask=h['score_gene_mask'][:]
   self.cell_names=h['cell_names'].asstr()[:]
   allowed=set(self.roles['outer_train_conditions'])
   rows=np.where(np.isin(self.conditions[ci],list(allowed)))[0]
   self.rows=rows; self.rowmap={int(k):i for i,k in enumerate(rows)}
   self.X=h['X'][rows];self.labels=self.conditions[ci[rows]]
  self.emb=load_embeddings(Path(embedding),self.roles['outer_train_conditions']+self.roles['test_conditions'])
  self.embdict={x:i for i,x in enumerate(self.emb.index)}
  self.n_genes=len(self.genes)
  self.ctrl=self.X[self.labels=='control'].mean(axis=0,dtype=np.float64)
 def adata(self,conds):
  mask=np.isin(self.labels,list(conds));x=self.X[mask]
  labels=[canon(c) for c in self.labels[mask]]
  obs=pd.DataFrame({'condition':labels},index=self.cell_names[self.rows[mask]])
  obs['embd_index']=[[self.embdict[g] for g in c.split('+')] for c in labels]
  return ad.AnnData(sparse.csr_matrix(x),obs=obs,var=pd.DataFrame({'gene_name':self.genes},index=self.genes))
 def controls_tensor(self,validation):
  key='validation_cell_indices' if validation else 'test_cell_indices'
  rows=self.controls[key]
  return torch.from_numpy(np.asarray(self.X[[self.rowmap[int(i)] for i in rows]],dtype=np.float32))
 def truth(self,conditions):
  return np.stack([self.X[self.labels==c].mean(axis=0,dtype=np.float64) for c in conditions])

def build_model(d):
 return ScouterModel(d.n_genes,torch.tensor(d.emb.values),n_encoder=(2048,512),n_out_encoder=64,n_decoder=(2048,),use_batch_norm=True,use_layer_norm=False,dropout_rate=0.)

def prediction(model,d,conditions,validation):
 model.eval();device=next(model.parameters()).device;ctrl=d.controls_tensor(validation).to(device);out=[]
 with torch.no_grad():
  for c in conditions:
   p=torch.tensor([[d.embdict[g] for g in canon(c).split('+')]],dtype=torch.long,device=device).repeat(len(ctrl),1)
   vals=[]
   for start in range(0,len(ctrl),64): vals.append(model(p[start:start+64],ctrl[start:start+64]).detach().cpu().numpy())
   out.append(np.concatenate(vals).mean(axis=0,dtype=np.float64))
 return np.stack(out)

def fit(d,conds,epochs,seed,args,outdir,validation=None,extension=0):
 outdir.mkdir(parents=True,exist_ok=True);set_seed(seed)
 a=d.adata(conds);ds=BalancedDataset(a,'condition','embd_index',seed=24)
 labeldict=dict(zip(a.obs.index,a.obs.condition))
 nz={c:np.where(np.asarray(a[a.obs.condition==c].X.sum(axis=0)).ravel()!=0)[0] for c in set(a.obs.condition)-{'ctrl'}}
 loader=DataLoader(ds,batch_size=args.batch_size,drop_last=True,shuffle=True,num_workers=0)
 model=build_model(d).to(args.device);opt=torch.optim.Adam(model.parameters(),lr=.001)
 sched=torch.optim.lr_scheduler.ExponentialLR(opt,gamma=.9)
 truth=d.truth(validation) if validation is not None else None
 hist=[];start=time.time();best=float('inf');best_key=(float('inf'),float('inf'),0);best_epoch=0; cap=epochs;epoch=0;extended=False
 while epoch<cap:
  epoch+=1;model.train();losses=[];t=time.time()
  for batch,(ctrl,y,pi,barcodes) in enumerate(loader):
   ctrl,y,pi=ctrl.to(args.device),y.to(args.device),pi.to(args.device)
   opt.zero_grad();pred=model(pi,ctrl)
   loss=gears_loss(pred,y,ctrl,[labeldict[b] for b in barcodes],nz,gamma=0.,lambda_=args.loss_lambda)
   loss.backward();torch.nn.utils.clip_grad_norm_(model.parameters(),max_norm=1.);opt.step();losses.append(float(loss.detach()))
   if args.max_seconds and time.time()-start>args.max_seconds:
    atomic_json(outdir/'bounded_stop.json',{'epoch':epoch,'completed_batches':batch+1,'wall_seconds':time.time()-start,'reason':'bounded pilot train-time limit','no_outer_test_predictions':True})
    return model,hist,None,True
  sched.step();val=None;metrics={'validation_C_MSE':None,'validation_condition_mean_mse':None,'validation_rectangles':None}
  if validation is not None:
   pr=prediction(model,d,validation,True)
   metrics=validation_metrics(pr,truth,validation,d.score_mask,d.validation_geometry)
   val=metrics['validation_C_MSE'];key=selection_key(metrics,epoch)
   if key<best_key:
    best=val;best_key=key;best_epoch=epoch
    torch.save({k:v.detach().cpu().clone() for k,v in model.state_dict().items()},outdir/'best_validation_state.pt')
  row={'epoch':epoch,'train_loss':float(np.mean(losses)),**metrics,'seconds':time.time()-t,'cumulative_seconds':time.time()-start,'learning_rate':opt.param_groups[0]['lr']}
  hist.append(row);atomic_json(outdir/'history.json',hist);print(json.dumps(row),flush=True)
  if epoch==epochs and extension>0 and validation is not None:
   # Only a validation-defined duration extension, never an outer-test decision.
   first=min(h['validation_C_MSE'] for h in hist[:-5]) if len(hist)>5 else float('inf')
   last=min(h['validation_C_MSE'] for h in hist[-5:])
   if best_epoch>epochs-5 and last<first*.99:cap=epochs+extension;extended=True
 if validation is not None:
  atomic_json(outdir/'selection.json',{'best_epoch':best_epoch,'best_validation_C_MSE':best,'best_selection_key':list(best_key),'epochs_run':epoch,'cap_reached_with_best_in_last5':best_epoch>epoch-5,'extended':extended,'extension_rule':'best in last 5 epochs and validation C-MSE >1% lower than best before last 5'})
 else:torch.save({k:v.detach().cpu().clone() for k,v in model.state_dict().items()},outdir/'refit_state.pt')
 return model,hist,best_epoch,False

def main():
 p=argparse.ArgumentParser();p.add_argument('--data',default=str(HERE.parent/'data'));p.add_argument('--embedding',default=str(HERE/'assets/embedding_subset.npz'));p.add_argument('--fold',type=int,default=0);p.add_argument('--seed',type=int,default=24);p.add_argument('--mode',choices=['pilot','formal'],required=True);p.add_argument('--epochs',type=int,default=40);p.add_argument('--extension',type=int,default=40);p.add_argument('--threads',type=int,default=2);p.add_argument('--batch-size',type=int,default=256);p.add_argument('--loss-lambda',type=float,default=.05);p.add_argument('--max-seconds',type=float,default=0);p.add_argument('--output');p.add_argument('--device',default='auto');args=p.parse_args()
 args.device=('cuda' if torch.cuda.is_available() else 'cpu') if args.device=='auto' else args.device
 torch.set_num_threads(args.threads);torch.set_num_interop_threads(1)
 out=Path(args.output) if args.output else HERE/'results'/f'{args.mode}_fold{args.fold}_seed{args.seed}'
 out.mkdir(parents=True,exist_ok=True)
 d=Data(args.data,args.fold,args.embedding)
 config=vars(args)|{'model':'Scouter','upstream_commit':'fe2a73bdda02c9ec639bd55dabe758da2f7ff335','source_model_sha256':sha(HERE/'upstream/scouter/_model.py'),'source_loss_sha256':sha(HERE/'upstream/scouter/_utils.py'),'embedding_sha256':sha(args.embedding),'input_cells_sha256':sha(Path(args.data)/'cells.h5'),'roles_sha256':sha(Path(args.data)/'common_roles.json'),'validation_geometry_sha256':sha(Path(args.data)/'selection_validation_geometry.json'),'selection_metric':'frozen original inner0 rectangle C-MSE; full MSE exact tie-break then earliest epoch','genes':len(d.genes),'scored_genes':int(d.score_mask.sum()),'architecture':{'encoder':[2048,512],'latent':64,'decoder':[2048],'batch_norm':True,'dropout':0},'device':args.device,'runner_sha256':sha(__file__),'parameters':sum(p.numel() for p in build_model(d).parameters())}
 atomic_json(out/'config.json',config)
 _,hist,best,stopped=fit(d,d.roles['selection_train_conditions'],args.epochs,args.seed,args,out/'selection',d.roles['selection_validation_conditions'],0 if args.mode=='pilot' else args.extension)
 if args.mode=='pilot' or stopped:
  atomic_json(out/'completion.json',{'mode':args.mode,'bounded_stop':stopped,'epochs_completed':len(hist),'outer_test_predicted':False});return
 model,refithist,_,stopped=fit(d,d.roles['outer_train_conditions'],best,args.seed,args,out/'refit')
 if stopped:raise RuntimeError('Formal refit interrupted by max-seconds; no scoring output')
 pred=prediction(model,d,d.roles['test_conditions'],False)
 target=out/'prediction.npz';tmp=out/'prediction.npz.tmp'
 with open(tmp,'wb') as f:np.savez_compressed(f,conditions=np.array(d.roles['test_conditions']),genes=d.genes,pred_mean_scouter=pred,control_mean=d.ctrl,control_source_cell_indices=np.array(d.controls['test_cell_indices']),model_seed=args.seed,fold=args.fold)
 os.replace(tmp,target)
 atomic_json(out/'completion.json',{'mode':args.mode,'best_epoch':best,'outer_test_predicted':True,'prediction_sha256':sha(target),'test_condition_count':len(pred),'all_finite':bool(np.isfinite(pred).all())})
if __name__=='__main__':main()
