#!/usr/bin/env python3
"""Plot the regenerated numerical tables, without loading stored plot values."""
import argparse,csv
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

def rows(p):
    with p.open(newline='') as f:return list(csv.DictReader(f))

def main():
    p=argparse.ArgumentParser();p.add_argument('--results',type=Path,required=True);a=p.parse_args()
    old={r['dataset']:r for r in rows(a.results/'A_Official12_Dataset_Summary.csv')}
    new={r['model']:r for r in rows(a.results/'B_Matched55_Model_Comparison.csv')}
    plt.rcParams.update({'font.size':10,'axes.titlesize':11,'svg.fonttype':'none','font.family':'DejaVu Sans'})
    fig,axes=plt.subplots(1,3,figsize=(15,4.7),layout='constrained',gridspec_kw={'width_ratios':[1,1,1.15]})
    ax,bx,cx=axes;datasets=['Wessels','Norman','Replogle_exp6','Schmidt']
    for i,d in enumerate(datasets):
        v=100*float(old[d]['full_response_gain_vs_joint_backbone']);pv=100*float(old[d]['projected_error_gain_vs_joint_backbone'])
        ax.barh(i,v,height=.6,color='#6b87a7',label='Full response' if i==0 else None)
        ax.scatter(pv,i,marker='D',s=40,color='#e49d2a',zorder=4,label='Endpoint-eliminated' if i==0 else None)
        ax.text(v+.7,i,f'{v:.2f}%',va='center',fontsize=9)
    ax.set_yticks(range(4),datasets);ax.invert_yaxis();ax.set_xlim(-1.5,39)
    ax.set_title('A  What the endpoint branch improves\n12 published splits; all readouts',loc='left');ax.set_xlabel('Error reduction vs joint backbone (%)');ax.legend(frameon=False,loc='lower right',fontsize=8)
    models=['M0','M1','R','GEARS','scouter'];colors=['#77838f','#72b7aa','#087f8c','#e6a03c','#9d83ba']
    for i,(m,c) in enumerate(zip(models,colors)):
        r=new[m];v=float(r['projection_ratio']);lo=float(r['projection_ratio_min']);hi=float(r['projection_ratio_max'])
        bx.barh(i,v,height=.6,color=c)
        if m in ('GEARS','scouter'):bx.errorbar(v,i,xerr=[[v-lo],[hi-v]],fmt='none',ecolor='#1f2937',capsize=3,lw=1)
        bx.text(max(v,hi)+.014,i,f'{v:.4f}',va='center',fontsize=9)
    bx.set_yticks(range(5),models);bx.invert_yaxis();bx.set_xlim(0,1.16);bx.axvline(1,color='#6b7280',lw=1,ls='--')
    bx.set_title('B  Recovering combination contrasts\nMatched55 RNA task; 4,995 non-target readouts',loc='left');bx.set_xlabel('Endpoint-eliminated error ratio (lower is better)')
    for m,offset,c in [('M1',-.18,'#72b7aa'),('R',.18,'#087f8c')]:
        vals=[100*float(new[m][k]) for k in ('C_gain_vs_M0','standardized_C_gain_vs_M0','drop10_C_gain_vs_M0')]
        cx.bar(np.arange(3)+offset,vals,width=.34,color=c,label=m)
        for x,v in zip(np.arange(3)+offset,vals):cx.text(x,v+(.6 if v>=0 else -.6),f'{v:+.2f}',ha='center',va='bottom' if v>=0 else 'top',fontsize=9)
    cx.axhline(0,color='#64748b',lw=1);cx.set_ylim(-13,20);cx.set_xticks(range(3),['Original\nscale','Variance\nstandardized','Fixed 10\ngenes removed'])
    cx.set_ylabel('Rectangle error reduction vs M0 (%)');cx.set_title('C  Where the incremental benefit lies\nMatched55 task; training-derived scaling',loc='left');cx.legend(frameon=False,loc='upper right')
    for x in axes:x.spines[['top','right']].set_visible(False)
    for ext in ('png','svg'):fig.savefig(a.results/('Integrated_Evidence.'+ext),dpi=220)
    plt.close(fig)

if __name__=='__main__':main()
