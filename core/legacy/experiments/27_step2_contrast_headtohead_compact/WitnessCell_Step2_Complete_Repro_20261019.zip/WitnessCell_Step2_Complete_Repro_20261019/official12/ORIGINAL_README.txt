WitnessCell Prediction Contrast Audit, 2026-10-18

This package scores archived predictions on the twelve release-matched test graphs. It does not train new predictors and does not claim that GEARS/CPA or the later 55-pair M0/M1/R experiment were evaluated on these graphs.

Start with PREDICTION_AUDIT_RESULTS_CN.txt and results/MAIN_TABLE_all_genes_raw.csv.
Full precision data: results/formal/MODEL_SCORES.json (234 rows), INCREMENT_AUDIT.json, DATASET_SUMMARY.json.
The 8 model columns in the main table are the available archived predictors/references. They are not eight independent external methods. NA marks no matched saved output, never an estimated score.

Sources: sources/materialized contains the original 34 NPZ arrays (12 deployment, four measurement contracts, six sets of three Step1 files). sources/PREDICTION_ASSET_INDEX.json records the exact canonical object keys and original SHA256. It also lists 36 incompatible custom-split GEARS/CPA files for availability documentation; these files are not used or included here. Their paths are not required to reproduce this audit. Source code snapshots are in sources/code_provenance.
sources/graph contains release identity checks, role lists and the twelve complete contrast bases from the preceding graph audit.
results/formal/<dataset>_seed<seed>/aligned_arrays.npz retains aligned input/effects, original gene/condition identities, full X/Z, fixed training scales and common target-exclusion mask.

Runtime: Python3 with NumPy; no GPU, downloads or training required.
Production scoring:
  python3 code/run_prediction_audit.py pilot
  python3 code/run_prediction_audit.py formal
For a rerun, make a separate copy of the package first and move its existing results/pilot and results/formal directories aside. The runner refuses to overwrite existing results and verifies AUDIT_LOCK.json before scoring. Preserve the original lock; do not run freeze again on a completed audit. Default limits are 60 and 300 compute seconds respectively.
Synthetic metric check:
  python3 code/projection_metrics.py --selftest
Independent verification (rewrites only its own audit reports):
  python3 code/verify_prediction_audit.py

This was an internally frozen retrospective diagnosis of already studied panels, not a new independent biological confirmation. Cell-half reproducibility is descriptive and does not establish biological-replicate uncertainty. Seeds overlap; no across-seed significance test is reported.
Original manuscript and grn_repo_v20 are unchanged. This is a standalone incremental experiment bundle.
