12 个发布划分：精确结果重算模块

快速运行（仅需 Python 3 和 NumPy）：
  python official12/reproduce.py --output reproduced/official12

输出：234 行 MODEL_SCORES、36 行 INCREMENT_AUDIT、全部三套 MAIN_TABLE、DATASET_SUMMARY、36 项浮点量化包络检查及 REPRODUCTION_CHECK.json。
覆盖四数据集×三种子、540 个组合—种子单元、212 个端点消去维数。它们不是540个不同组合，也不是212次独立生物学实验。

精简方式
原 aligned_arrays.npz 共155,248,383字节，完整保留在原 WitnessCell_Prediction_Contrast_Audit_20261018.zip 中，未再次复制进 v22；本小包以 float64 充分统计量代替完整矩阵。
extract_sufficient_statistics.py 逐个读取原始对齐数组，先按原评价规则构造全部三套变换：原始尺度、统一剔除面板靶点、训练方差标准化；再计算真值/预测在 Z 和 P 空间中的平方和、交叉积、完整响应误差、细胞半重复交叉积与v14增量。
每项由连续64个基因的分块和构成，另存一次 float64 求和顺序校正。该校正等于“在原矩阵上直接求和减去分块和的总和”，用于保留原数组归约顺序；它不是四舍五入，也不从已发表结果表复制。max类统计按分块最大值保存。
图的 X、Z、组合及基因身份、统一靶点mask、完整训练方差/尺度/方差下限、训练条件与来源哈希同时保留。原始模型代码及原评分代码保持原样放在 original_model_code 和 original_code。

计算和核对彼此独立
reproduce.py 只使用 data/*.npz 与对应身份文件生成全部结果。expected/ 中的原始表仅在生成后作核对；删除 expected 或使用 --no-verify 不改变结果计算。
本次7215项数值核对最大绝对差为2.7755575615628914e-17，234行评分、36行增量和全部图表相关数值恢复。
适用范围是精确重算既定指标。充分统计量不可逆，不能据此恢复完整逐预测向量、重新训练模型、修改任意基因mask或计算未保存的新指标。需要这些任务时，应使用总代码包保留的完整 aligned_arrays.npz 和相应原模型输入；小包不冒充无损预测归档。

从完整资产重新产生充分统计量
  python official12/extract_sufficient_statistics.py --source /path/to/WitnessCell_Prediction_Contrast_Audit_20261018 --output /tmp/official12_stats
source目录应包含 results/formal/{dataset}_seed{seed}/aligned_arrays.npz 和 identity.json。
此命令不会读取 MODEL_SCORES 或其他最终评分表，保留提取脚本可供逐行检查。

评价口径
投影误差比 = ||Z^T(prediction-truth)||² / ||Z^T truth||²。
P=I−XX⁺，与ZZ^T一致。全部缩放及共同mask按原实验规则；不按每条边分别去靶点。
v14 与它自己的联合饱和骨架比较；二者不是后续55组合任务中M0的别名。
GEARS/scouter/M1/R的新结果使用不同55组合任务，并未填入这12个划分的缺项。
Schmidt和Replogle_exp6没有匹配Step1额外基线的6个划分维持NA。
trainMean为原保存的端点均值补全预测，不是恒定向量。
原始实验档案中的独立核验由源contract/deploy/baseline重建真值及预测；小包只重算已定义指标，不能替代原始数据真实性检查。
