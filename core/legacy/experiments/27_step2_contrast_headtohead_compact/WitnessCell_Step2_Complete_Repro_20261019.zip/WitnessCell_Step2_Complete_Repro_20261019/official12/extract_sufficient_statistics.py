#!/usr/bin/env python3
"""Derive compact float64 statistics from ORIGINAL aligned prediction arrays.
This does not read score tables. The reduction preserves only the registered
three metric families, not recoverable predictions or arbitrary new masks.
"""
import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'): os.environ[k]='1'
import argparse,hashlib,json
from pathlib import Path
import numpy as np
DATASETS=['Norman','Wessels','Schmidt','Replogle_exp6']
MODELS=['WitnessCell_v14','v14_joint_saturation_backbone','WitnessCell_v1_archived','v1_joint_saturation_backbone','zero_contrast_reference','Step1_trainMean','Step1_shared_endpoint_additive','Step1_saturation_only']
MODES=['all_genes_raw','exclude_panel_targets','training_variance_standardized']
BLOCK=64

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def half_ulp32(value):
 x=value.astype(np.float64)
 return .5*np.maximum(np.nextafter(value,np.float32(np.inf)).astype(float)-x,x-np.nextafter(value,np.float32(-np.inf)).astype(float))
def block_stats(x):
 """Gene blocks + float64 reduction-order correction reproduce original sum.
 The correction is calculated from the original array, never copied scores.
 """
 x=np.asarray(x,dtype=np.float64)
 sums=np.array([np.sum(x[:,i:i+BLOCK]) for i in range(0,x.shape[1],BLOCK)],dtype=np.float64)
 return np.r_[sums,np.float64(np.sum(x)-np.sum(sums))]
def add(store,name,x):store[name]=block_stats(x)
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--source',type=Path,required=True);ap.add_argument('--output',type=Path,default=Path(__file__).parent/'data');args=ap.parse_args()
 args.output.mkdir(parents=True,exist_ok=True);manifest=[]
 for ds in DATASETS:
  for seed in [1,2,3]:
   source=args.source/f'results/formal/{ds}_seed{seed}/aligned_arrays.npz'
   with np.load(source,allow_pickle=False) as z: a={k:z[k] for k in z.files}
   methods=[m for m in MODELS if m in a];Z=a['Z'];X=a['X'];P=np.eye(len(X))-X@np.linalg.pinv(X)
   meta=json.loads(source.with_name('identity.json').read_text())
   st={k:a[k] for k in ['genes','conditions','Z','X','control','panel_target_mask','train_conditions','train_variance','train_scale','variance_floor']}
   # Original prediction dtype is float32 for v14 and its joint backbone.
   fraw=(a['WitnessCell_v14']+a['control']).astype(np.float32);braw=(a['v14_joint_saturation_backbone']+a['control']).astype(np.float32)
   # Verify reconstructed archived float32 values really roundtrip.
   assert np.array_equal(fraw.astype(float)-a['control'],a['WitnessCell_v14'])
   assert np.array_equal(braw.astype(float)-a['control'],a['v14_joint_saturation_backbone'])
   for mi,mode in enumerate(MODES):
    keep=a['panel_target_mask'] if mi==1 else np.ones(len(a['genes']),bool)
    divisor=a['train_scale'][keep] if mi==2 else np.ones(keep.sum())
    y=a['truth'][:,keep]/divisor;T=Z.T@y;py=P@y
    h1=Z.T@(a['truth_half1'][:,keep]/divisor);h2=Z.T@(a['truth_half2'][:,keep]/divisor)
    prefix=f'm{mi}__';st[prefix+'gene_indices']=np.flatnonzero(keep)
    for name,x in [('truth_projected2',T*T),('truth_edge2',y*y),('truth_P2',py*py),('half1_2',h1*h1),('half2_2',h2*h2),('half_cross',h1*h2)]:add(st,prefix+name,x)
    for j,model in enumerate(methods):
     pred=a[model][:,keep]/divisor;H=Z.T@pred
     pp=P@pred;pe=P@(pred-y)
     for name,x in [('pred_projected2',H*H),('error_projected2',(H-T)**2),('pred_truth_cross',H*T),('pred_edge2',pred*pred),('error_edge2',((a[model][:,keep]-a['truth'][:,keep])/divisor)**2),('error_P2',pe*pe),('pred_P2',pp*pp)]:add(st,prefix+f'j{j}__'+name,x)
    final=a['WitnessCell_v14'][:,keep]/divisor;back=a['v14_joint_saturation_backbone'][:,keep]/divisor;inc=final-back;pi=Z.T@inc
    add(st,prefix+'inc2',inc*inc);add(st,prefix+'inc_projected2',pi*pi)
    st[prefix+'inc_projected_max']=np.array([np.max(np.abs(pi[:,i:i+BLOCK])) for i in range(0,pi.shape[1],BLOCK)])
    # These operation orders reproduce the original increment audit exactly.
    add(st,prefix+'inc_final_error2',(final-y)**2);add(st,prefix+'inc_back_error2',(back-y)**2)
    add(st,prefix+'inc_final_projected_error2',(Z.T@final-T)**2);add(st,prefix+'inc_back_projected_error2',(Z.T@back-T)**2)
    envelope=(half_ulp32(fraw)+half_ulp32(braw))[:,keep]/divisor
    ep=np.finfo(float).eps;gamma=len(X)*ep/(1-len(X)*ep)
    xp=np.linalg.lstsq(X,np.eye(len(X)),rcond=None)[0]
    envelope_norm=float(np.linalg.norm(envelope));round_bound=float(np.linalg.norm(Z,2))*envelope_norm
    basis_bound=float(np.linalg.norm(Z.T@X))*float(np.linalg.norm(xp,2))*(float(np.linalg.norm(inc))+envelope_norm)
    arithmetic_bound=gamma*float(np.linalg.norm(np.abs(Z).T@np.abs(inc)))+8*ep*float(np.linalg.norm((np.abs(fraw.astype(float))+np.abs(braw.astype(float)))[:,keep]/divisor))
    # Norm components derived from original vectors; not inferential statistics.
    st[prefix+'quantization_norm_components']=np.array([float(np.linalg.norm(Z.T@inc)),envelope_norm,round_bound,basis_bound,arithmetic_bound])
   st['methods']=np.array(methods);st['modes']=np.array(MODES);st['block_size']=np.array(BLOCK)
   out=args.output/f'{ds}_seed{seed}.npz';np.savez_compressed(out,**st)
   meta.update(aligned_source_sha256=sha(source),sufficient_statistics_sha256=sha(out),methods=methods,block_size=BLOCK,representation='float64 gene-block sums with reduction-order correction; original inputs are not recoverable')
   out.with_suffix('.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2)+'\n');manifest.append(meta)
   print(ds,seed,out.stat().st_size,flush=True)
 (args.output/'INDEX.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
if __name__=='__main__':main()
