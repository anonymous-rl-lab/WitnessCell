"""Reformat completed formal scores without changing scores or selecting models."""
from pathlib import Path
import csv
import hashlib
import json

BASE=Path(__file__).resolve().parents[1]
SOURCE=BASE/'results'/'formal'/'MODEL_SCORES.json'
OUT=BASE/'results'
MODELS=['WitnessCell_v14','v14_joint_saturation_backbone','WitnessCell_v1_archived',
        'v1_joint_saturation_backbone','zero_contrast_reference','Step1_trainMean',
        'Step1_shared_endpoint_additive','Step1_saturation_only']
MODES=['all_genes_raw','exclude_panel_targets','training_variance_standardized']
DATASETS=['Norman','Wessels','Schmidt','Replogle_exp6']
rows=json.loads(SOURCE.read_text())
index={}
for r in rows:
    key=(r['mode'],r['dataset'],r['seed'],r['model'])
    if key in index: raise ValueError(f'Duplicate formal score {key}')
    index[key]=r
tables={}
for mode in MODES:
    table=[]
    for dataset in DATASETS:
        for seed in [1,2,3]:
            reference=index[(mode,dataset,seed,'WitnessCell_v14')]
            out={'dataset':dataset,'seed':seed,'d':reference['contrast_dimension'],'E':reference['E']}
            for model in MODELS:
                score=index.get((mode,dataset,seed,model))
                if score is None:out[model]='NA'
                else:
                    assert score['E']==out['E'] and score['contrast_dimension']==out['d']
                    out[model]='NA' if score['projection_error_ratio'] is None else score['projection_error_ratio']
            table.append(out)
    with (OUT/f'MAIN_TABLE_{mode}.csv').open('w',newline='',encoding='utf-8') as f:
        writer=csv.DictWriter(f,fieldnames=['dataset','seed','d','E']+MODELS)
        writer.writeheader();writer.writerows(table)
    tables[mode]=table

short_names=['v14','v14骨架','v1','v1骨架','零对比','trainMean','端点加性','Step1饱和']
lines=['正式预测审计主表：全基因、原始尺度',
       '',
       '指标：投影误差比 = 投影误差平方和 / 真值投影能量。越小越好；1表示与零对比基线相同。下表保留小数六位。',
       '此表仅描述相同官方重建划分上的已保存预测，不包含新拟合或新调参。',
       '',
       '| 数据集 | seed | d | E | '+' | '.join(short_names)+' |',
       '|---|'+'---:|'*11]
for r in tables['all_genes_raw']:
    vals=[]
    for model in MODELS:
        v=r[model]
        display='NA' if v=='NA' else f'{v:.6f}'
        vals.append('0.000000' if display=='-0.000000' else display)
    lines.append('| '+str(r['dataset'])+' | '+str(r['seed'])+' | '+str(r['d'])+' | '+str(r['E'])+' | '+' | '.join(vals)+' |')
lines += ['',
          '显示说明：中文表四舍五入至小数六位；包含数值残差的原始全精度值均保留在三张 MAIN_TABLE_*.csv 中。不将浮点级误差解释为科学增益。',
          'NA说明：Schmidt和Replogle_exp6的6个划分没有本次同权限、同划分的三项Step1预测，未插补。',
          '骨架说明：v14骨架与v1骨架分别指各自预测器保存的joint saturation backbone；它们不自动等于另一批实验中的M0。',
          '三套评价：all_genes_raw；exclude_panel_targets（全测试面板靶点的统一基因mask）；training_variance_standardized（训练侧尺度）。',
          'CSV数值是投影误差比原值，与中文表口径相同；不转换成skill或百分数。']
(OUT/'MAIN_TABLE_CN.txt').write_text('\n'.join(lines)+'\n',encoding='utf-8')

availability='''本次正式预测审计的模型可用性与身份

1. 正式评价范围
   四个数据集 × 三个官方重建划分，共12个固定测试图。
   本次仅把已完成MODEL_SCORES.json转为表格，未改变任何预测、误差或投影评分。

2. 每个划分均可用的5列
   WitnessCell_v14：v14正式预测。
   v14_joint_saturation_backbone：与上述v14对应的联合饱和骨架。
   WitnessCell_v1_archived：保存的v1预测。
   v1_joint_saturation_backbone：与上述v1对应的联合饱和骨架。
   zero_contrast_reference：投影空间的零对比参考，不是额外训练的模型。

3. 仅Norman和Wessels的6个划分可用的3列
   Step1_trainMean、Step1_shared_endpoint_additive、Step1_saturation_only。
   Schmidt和Replogle_exp6的对应6个划分记NA，不用其他划分或其他模型填补。

4. GEARS / CPA
   已恢复的36份命名模型NPZ来自项目自建的Norman与GSE146194实验图。
   它们未与这里12个官方重建测试图完成预测对象、拟合身份和完整边集合对齐。
   不能把这些预测拼到本表，不能凭本表声称已完成GEARS或CPA的官方划分对比。

5. M0 / M1 / R
   它们属于55个CaRPool组合的伙伴分量与可靠性收缩实验。
   该实验采用自身冻结的矩形划分、训练权限和参数。
   它们不是本表WitnessCell_v14及其骨架的别名；不能默认为已经完成12个官方划分的M0/M1/R评分。

6. 指标口径
   三张主表均报告 projection_error_ratio = projection_SSE / projected_truth_energy。
   三套口径分别为全基因原始尺度、统一剔除面板靶点、训练侧方差标准化。
   CSV保留原JSON读出的浮点全精度；中文表按误差比小数六位显示，越小越好，1为零对比基线。
'''
(OUT/'MODEL_AVAILABILITY_CN.txt').write_text(availability,encoding='utf-8')
outputs=[OUT/f'MAIN_TABLE_{m}.csv' for m in MODES]+[OUT/'MAIN_TABLE_CN.txt',OUT/'MODEL_AVAILABILITY_CN.txt']
manifest={'source':str(SOURCE.relative_to(BASE)),
          'source_sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
          'metric':'projection_error_ratio','csv_unit':'ratio','display_unit':'ratio_6_decimal_places',
          'model_order':MODELS,'rows_per_table':12,
          'outputs':{str(p.relative_to(BASE)):hashlib.sha256(p.read_bytes()).hexdigest() for p in outputs}}
(OUT/'MAIN_TABLE_SOURCES.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'status':'PASS','tables':3,'rows_per_table':12,'models_per_table':8,
                  'missing_cells_per_table':sum(v=='NA' for r in tables['all_genes_raw'] for m,v in r.items() if m in MODELS)}))
