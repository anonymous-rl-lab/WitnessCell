from pathlib import Path
import hashlib,json,zipfile
ROOT=Path(__file__).resolve().parents[1]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert json.loads((ROOT/'audit/INDEPENDENT_PREDICTION_VERIFY.json').read_text())['status']=='PASS'
files=sorted(p for p in ROOT.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.name!='PACKAGE_MANIFEST.json')
for p in files:
 if p.suffix=='.npz':
  with zipfile.ZipFile(p) as z:assert z.testzip() is None,str(p)
manifest={'files':[{'path':str(p.relative_to(ROOT)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in files]}
mp=ROOT/'PACKAGE_MANIFEST.json';mp.write_text(json.dumps(manifest,indent=2)+'\n');files.append(mp)
target=ROOT.parent/'WitnessCell_Prediction_Contrast_Audit_20261018.zip'
with zipfile.ZipFile(target,'w',allowZip64=True) as z:
 for p in files:z.write(p,arcname='WitnessCell_Prediction_Contrast_Audit_20261018/'+str(p.relative_to(ROOT)),compress_type=zipfile.ZIP_STORED if p.suffix=='.npz' else zipfile.ZIP_DEFLATED)
with zipfile.ZipFile(target) as z:assert z.testzip() is None
identity={'filename':target.name,'bytes':target.stat().st_size,'sha256':sha(target),'payload_files':len(files),'zip_crc':'PASS'}
(target.parent/'WitnessCell_Prediction_Contrast_Audit_20261018_identity.json').write_text(json.dumps(identity,indent=2)+'\n')
print(json.dumps(identity))
