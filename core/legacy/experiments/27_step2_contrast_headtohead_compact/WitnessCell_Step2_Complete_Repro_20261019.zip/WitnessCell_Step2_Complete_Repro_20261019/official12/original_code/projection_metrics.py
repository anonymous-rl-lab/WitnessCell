"""Projection metrics for ONE fixed fit and ONE unique-edge evaluation graph.

Only NumPy is required. No model training, data-dependent feature selection,
scale fitting, confidence interval or hypothesis test is performed here.
Rows must already have exactly the same canonical edge order as the supplied
orthonormal E-by-d contrast basis Z. Predictions cannot be stitched across
different fits. Callers are responsible for provenance and fit identity.

A single G-vector gene mask is shared by EVERY edge. Per-edge target masking
is explicitly rejected because it can create nonadditive projections from
an additive prediction. Training scales are externally fixed positive
standard deviations (not variances); values are never fitted or floored here.

Cell-half cross-products are descriptive reproducibility summaries, not
independent biological replicates and not confidence statements.
"""
from __future__ import annotations

import json
from pathlib import Path
import numpy as np


def common_gene_mask(gene_names, excluded_genes=()):
    """Build a one-dimensional common mask, e.g. exclude ALL test endpoints.

    All rows with an excluded name are removed; the caller supplies the union
    of endpoints across the complete test graph, never per-edge exclusions.
    """
    names = np.asarray(gene_names)
    if names.ndim != 1:
        raise ValueError('gene_names must be one-dimensional')
    excluded = set(map(str, excluded_genes))
    return np.asarray([str(g) not in excluded for g in names], dtype=bool)


def _ratio(numerator, denominator):
    return float(numerator / denominator) if denominator > 0 else None


def _cosine(a, b):
    aa = float(np.sum(a*a))
    bb = float(np.sum(b*b))
    return _ratio(float(np.sum(a*b)), float(np.sqrt(aa)*np.sqrt(bb)))


def projection_metrics(truth, prediction, Z, *, gene_mask=None,
                       train_gene_scale=None, truth_half1=None,
                       truth_half2=None, projection_matrix=None,
                       verify_projection_equivalence=True):
    """Return JSON-safe additive-contrast prediction and energy metrics.

    Parameters
    ----------
    truth, prediction : finite arrays (E, G), same edge/gene order, same fit
    Z : finite array (E, d), orthonormal columns spanning the complete left
        nullspace of the evaluation graph's unsigned incidence matrix.
        A zero-dimensional graph is represented by shape (E, 0).
    gene_mask : optional boolean (G,) common to all edges, default all genes
    train_gene_scale : optional positive (G,) fixed training-side SD values;
        selected values divide both truth and prediction before projection.
        To standardize by a training variance v, explicitly pass sqrt(v).
    truth_half1, truth_half2 : paired optional (E, G), same graph and features
    projection_matrix : optional (E, E) independently constructed P, checked
        against Z@Z.T before use. It must represent exactly the same subspace.

    Definitions
    -----------
    T=Z.T@(truth[:,mask]/scale), H=Z.T@(prediction[:,mask]/scale).
    SSE=||H-T||_F^2; zero-contrast baseline SSE=||T||_F^2.
    skill=1-SSE/||T||_F^2; cosine=inner(H,T)/(||H||*||T||).
    Nonadditive fraction = projected energy / corresponding complete edge
    response energy under the same feature mask and scaling.

    Zero denominator always produces None (JSON null), never +/-infinity,
    an arbitrary 0 or an arbitrary 1. Energies on an empty contrast space are
    exactly zero and prediction skill is NA. No inferential p-value is made.
    """
    y = np.asarray(truth, dtype=float)
    pred = np.asarray(prediction, dtype=float)
    basis = np.asarray(Z, dtype=float)
    if y.ndim != 2 or pred.shape != y.shape:
        raise ValueError('truth and prediction must share shape (E, G)')
    E, G = y.shape
    if basis.ndim != 2 or basis.shape[0] != E:
        raise ValueError('Z must have shape (E, d) in the same edge order')
    d = basis.shape[1]
    if d > E:
        raise ValueError('Z cannot have more orthonormal columns than edges')
    for name, arr in [('truth',y),('prediction',pred),('Z',basis)]:
        if not np.all(np.isfinite(arr)):
            raise ValueError(f'{name} contains nonfinite values')
    orth_error = float(np.max(np.abs(basis.T@basis-np.eye(d)))) if d else 0.
    if orth_error > 1e-8:
        raise ValueError(f'Z is not orthonormal (max error {orth_error:g})')
    if gene_mask is None:
        mask = np.ones(G, dtype=bool)
    else:
        mask = np.asarray(gene_mask)
        if mask.shape != (G,) or mask.dtype.kind != 'b':
            raise ValueError('gene_mask must be a common boolean (G,) vector; per-edge masks are invalid')
    if train_gene_scale is None:
        scale = np.ones(int(np.sum(mask)))
        scale_mode = 'unscaled'
    else:
        full_scale = np.asarray(train_gene_scale, dtype=float)
        if full_scale.shape != (G,):
            raise ValueError('train_gene_scale must be a training-fixed (G,) SD vector')
        scale = full_scale[mask]
        if not np.all(np.isfinite(scale)) or np.any(scale <= 0):
            raise ValueError('selected training scales must be finite and strictly positive; no test-side floor is fitted')
        scale_mode = 'externally_fixed_training_standard_deviation'
    K = int(np.sum(mask))
    ys, ps = y[:,mask]/scale, pred[:,mask]/scale
    T, H = basis.T@ys, basis.T@ps
    truth_energy = float(np.sum(T*T))
    prediction_energy = float(np.sum(H*H))
    error = H-T
    sse = float(np.sum(error*error))
    edge_truth_energy = float(np.sum(ys*ys))
    edge_prediction_energy = float(np.sum(ps*ps))
    sse_ratio = _ratio(sse, truth_energy)
    result = {
        'E': E, 'G_input': G, 'G_selected': K, 'contrast_dimension': d,
        'scale_mode': scale_mode,
        'projection_SSE': sse,
        'projection_MSE_per_contrast_gene': _ratio(sse, d*K),
        'zero_contrast_baseline_SSE': truth_energy,
        'projection_skill': 1.-sse_ratio if sse_ratio is not None else None,
        'projected_prediction_energy': prediction_energy,
        'projected_truth_energy': truth_energy,
        'projected_prediction_truth_inner_product': float(np.sum(H*T)),
        'projected_cosine': _cosine(H,T),
        'prediction_nonadditive_fraction': _ratio(prediction_energy, edge_prediction_energy),
        'truth_nonadditive_fraction': _ratio(truth_energy, edge_truth_energy),
        'total_prediction_energy_selected_scaled': edge_prediction_energy,
        'total_truth_energy_selected_scaled': edge_truth_energy,
        'basis_orthogonality_max_error': orth_error,
        'status': 'NO_CONTRAST_DIMENSION' if d==0 else ('NO_SELECTED_GENES' if K==0 else 'EVALUATED'),
    }
    if projection_matrix is not None or verify_projection_equivalence:
        canonical_P = basis@basis.T
        P = canonical_P if projection_matrix is None else np.asarray(projection_matrix,dtype=float)
        if P.shape != (E,E) or not np.all(np.isfinite(P)):
            raise ValueError('projection_matrix must be finite with shape (E, E)')
        p_error = float(np.max(np.abs(P-canonical_P))) if E else 0.
        if p_error > 1e-8:
            raise ValueError('projection_matrix does not equal Z@Z.T for this subspace')
        p_sse = float(np.sum((P@(ps-ys))**2))
        p_y_energy = float(np.sum((P@ys)**2))
        p_h_energy = float(np.sum((P@ps)**2))
        max_difference = max(abs(p_sse-sse),abs(p_y_energy-truth_energy),abs(p_h_energy-prediction_energy))
        normalizer = max(1.,sse,truth_energy,prediction_energy)
        result['P_equivalence'] = {
            'P_source':'independently_supplied' if projection_matrix is not None else 'Z_times_Z_transpose',
            'max_abs_P_minus_ZZt':p_error,
            'max_abs_energy_difference':max_difference,
            'relative_energy_difference':max_difference/normalizer,
            'pass':bool(max_difference/normalizer < 1e-8),
        }
    if (truth_half1 is None) != (truth_half2 is None):
        raise ValueError('Supply both cell-half truth matrices or neither')
    if truth_half1 is not None:
        halfs=[]
        for h in (truth_half1,truth_half2):
            arr=np.asarray(h,dtype=float)
            if arr.shape!=y.shape or not np.all(np.isfinite(arr)):
                raise ValueError('Cell-half matrices must be finite with the complete truth shape')
            halfs.append(basis.T@(arr[:,mask]/scale))
        a,b=halfs
        ea,eb=float(np.sum(a*a)),float(np.sum(b*b))
        cross=float(np.sum(a*b))
        result['cell_half_descriptive']={
            'projected_half1_energy':ea,'projected_half2_energy':eb,
            'projected_cross_inner_product':cross,
            'projected_cross_cosine':_cosine(a,b),
            'cross_over_mean_half_energy':_ratio(cross,.5*(ea+eb)),
            'interpretation':'descriptive cell-half reproducibility; not independent biological replicates',
        }
    return result


def selftest():
    """Synthetic checks: perfect, zero, orthogonal, masks, scales and d=0."""
    # Rectangle order AB, AD, CB, CD; z is exactly normalized.
    z=np.array([[1.],[-1.],[-1.],[1.]])*.5
    X=np.array([[1.,1.,0.,0.],[1.,0.,0.,1.],
                [0.,1.,1.,0.],[0.,0.,1.,1.]])
    P=np.eye(4)-X@np.linalg.pinv(X)
    signal=z@np.array([[2.,-3.,1.]])
    endpoint=np.array([[1.,3.,5.],[2.,4.,6.],[3.,5.,7.],[4.,6.,8.]])
    additive=X@endpoint
    y=signal+additive
    r=projection_metrics(y,y,z,projection_matrix=P)
    assert abs(r['projection_skill']-1.)<1e-12 and r['projection_SSE']==0
    assert abs(r['zero_contrast_baseline_SSE']-14.)<1e-12
    assert r['P_equivalence']['pass']
    zero=projection_metrics(y,additive,z)
    assert abs(zero['projection_skill'])<1e-12
    assert zero['projected_prediction_energy']==0 and zero['projected_cosine'] is None
    half=projection_metrics(y,additive+.5*signal,z)
    assert abs(half['projection_skill']-.75)<1e-12
    no_space=projection_metrics(y,y,np.empty((4,0)))
    assert no_space['projection_skill'] is None and no_space['projection_MSE_per_contrast_gene'] is None
    no_signal=projection_metrics(np.zeros_like(y),signal,z)
    assert no_signal['projection_skill'] is None and no_signal['projected_cosine'] is None
    no_genes=projection_metrics(y,y,z,gene_mask=np.zeros(3,dtype=bool))
    assert no_genes['projection_skill'] is None
    mask=common_gene_mask(['G1','G2','G3'],['G2'])
    scaled=projection_metrics(y,additive,z,gene_mask=mask,train_gene_scale=np.array([2.,10.,.5]),
                              truth_half1=y,truth_half2=y)
    assert abs(scaled['zero_contrast_baseline_SSE']-5.)<1e-12
    assert abs(scaled['cell_half_descriptive']['projected_cross_inner_product']-5.)<1e-12
    assert scaled['cell_half_descriptive']['cross_over_mean_half_energy']==1
    rejected=False
    try: projection_metrics(y,y,z,gene_mask=np.ones_like(y,dtype=bool))
    except ValueError: rejected=True
    assert rejected
    # Common feature scaling preserves exact endpoint cancellation.
    assert scaled['projected_prediction_energy']==0
    # Deliberately demonstrate why edge-specific gene masking is prohibited.
    corrupted=additive.copy();corrupted[0,0]=0.
    assert np.sum((z.T@corrupted)**2)>0
    return {'status':'PASS','synthetic_only':True,
            'cases':{'perfect':r,'zero_contrast_prediction':zero,
                     'half_signal':half,'no_contrast_space':no_space,
                     'zero_truth_signal':no_signal,'empty_gene_mask':no_genes,
                     'common_mask_training_scale_and_cell_halves':scaled,
                     'edge_specific_mask_rejected':rejected}}


if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser()
    parser.add_argument('--selftest',action='store_true')
    parser.add_argument('--output')
    args=parser.parse_args()
    if not args.selftest:parser.error('This module CLI only provides --selftest')
    text=json.dumps(selftest(),indent=2,allow_nan=False)+'\n'
    if args.output:Path(args.output).write_text(text)
    else:print(text,end='')
