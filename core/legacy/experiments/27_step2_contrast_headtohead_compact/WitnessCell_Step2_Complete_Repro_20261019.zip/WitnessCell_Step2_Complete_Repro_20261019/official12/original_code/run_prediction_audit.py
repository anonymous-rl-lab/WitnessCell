#!/usr/bin/env python3
"""Frozen, retrospective projection audit. No fitting or model selection."""
import os
for key in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:
    os.environ[key]='1'
import argparse,csv,hashlib,json,time,signal
from pathlib import Path
import numpy as np
from projection_metrics import projection_metrics, common_gene_mask
ROOT=Path(__file__).resolve().parents[1]
MAT=ROOT/'sources/materialized/experiments'
DATASETS=['Norman','Wessels','Schmidt','Replogle_exp6']
FIELDS={'WitnessCell_v14':'prediction','v14_joint_saturation_backbone':'factorized_prediction',
        'WitnessCell_v1_archived':'baseline_prediction','v1_joint_saturation_backbone':'baseline_factorized_prediction'}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,obj):
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(obj,indent=2,ensure_ascii=False,allow_nan=False)+'\n')
def key(s):return '+'.join(sorted(str(s).split('+')))
def index(names):
    names=[key(x) for x in names]
    if len(set(names))!=len(names):raise ValueError('Duplicate canonical condition')
    return {s:i for i,s in enumerate(names)}
def freeze():
    p=ROOT/'AUDIT_LOCK.json'
    if p.exists():raise FileExistsError('Lock already exists; do not overwrite')
    files=[ROOT/'PROTOCOL_CN.txt',ROOT/'code/run_prediction_audit.py',ROOT/'code/projection_metrics.py']
    files+=list((ROOT/'sources').rglob('*.npz'))+list((ROOT/'sources/graph').rglob('*.json'))
    dump(p,{'created_unix':time.time(),'scope':'internal freeze; retrospective audit',
            'files':{str(q.relative_to(ROOT)):sha(q) for q in sorted(set(files))}})
    print(json.dumps({'stage':'freeze','files':len(set(files)),'lock_sha256':sha(p)}),flush=True)
def verify_lock():
    lock=json.loads((ROOT/'AUDIT_LOCK.json').read_text())
    for rel,digest in lock['files'].items():
        if sha(ROOT/rel)!=digest:raise ValueError('Frozen input changed: '+rel)
def safe_ratio(a,b):return float(a/b) if b>0 else None
def audit_one(ds,seed,out):
    records=json.loads((ROOT/'sources/graph/normalized_splits.json').read_text())['records']
    rec=next(r for r in records if r['family']=='scperturbench_release_reconstruction' and r['dataset']==ds and r['seed']==seed)
    p=MAT/f'19_v14_incremental_amplitude_gate/predictions/formal_combo/{ds}/seed{seed}/deploy_predictions.npz'
    cp=MAT/f'22_metric_calibration_stress/assets/formal_contracts/{ds}.phase_m_contract.npz'
    with np.load(p,allow_pickle=False) as z:dep={k:z[k] for k in z.files}
    with np.load(cp,allow_pickle=False) as z:contract={k:z[k] for k in z.files}
    with np.load(ROOT/f'sources/graph/{rec["id"]}/contrast_basis.npz',allow_pickle=False) as z:
        Z=z['basis'];pairs=z['pairs'];nodes=z['nodes']
    conditions=['+'.join(x) for x in pairs]
    di=index(dep['conditions']);ci=index(contract['conditions'])
    if set(di)!=set(map(key,rec['original_roles']['test'])):raise ValueError('Published test identity mismatch')
    if set(conditions)!={key(x) for x in dep['conditions'] if '+' in str(x)}:raise ValueError('Combo set mismatch')
    genes=dep['genes'].astype(str)
    if len(set(genes))!=len(genes):raise ValueError('Duplicate genes')
    cg={str(g):i for i,g in enumerate(contract['genes'])}
    if set(genes)!=set(cg):raise ValueError('Gene set mismatch')
    gi=np.array([cg[g] for g in genes]);dr=np.array([di[c] for c in conditions]);cr=np.array([ci[c] for c in conditions])
    ctrl=contract['control'][gi].astype(float)
    truth=contract['full_means'][cr][:,gi].astype(float)-ctrl
    h1=contract['first_means'][cr][:,gi].astype(float)-ctrl
    h2=contract['second_means'][cr][:,gi].astype(float)-ctrl
    methods={name:dep[field][dr].astype(float)-ctrl for name,field in FIELDS.items()}
    methods['zero_contrast_reference']=np.zeros_like(truth)
    base=MAT/f'23_joint_prediction_risk_step1/witnesscell_step1_run/results/{ds}_seed{seed}'
    baseline_available=(base/'baseline_predictions.npz').exists()
    if baseline_available:
        with np.load(base/'allowed_input.npz',allow_pickle=False) as a:
            assert np.array_equal(a['genes'].astype(str),genes)
            ai=index(a['targets']);ar=np.array([ai[c] for c in conditions])
            assert np.array_equal(a['frozen_prediction'][ar],dep['prediction'][dr])
            assert np.array_equal(a['frozen_factorized'][ar],dep['factorized_prediction'][dr])
        with np.load(base/'baseline_predictions.npz',allow_pickle=False) as b:
            bi=index(b['conditions']);br=np.array([bi[c] for c in conditions])
            assert np.array_equal(b['factorized_prediction'][br],dep['factorized_prediction'][dr])
            for name in ['trainMean','shared_endpoint_additive','saturation_only']:
                methods['Step1_'+name]=b[name][br].astype(float)-ctrl
    train=[key(c) for c in rec['original_roles']['train'] if c!='control']
    tr=np.array([ci[c] for c in train]);tv=np.var(contract['full_means'][tr][:,gi],axis=0,ddof=1)
    positive=tv[tv>0];floor=.01*float(np.median(positive));assert floor>0
    scale=np.sqrt(np.maximum(tv,floor))
    mask=common_gene_mask(genes,rec['node_universe'])
    X=np.zeros((len(pairs),len(nodes)));ni={str(n):i for i,n in enumerate(nodes)}
    for i,(a,b) in enumerate(pairs):X[i,ni[str(a)]]=1;X[i,ni[str(b)]]=1
    P=np.eye(len(pairs))-X@np.linalg.pinv(X)
    assert np.max(np.abs(X.T@Z))<1e-10
    rows=[];contrasts=[]
    modes={'all_genes_raw':(None,None),'exclude_panel_targets':(mask,None),'training_variance_standardized':(None,scale)}
    for mode,(m,s) in modes.items():
        keep=np.ones(len(genes),bool) if m is None else m
        div=np.ones(int(keep.sum())) if s is None else s[keep]
        rawtruth=truth[:,keep]/div
        ys=Z.T@rawtruth
        den=float(np.sum(ys*ys))
        for name,pred in methods.items():
            result=projection_metrics(truth,pred,Z,gene_mask=m,train_gene_scale=s,
                    truth_half1=h1,truth_half2=h2,projection_matrix=P)
            result.update(dataset=ds,seed=seed,mode=mode,model=name,split_id=rec['id'])
            result['projection_error_ratio']=safe_ratio(result['projection_SSE'],den)
            result['full_response_SSE']=float(np.sum(((pred[:,keep]-truth[:,keep])/div)**2))
            result['numerical_degeneracy']=bool(den<=100*np.finfo(float).eps*max(result['total_truth_energy_selected_scaled'],np.finfo(float).tiny))
            rows.append(result)
        final=methods['WitnessCell_v14'][:,keep]/div;factor=methods['v14_joint_saturation_backbone'][:,keep]/div
        inc=final-factor;inc_energy=float(np.sum(inc*inc));pi=Z.T@inc;pe=float(np.sum(pi*pi))
        ef=float(np.sum((final-rawtruth)**2));eb=float(np.sum((factor-rawtruth)**2))
        pf=float(np.sum((Z.T@final-ys)**2));pb=float(np.sum((Z.T@factor-ys)**2))
        fraction=safe_ratio(pe,inc_energy)
        contrasts.append({'dataset':ds,'seed':seed,'mode':mode,'increment_energy':inc_energy,
            'increment_projected_energy':pe,'increment_projected_fraction':fraction,
            'compatible_with_additive_increment_at_float32_precision':inc_energy==0 or fraction<=1e-10,
            'full_response_error_gain_vs_joint_backbone':None if eb==0 else 1-ef/eb,
            'projection_error_gain_vs_joint_backbone':None if pb==0 else 1-pf/pb,
            'max_absolute_projected_increment':float(np.max(np.abs(pi)))})
    directory=out/f'{ds}_seed{seed}';directory.mkdir(parents=True)
    np.savez_compressed(directory/'aligned_arrays.npz',conditions=np.asarray(conditions),genes=genes,
        truth=truth,truth_half1=h1,truth_half2=h2,Z=Z,X=X,control=ctrl,
        panel_target_mask=mask,train_conditions=np.array(train),train_variance=tv,
        train_scale=scale,variance_floor=np.array(floor),**methods)
    dump(directory/'scores.json',rows);dump(directory/'increment_audit.json',contrasts)
    dump(directory/'identity.json',{'dataset':ds,'seed':seed,'split_id':rec['id'],
        'deploy_sha256':sha(p),'truth_contract_sha256':sha(cp),'E':len(pairs),'G':len(genes),'d':Z.shape[1],
        'baseline_available':baseline_available,'training_scale_conditions':train,
        'excluded_panel_target_coordinates':int((~mask).sum()),'training_variance_floor':floor,
        'truth_dtype':'contract_float64; predictions original archived float32/Step1 float64',
        'P_Z_max_difference':float(np.max(np.abs(P-Z@Z.T)))})
    return rows,contrasts
def flat_csv(path,rows):
    keys=list(dict.fromkeys(k for r in rows for k,v in r.items() if not isinstance(v,dict)))
    with path.open('w',newline='') as f:
        w=csv.DictWriter(f,keys,extrasaction='ignore');w.writeheader();w.writerows(rows)
def run(stage):
    verify_lock();started=time.monotonic();out=ROOT/'results'/stage
    if out.exists():raise FileExistsError(out)
    out.mkdir(parents=True)
    jobs=[('Norman',1)] if stage=='pilot' else [(d,s) for d in DATASETS for s in [1,2,3]]
    rows=[];inc=[];budget=60 if stage=='pilot' else 300
    def timeout(*_):raise TimeoutError('Frozen compute budget exceeded')
    signal.signal(signal.SIGALRM,timeout);signal.alarm(budget)
    try:
        for ds,seed in jobs:
            r,c=audit_one(ds,seed,out);rows+=r;inc+=c
            print(json.dumps({'completed':f'{ds}_seed{seed}','elapsed_seconds':time.monotonic()-started}),flush=True)
        flat_csv(out/'MODEL_SCORES.csv',rows);flat_csv(out/'INCREMENT_AUDIT.csv',inc)
        dump(out/'MODEL_SCORES.json',rows);dump(out/'INCREMENT_AUDIT.json',inc)
        groups=[]
        for ds in DATASETS:
            for mode in sorted({r['mode'] for r in rows}):
                for model in sorted({r['model'] for r in rows}):
                    rr=[r for r in rows if r['dataset']==ds and r['mode']==mode and r['model']==model]
                    if not rr:continue
                    den=sum(r['zero_contrast_baseline_SSE'] for r in rr);sse=sum(r['projection_SSE'] for r in rr)
                    ratio=safe_ratio(sse,den)
                    groups.append(dict(dataset=ds,mode=mode,model=model,n_splits=len(rr),
                        projection_error_ratio=ratio,projection_skill=None if ratio is None else 1-ratio,
                        note='descriptive within-dataset pooled SSE; overlapping splits are not independent'))
        dump(out/'DATASET_SUMMARY.json',groups);flat_csv(out/'DATASET_SUMMARY.csv',groups)
        dump(out/'RUN_METADATA.json',{'status':'PASS','stage':stage,'n_splits':len(jobs),'n_score_rows':len(rows),
             'elapsed_seconds':time.monotonic()-started,'budget_seconds':budget,'lock_sha256':sha(ROOT/'AUDIT_LOCK.json'),
             'numpy_version':np.__version__,'formal_predictions_retrained':False})
    finally:signal.alarm(0)
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('stage',choices=['freeze','pilot','formal']);args=ap.parse_args()
    if args.stage=='freeze':freeze()
    else:run(args.stage)
