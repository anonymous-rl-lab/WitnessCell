#!/usr/bin/env python3
"""Independent read-only verification from source arrays and least-squares P.
Does not import the production runner or projection_metrics.
"""
import os
for name in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ[name] = "1"
import argparse
import hashlib
import json
import time
from pathlib import Path
import numpy as np

FIELDS = {"WitnessCell_v14": "prediction", "v14_joint_saturation_backbone": "factorized_prediction",
          "WitnessCell_v1_archived": "baseline_prediction", "v1_joint_saturation_backbone": "baseline_factorized_prediction"}

def read_npz(path):
    with np.load(path, allow_pickle=False) as z:
        return {k: z[k] for k in z.files}

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def canonical(value):
    return "+".join(sorted(str(value).split("+")))

def half_ulp32(value):
    assert value.dtype == np.float32
    x = value.astype(np.float64)
    hi = np.nextafter(value, np.float32(np.inf)).astype(np.float64)
    lo = np.nextafter(value, np.float32(-np.inf)).astype(np.float64)
    return 0.5 * np.maximum(hi-x, x-lo)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    root = ap.parse_args().root.resolve()
    started = time.monotonic()
    lock = json.loads((root/"AUDIT_LOCK.json").read_text())
    for rel, digest in lock["files"].items():
        assert sha(root/rel) == digest, rel
    formal = root/"results/formal"
    meta = json.loads((formal/"RUN_METADATA.json").read_text())
    assert meta["n_splits"] == 12 and meta["n_score_rows"] == 234
    rows = json.loads((formal/"MODEL_SCORES.json").read_text())
    inc_rows = json.loads((formal/"INCREMENT_AUDIT.json").read_text())
    assert len(rows) == 234 and len(inc_rows) == 36
    record_lookup = {r["id"]: r for r in json.loads((root/"sources/graph/normalized_splits.json").read_text())["records"]}
    mat = root/"sources/materialized/experiments"
    quantization, checked, discrepancies = [], [], []

    def close(actual, expected, label, atol=2e-9, rtol=1e-10):
        error = abs(float(actual)-float(expected))
        assert error <= atol + rtol * max(abs(float(actual)), abs(float(expected))), (label, actual, expected)
        discrepancies.append(error / max(1.0, abs(float(actual)), abs(float(expected))))

    for dataset in ("Norman", "Schmidt", "Replogle_exp6", "Wessels"):
        for seed in (1, 2, 3):
            directory = formal/f"{dataset}_seed{seed}"
            identity = json.loads((directory/"identity.json").read_text())
            rec = record_lookup[identity["split_id"]]
            arr = read_npz(directory/"aligned_arrays.npz")
            dp = mat/f"19_v14_incremental_amplitude_gate/predictions/formal_combo/{dataset}/seed{seed}/deploy_predictions.npz"
            cp = mat/f"22_metric_calibration_stress/assets/formal_contracts/{dataset}.phase_m_contract.npz"
            assert sha(dp) == identity["deploy_sha256"]
            assert sha(cp) == identity["truth_contract_sha256"]
            dep, contract = read_npz(dp), read_npz(cp)
            conditions = [canonical(c) for c in arr["conditions"]]
            assert conditions == sorted(canonical("+".join(p)) for p in rec["test_pairs"])
            assert len(set(conditions)) == len(conditions)
            genes = arr["genes"].astype(str).tolist()
            assert len(set(genes)) == len(genes)
            assert genes == dep["genes"].astype(str).tolist()
            cg = {str(v): i for i, v in enumerate(contract["genes"])}
            cc = {canonical(v): i for i, v in enumerate(contract["conditions"])}
            dc = {canonical(v): i for i, v in enumerate(dep["conditions"])}
            col = [cg[g] for g in genes]
            cr, dr = [cc[c] for c in conditions], [dc[c] for c in conditions]
            ctrl = contract["control"][col].astype(float)
            for target, field in (("truth", "full_means"), ("truth_half1", "first_means"), ("truth_half2", "second_means")):
                source = contract[field][cr][:, col].astype(float)-ctrl
                assert np.array_equal(source, arr[target]), (dataset, seed, target)
            for name, field in FIELDS.items():
                assert np.array_equal(dep[field][dr].astype(float)-ctrl, arr[name])
            methods = list(FIELDS) + ["zero_contrast_reference"]
            assert np.count_nonzero(arr["zero_contrast_reference"]) == 0
            if identity["baseline_available"]:
                bp = mat/f"23_joint_prediction_risk_step1/witnesscell_step1_run/results/{dataset}_seed{seed}/baseline_predictions.npz"
                bpz = read_npz(bp)
                bc = {canonical(v): i for i, v in enumerate(bpz["conditions"])}
                br = [bc[c] for c in conditions]
                for short in ("trainMean", "shared_endpoint_additive", "saturation_only"):
                    name = "Step1_"+short
                    assert np.array_equal(bpz[short][br].astype(float)-ctrl, arr[name])
                    methods.append(name)
            train_names = [canonical(c) for c in rec["original_roles"]["train"] if c != "control"]
            assert train_names == arr["train_conditions"].tolist()
            tr = [cc[c] for c in train_names]
            variance = np.var(contract["full_means"][tr][:, col], axis=0, ddof=1)
            floor = .01 * np.median(variance[variance > 0])
            scale = np.sqrt(np.maximum(variance, floor))
            assert np.array_equal(variance, arr["train_variance"])
            assert np.array_equal(scale, arr["train_scale"])
            assert float(arr["variance_floor"]) == floor
            mask = np.array([g not in set(rec["node_universe"]) for g in genes])
            assert np.array_equal(mask, arr["panel_target_mask"])

            nodes = sorted({v for c in conditions for v in c.split("+")})
            ni = {v: i for i, v in enumerate(nodes)}
            X = np.zeros((len(conditions), len(nodes)))
            for i, c in enumerate(conditions):
                for v in c.split("+"):
                    X[i, ni[v]] = 1
            assert np.array_equal(X, arr["X"])
            # Independent route: solve the full least-squares normal problem,
            # avoiding the production saved Z for every scored residual.
            Xplus = np.linalg.lstsq(X, np.eye(len(X)), rcond=None)[0]
            P = np.eye(len(X))-X@Xplus
            Z = arr["Z"]
            assert np.max(np.abs(P-Z@Z.T)) < 1e-10
            assert Z.shape[1] == identity["d"]
            modes = {"all_genes_raw": (np.ones(len(genes), bool), np.ones(len(genes))),
                     "exclude_panel_targets": (mask, np.ones(len(genes))),
                     "training_variance_standardized": (np.ones(len(genes), bool), scale)}
            for mode, (keep, divisor) in modes.items():
                y = arr["truth"][:, keep]/divisor[keep]
                py = P@y
                baseline = float(np.sum(py*py))
                for name in methods:
                    row = next(r for r in rows if r["dataset"] == dataset and r["seed"] == seed and r["mode"] == mode and r["model"] == name)
                    pred = arr[name][:, keep]/divisor[keep]
                    pp = P@pred
                    sse = float(np.sum((pp-py)**2))
                    close(sse, row["projection_SSE"], "SSE")
                    close(baseline, row["zero_contrast_baseline_SSE"], "baseline SSE")
                    close(sse/baseline, row["projection_error_ratio"], "ratio")
                    close(1-sse/baseline, row["projection_skill"], "skill")
                    close(np.sum(pp*pp), row["projected_prediction_energy"], "projected energy")
                    close(np.sum((pred-y)**2), row["full_response_SSE"], "full SSE")
                    close(sse/(identity["d"]*keep.sum()), row["projection_MSE_per_contrast_gene"], "contrast MSE")
                    h1 = P@(arr["truth_half1"][:, keep]/divisor[keep])
                    h2 = P@(arr["truth_half2"][:, keep]/divisor[keep])
                    half = row["cell_half_descriptive"]
                    close(np.sum(h1*h2), half["projected_cross_inner_product"], "half cross")
                    close(np.sum(h1*h1), half["projected_half1_energy"], "half1")
                    close(np.sum(h2*h2), half["projected_half2_energy"], "half2")
                    checked.append({"dataset": dataset, "seed": seed, "mode": mode, "model": name, "P_recalculated_skill": 1-sse/baseline})
                final = arr["WitnessCell_v14"][:, keep]/divisor[keep]
                backbone = arr["v14_joint_saturation_backbone"][:, keep]/divisor[keep]
                increment = final-backbone
                projected = P@increment
                ir = next(r for r in inc_rows if r["dataset"] == dataset and r["seed"] == seed and r["mode"] == mode)
                close(np.sum(increment**2), ir["increment_energy"], "increment energy")
                close(np.sum(projected**2), ir["increment_projected_energy"], "increment projected energy", atol=1e-12)
                close(1-np.sum((final-y)**2)/np.sum((backbone-y)**2), ir["full_response_error_gain_vs_joint_backbone"], "full increment gain")
                close(1-np.sum((P@(final-y))**2)/np.sum((P@(backbone-y))**2), ir["projection_error_gain_vs_joint_backbone"], "projected increment gain")

                # Conservative nearest-rounding interval for float32 archives.
                # This is conditional on the source real-valued increment being
                # additive; it is a compatibility bound, not proof of its truth.
                fraw, braw = dep["prediction"][dr], dep["factorized_prediction"][dr]
                envelope = (half_ulp32(fraw)+half_ulp32(braw))[:, keep]/divisor[keep]
                envelope_norm = float(np.linalg.norm(envelope))
                round_bound = float(np.linalg.norm(Z, 2))*envelope_norm
                ztx = float(np.linalg.norm(Z.T@X))
                basis_bound = ztx*float(np.linalg.norm(Xplus, 2))*(float(np.linalg.norm(increment))+envelope_norm)
                eps = np.finfo(float).eps
                gamma = len(X)*eps/(1-len(X)*eps)
                multiply_bound = gamma*float(np.linalg.norm(np.abs(Z).T@np.abs(increment)))
                subtraction_bound = 8*eps*float(np.linalg.norm((np.abs(fraw.astype(float))+np.abs(braw.astype(float)))[:, keep]/divisor[keep]))
                bound = round_bound+basis_bound+multiply_bound+subtraction_bound
                observed = float(np.linalg.norm(Z.T@increment))
                quantization.append({"dataset": dataset, "seed": seed, "mode": mode,
                    "observed_projected_increment_norm": observed,
                    "float32_rounding_envelope_norm": envelope_norm,
                    "basis_residual_allowance": basis_bound,
                    "double_arithmetic_allowance": multiply_bound+subtraction_bound,
                    "total_upper_bound_under_additive_source_increment": bound,
                    "observed_over_bound": observed/bound,
                    "compatible_with_additive_source_increment": bool(observed <= bound)})

    assert len(checked) == 234
    groups = json.loads((formal/"DATASET_SUMMARY.json").read_text())
    for group in groups:
        selected = [r for r in rows if all(r[k] == group[k] for k in ("dataset", "mode", "model"))]
        assert group["n_splits"] == len(selected) == 3
        ratio = sum(r["projection_SSE"] for r in selected)/sum(r["zero_contrast_baseline_SSE"] for r in selected)
        close(ratio, group["projection_error_ratio"], "pooled ratio")
        close(1-ratio, group["projection_skill"], "pooled skill")
    result = {"status": "PASS", "production_code_imported": False,
              "method": "Source NPZ reconstruction plus independent least-squares P, never importing projection_metrics",
              "n_splits": 12, "n_score_rows": len(checked), "n_increment_rows": len(inc_rows),
              "maximum_scaled_discrepancy": max(discrepancies),
              "elapsed_seconds": time.monotonic()-started,
              "lock_sha256": sha(root/"AUDIT_LOCK.json"), "verifier_sha256": sha(Path(__file__)),
              "quantization_compatible_count": sum(x["compatible_with_additive_source_increment"] for x in quantization),
              "quantization_checks": quantization, "independent_scores": checked,
              "notes": ["Float32 envelope is a conditional compatibility check, not proof that a model source operator is additive.",
                        "Historical fixed-fit provenance is established by the separate source audit; this checker verifies saved arrays, alignment and scores.",
                        "Step1 trainMean is measured/mean-completed endpoint additive, not a constant output."]}
    audit = root/"audit"
    audit.mkdir(exist_ok=True)
    (audit/"INDEPENDENT_PREDICTION_VERIFY.json").write_text(json.dumps(result, ensure_ascii=False, indent=2)+"\n")
    text = ("预测端点消去空间审计：独立复核通过\n"
            "未导入生产 runner 或 projection_metrics。由源 contract/deploy/baseline 重新对齐条件与基因，重建真值、全部预测、训练方差及固定去靶基因 mask。\n"
            "采用独立最小二乘 P=I−X X^+ 计算投影损失、零对比基线、技能、半重复能量、增量与汇总；12 划分、234 行评分、36 行增量全部核对。\n"
            f"最大缩放数值差 {max(discrepancies):.3e}，复核耗时 {result['elapsed_seconds']:.3f} 秒。\n"
            f"float32 半 ULP 包络＋双精度基/算术误差检验：{result['quantization_compatible_count']}/36 个增量与原源端点加性相容。该结果是相容性，不单独证明算子恒等式。\n"
            "Step1 trainMean 为实测/训练条件均值补全的端点加性模型，并非常数响应；不能称其没有输入信息。\n")
    (audit/"INDEPENDENT_PREDICTION_VERIFY_CN.txt").write_text(text)
    print(json.dumps({k: result[k] for k in ("status", "n_splits", "n_score_rows", "n_increment_rows", "maximum_scaled_discrepancy", "quantization_compatible_count", "elapsed_seconds")}, indent=2))

if __name__ == "__main__":
    main()
