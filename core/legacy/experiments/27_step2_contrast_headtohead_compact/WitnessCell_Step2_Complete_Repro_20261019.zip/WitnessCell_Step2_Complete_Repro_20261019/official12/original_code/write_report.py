import json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
p=ROOT/'results/formal'
rows=json.loads((p/'MODEL_SCORES.json').read_text())
inc=json.loads((p/'INCREMENT_AUDIT.json').read_text())
summary=json.loads((p/'DATASET_SUMMARY.json').read_text())
meta=json.loads((p/'RUN_METADATA.json').read_text())
datasets=['Norman','Wessels','Schmidt','Replogle_exp6']
def get(ds,s,model,mode='all_genes_raw'):
 return next((r for r in rows if r['dataset']==ds and r['seed']==s and r['model']==model and r['mode']==mode),None)
def val(r):return 'NA' if r is None else f'{r["projection_error_ratio"]:.9f}'
lines=['WitnessCell 发布测试预测的端点消去对比审计','2026-10-18','',
'正式12个划分已跑完。现有发布v14输出在该对比空间上的误差比值均接近1；最终预测与其联合选参饱和骨架的对比误差相同至保存精度。此前端点残差分支的完整响应收益没有转化为新的非加性对比预测收益。',
'本结果适用于旧版发布v14及已保存对照，不能直接替代后续55组合面板的M0/M1/R验证，也不能推论GEARS、CPA或全领域方法均无非加性预测能力。','',
'主指标：rho=||P(prediction−truth)||²/||P truth||²；P=ZZ^T消去自由端点效应。rho<1优于零对比参考，rho=1与其相同，rho>1更差。所有真值为条件均值，包含测量噪声；接近1只说明在本指标下未明显降低观测对比误差。','',
'表1 全部发布划分；全基因、未加权主分析','dataset\tseed\td\t最终v14\t联合选参饱和骨架\t独立选参saturation-only\tStep1_trainMean\t共享端点additive']
for ds in datasets:
 for s in [1,2,3]:
  r=get(ds,s,'WitnessCell_v14')
  lines.append('\t'.join([ds,str(s),str(r['contrast_dimension'])]+[val(get(ds,s,m)) for m in ['WitnessCell_v14','v14_joint_saturation_backbone','Step1_saturation_only','Step1_trainMean','Step1_shared_endpoint_additive']]))
lines+=['','表1的两个饱和对照有不同选参权限：联合骨架沿用完整模型的alpha；Step1 saturation-only在validation独立选alpha。trainMean在该保存实现中也是实测/均值补全端点相加，不是常数向量。共享端点additive与最终模型使用相同端点估计。只有Norman/Wessels六组存有Step1向量，其他格子保持NA。未见端点不得使用留出single真值补齐。','',
'表2 各数据集三seed的SSE求和比（描述性，不把seed当独立重复）','dataset\t主指标rho\t剔除面板扰动基因rho\t训练方差标准化rho\t最终模型对联合骨架的完整响应误差降低(%)']
for ds in datasets:
 vals=[]
 for mode in ['all_genes_raw','exclude_panel_targets','training_variance_standardized']:
  r=next(r for r in summary if r['dataset']==ds and r['mode']==mode and r['model']=='WitnessCell_v14');vals.append(f'{r["projection_error_ratio"]:.9f}')
 rr=[r for r in rows if r['dataset']==ds and r['mode']=='all_genes_raw']
 a=sum(r['full_response_SSE'] for r in rr if r['model']=='WitnessCell_v14');b=sum(r['full_response_SSE'] for r in rr if r['model']=='v14_joint_saturation_backbone')
 lines.append('\t'.join([ds]+vals+[f'{100*(1-a/b):.6f}']))
maxdiff=max(abs(get(ds,s,'WitnessCell_v14')['projection_error_ratio']-get(ds,s,'v14_joint_saturation_backbone')['projection_error_ratio']) for ds in datasets for s in [1,2,3])
lines+=['',f'12个主分析中，final与factorized的rho最大绝对差={maxdiff:.12g}。保存代码中残差核为端点关联核；P(final−factorized)的精确算子值为0，已保存float32向量存在量化误差。独立复核另用逐元素ULP包络判断残差是否可由量化解释，不把任意数值阈值冒充精度证明。',
'例如Wessels最终v14相对联合骨架的完整响应误差下降31.94%，对比误差却保持不变。这直接区分了端点响应校正与非加性结构预测。不能将该31.94%与论文相对trainMean的改善率混称。','',
'测量侧诊断：各split两细胞半投影均值的cosine如下。它描述同批数据细胞抽样重复性，不是独立生物学复现，不给显著性结论。','dataset\tseed1\tseed2\tseed3']
for ds in datasets:
 lines.append(ds+'\t'+'\t'.join(f'{get(ds,s,"WitnessCell_v14")["cell_half_descriptive"]["projected_cross_cosine"]:.6f}' for s in [1,2,3]))
lines+=['','受测对象边界',
'GEARS/CPA的36份表达向量全部来自项目自建Norman/GSE划分，与本表12个发布测试图不匹配；scouter/基础模型缺匹配表达输出。它们没有进入本表评分。',
'M0/M1/R来自另一套55组合、5折CaRPool实验；没有本表12个官方同fit输出。本次没有重新训练这些模型，不能把v14、其factorized或其残差重新命名成M0/M1/R。',
'实测单扰动加性若使用测试/验证权限之外的留出single，会扩大信息权限；当前公平对照是已有训练权限下的端点补全加性，不能暗称全端点实测。',
'因此，本次不支持“所有主流模型都失败”的领域级结论。可以明确说：受测旧v14的端点核增量没有提供新的端点消去预测，原来响应误差收益应按其实际来源归因。',
'seen1的103维也不能直接读成212维几乎全部：分层内部合计119维，完整图另有93维不能由这些分层内部对比张成。图约束数量与生物效应大小是不同量；既有线索来自复用面板，不据此宣称三条独立生物证据。','',
'执行与复核',f'冻结后pilot约1.69秒；正式{meta["elapsed_seconds"]:.3f}秒。共12split、234个model×split×指标模式评分。时间仅为计算，不含文件恢复和交付。',
'输入、模型字段、主指标、两个敏感性分析及聚合规则均在正式计算前内部冻结。两种敏感性分析没有按结果调参；训练方差使用训练条件、1%正方差中位数floor。',
'独立复核已通过：234个评分、36个增量诊断、原始contract/deploy/baseline和训练尺度全部一致。36/36种split×指标模式的投影增量均在逐元素半ULP加数值误差包络以内，观测范数/包络最大0.2431。',
'交付检查发现Wessels seed3的一份对齐数组文件被截断；用原冻结输入和同一函数重建该文件后，原scores、increment、identity三个JSON逐字节不变。修复不涉及模型、指标或结果修改，详见audit/ALIGNED_ARRAY_REPAIR.json。',
'完整输入、对齐数组、投影基、尺度、原始精度分数、独立复核和可复跑代码保存在同包。独立复核状态详见audit/INDEPENDENT_PREDICTION_VERIFY.json。']
(ROOT/'PREDICTION_AUDIT_RESULTS_CN.txt').write_text('\n'.join(lines)+'\n')
print('Report written')
