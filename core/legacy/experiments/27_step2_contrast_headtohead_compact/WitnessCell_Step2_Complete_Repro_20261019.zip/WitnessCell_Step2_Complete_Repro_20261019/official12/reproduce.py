#!/usr/bin/env python3
"""Recompute the 12 official-split scores from sufficient statistics.
No archived final scores are read for calculation. --verify (default) compares
new outputs with separately preserved reference tables after calculation.
"""
import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
import argparse,csv,hashlib,json
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parent
DATASETS=['Norman','Wessels','Schmidt','Replogle_exp6']
MODELS=['WitnessCell_v14','v14_joint_saturation_backbone','WitnessCell_v1_archived','v1_joint_saturation_backbone','zero_contrast_reference','Step1_trainMean','Step1_shared_endpoint_additive','Step1_saturation_only']
MODES=['all_genes_raw','exclude_panel_targets','training_variance_standardized']
def ratio(a,b):return float(a/b) if b>0 else None
def total(a):return float(np.sum(a[:-1])+a[-1])
def write_json(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
def csvout(p,rows):
 keys=list(dict.fromkeys(k for r in rows for k,v in r.items() if not isinstance(v,dict)))
 with p.open('w',newline='') as f:w=csv.DictWriter(f,keys,extrasaction='ignore');w.writeheader();w.writerows(rows)
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=ROOT/'reproduced');ap.add_argument('--no-verify',action='store_true');args=ap.parse_args();out=args.output;out.mkdir(parents=True,exist_ok=True)
 rows=[];increments=[];quantization=[]
 for ds in DATASETS:
  for seed in [1,2,3]:
   path=ROOT/f'data/{ds}_seed{seed}.npz';meta=json.loads(path.with_suffix('.json').read_text());assert hashlib.sha256(path.read_bytes()).hexdigest()==meta['sufficient_statistics_sha256']
   with np.load(path,allow_pickle=False) as z:a={k:z[k] for k in z.files}
   E,G,d=meta['E'],meta['G'],meta['d'];Z=a['Z'];X=a['X'];P=np.eye(E)-X@np.linalg.pinv(X)
   assert np.max(np.abs(Z.T@X))<1e-10
   assert np.max(np.abs(P-Z@Z.T))<1e-10
   orth=float(np.max(np.abs(Z.T@Z-np.eye(d)))) if d else 0.
   for mi,mode in enumerate(MODES):
    prefix=f'm{mi}__';s=lambda name:total(a[prefix+name]);K=len(a[prefix+'gene_indices']);T2=s('truth_projected2');Y2=s('truth_edge2');PY2=s('truth_P2')
    h12=s('half1_2');h22=s('half2_2');hc=s('half_cross')
    for j,model in enumerate(a['methods'].tolist()):
     t=lambda name:s(f'j{j}__'+name)
     H2=t('pred_projected2');SSE=t('error_projected2');HT=t('pred_truth_cross');F2=t('pred_edge2');err=ratio(SSE,T2)
     pdiff=max(abs(t('error_P2')-SSE),abs(PY2-T2),abs(t('pred_P2')-H2));pnormal=max(1.,SSE,T2,H2)
     row=dict(E=E,G_input=G,G_selected=K,contrast_dimension=d,scale_mode='externally_fixed_training_standard_deviation' if mi==2 else 'unscaled',projection_SSE=SSE,projection_MSE_per_contrast_gene=ratio(SSE,d*K),zero_contrast_baseline_SSE=T2,projection_skill=None if err is None else 1-err,projected_prediction_energy=H2,projected_truth_energy=T2,projected_prediction_truth_inner_product=HT,projected_cosine=ratio(HT,float(np.sqrt(H2)*np.sqrt(T2))),prediction_nonadditive_fraction=ratio(H2,F2),truth_nonadditive_fraction=ratio(T2,Y2),total_prediction_energy_selected_scaled=F2,total_truth_energy_selected_scaled=Y2,basis_orthogonality_max_error=orth,status='EVALUATED',P_equivalence=dict(P_source='independently_supplied',max_abs_P_minus_ZZt=float(np.max(np.abs(P-Z@Z.T))),max_abs_energy_difference=pdiff,relative_energy_difference=pdiff/pnormal,**{'pass':bool(pdiff/pnormal<1e-8)}),cell_half_descriptive=dict(projected_half1_energy=h12,projected_half2_energy=h22,projected_cross_inner_product=hc,projected_cross_cosine=ratio(hc,float(np.sqrt(h12)*np.sqrt(h22))),cross_over_mean_half_energy=ratio(hc,.5*(h12+h22)),interpretation='descriptive cell-half reproducibility; not independent biological replicates'),dataset=ds,seed=seed,mode=mode,model=model,split_id=meta['split_id'],projection_error_ratio=err,full_response_SSE=t('error_edge2'),numerical_degeneracy=bool(T2<=100*np.finfo(float).eps*max(Y2,np.finfo(float).tiny)))
     rows.append(row)
    inc=s('inc2');pi=s('inc_projected2');fraction=ratio(pi,inc);eb=s('inc_back_error2');pb=s('inc_back_projected_error2')
    increments.append(dict(dataset=ds,seed=seed,mode=mode,increment_energy=inc,increment_projected_energy=pi,increment_projected_fraction=fraction,compatible_with_additive_increment_at_float32_precision=bool(inc==0 or fraction<=1e-10),full_response_error_gain_vs_joint_backbone=None if eb==0 else 1-s('inc_final_error2')/eb,projection_error_gain_vs_joint_backbone=None if pb==0 else 1-s('inc_final_projected_error2')/pb,max_absolute_projected_increment=float(np.max(a[prefix+'inc_projected_max']))))
    observed,envelope,round_bound,basis,arithmetic=a[prefix+'quantization_norm_components'];bound=round_bound+basis+arithmetic
    quantization.append(dict(dataset=ds,seed=seed,mode=mode,observed_projected_increment_norm=float(observed),float32_rounding_envelope_norm=float(envelope),basis_residual_allowance=float(basis),double_arithmetic_allowance=float(arithmetic),total_upper_bound_under_additive_source_increment=float(bound),observed_over_bound=float(observed/bound),compatible_with_additive_source_increment=bool(observed<=bound)))
 groups=[]
 for ds in DATASETS:
  for mode in sorted(MODES):
   for model in sorted(MODELS):
    rr=[r for r in rows if r['dataset']==ds and r['mode']==mode and r['model']==model]
    if rr:
     v=ratio(sum(r['projection_SSE'] for r in rr),sum(r['zero_contrast_baseline_SSE'] for r in rr))
     groups.append(dict(dataset=ds,mode=mode,model=model,n_splits=len(rr),projection_error_ratio=v,projection_skill=None if v is None else 1-v,note='descriptive within-dataset pooled SSE; overlapping splits are not independent'))
 for name,data in [('MODEL_SCORES',rows),('INCREMENT_AUDIT',increments),('DATASET_SUMMARY',groups)]:write_json(out/(name+'.json'),data);csvout(out/(name+'.csv'),data)
 for mode in MODES:
  table=[]
  for ds in DATASETS:
   for seed in [1,2,3]:
    rr=[r for r in rows if r['dataset']==ds and r['seed']==seed and r['mode']==mode];ref=rr[0];v={r['model']:r['projection_error_ratio'] for r in rr}
    table.append(dict(dataset=ds,seed=seed,d=ref['contrast_dimension'],E=ref['E'],**{m:v.get(m,'NA') for m in MODELS}))
  csvout(out/f'MAIN_TABLE_{mode}.csv',table)
 write_json(out/'QUANTIZATION_COMPATIBILITY.json',quantization)
 comparisons=0;maxdiff=0.;maxscaled=0.;mismatches=[]
 def compare(x,y,label):
  nonlocal comparisons,maxdiff,maxscaled
  if isinstance(y,dict):
   assert set(x)==set(y),(label,set(x)^set(y))
   for k in y:compare(x[k],y[k],label+'.'+k)
  elif isinstance(y,list):
   assert len(x)==len(y),label
   for i,(u,v) in enumerate(zip(x,y)):compare(u,v,label+f'[{i}]')
  elif isinstance(y,(int,float)) and not isinstance(y,bool):
   comparisons+=1;diff=abs(float(x)-float(y));scale=max(1.,abs(float(x)),abs(float(y)));maxdiff=max(maxdiff,diff);maxscaled=max(maxscaled,diff/scale)
   if diff>2e-9+1e-10*scale:mismatches.append((label,x,y))
  else:
   assert x==y,(label,x,y)
 if not args.no_verify:
  for name,actual in [('MODEL_SCORES',rows),('INCREMENT_AUDIT',increments),('DATASET_SUMMARY',groups)]:
   expected=json.loads((ROOT/f'expected/{name}.json').read_text());compare(actual,expected,name)
  expected=json.loads((ROOT/'expected/INDEPENDENT_PREDICTION_VERIFY.json').read_text())['quantization_checks'];lookup={(r['dataset'],r['seed'],r['mode']):r for r in quantization}
  compare([lookup[(r['dataset'],r['seed'],r['mode'])] for r in expected],expected,'quantization')
 assert not mismatches,mismatches[:10]
 assert len(rows)==234 and len(increments)==36 and all(r['compatible_with_additive_source_increment'] for r in quantization)
 report=dict(passed=True,comparisons=comparisons,max_abs_diff=maxdiff,max_scaled_diff=maxscaled,n_score_rows=len(rows),n_increment_rows=len(increments),n_splits=12,contrast_dimensions=sum(json.loads((ROOT/f'data/{ds}_seed{s}.json').read_text())['d'] for ds in DATASETS for s in [1,2,3]),source_arrays_used_at_extraction=True,final_score_tables_used_for_calculation=False,scope='Exact declared-score reproduction from float64 sufficient statistics; no raw-prediction reconstruction or model retraining',tolerance='abs 2e-9 + relative 1e-10; original independent-verifier tolerance')
 write_json(out/'REPRODUCTION_CHECK.json',report);print(json.dumps(report,indent=2))
if __name__=='__main__':main()
