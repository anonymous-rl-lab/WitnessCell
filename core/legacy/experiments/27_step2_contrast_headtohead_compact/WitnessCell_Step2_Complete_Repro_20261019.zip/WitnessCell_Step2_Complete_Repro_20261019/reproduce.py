#!/usr/bin/env python3
"""Offline score reproduction. No downloads, installation, GPU use or model retraining."""
import argparse,csv,json,os,subprocess,sys,time
from pathlib import Path

ROOT=Path(__file__).resolve().parent

def readcsv(path):
    with path.open(newline='') as f:return list(csv.DictReader(f))

def writecsv(path,rows):
    with path.open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--output',type=Path,default=ROOT/'reproduced')
    ap.add_argument('--figure',action='store_true',help='Also recreate PNG/SVG; requires matplotlib')
    a=ap.parse_args();out=a.output.resolve();out.mkdir(parents=True,exist_ok=True)
    start=time.monotonic()
    env=os.environ.copy()
    for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):env[k]='1'
    subprocess.run([sys.executable,str(ROOT/'verify.py')],check=True,env=env)
    checks={}
    for name in ('official12','headtohead'):
        dest=out/name
        command=[sys.executable,str(ROOT/name/'reproduce.py'),'--output',str(dest)]
        with (out/(name+'.log')).open('w') as log:
            subprocess.run(command,check=True,stdout=log,stderr=subprocess.STDOUT,env=env)
        checks[name]=json.loads((dest/'REPRODUCTION_CHECK.json').read_text())
        assert checks[name]['passed'],name
        print(name+': scores reproduced',flush=True)

    old=readcsv(out/'official12/MODEL_SCORES.csv');rows=[]
    for dataset in ('Norman','Wessels','Schmidt','Replogle_exp6'):
        select=lambda m:[r for r in old if r['dataset']==dataset and r['mode']=='all_genes_raw' and r['model']==m]
        final=select('WitnessCell_v14');base=select('v14_joint_saturation_backbone')
        total=lambda rs,k:sum(float(r[k]) for r in rs)
        rows.append(dict(study='official12',dataset=dataset,condition_seed_units=int(total(final,'E')),
            contrast_dimensions=int(total(final,'contrast_dimension')),
            full_response_gain_vs_joint_backbone=1-total(final,'full_response_SSE')/total(base,'full_response_SSE'),
            projected_error_gain_vs_joint_backbone=1-total(final,'projection_SSE')/total(base,'projection_SSE'),
            projection_ratio_final=total(final,'projection_SSE')/total(final,'zero_contrast_baseline_SSE')))
    writecsv(out/'A_Official12_Dataset_Summary.csv',rows)
    new={r['model']:r for r in readcsv(out/'headtohead/FINAL_PK_TABLE.csv')}
    std={r['model']:r for r in readcsv(out/'headtohead/FINAL_PK_TABLE_STANDARDIZED.csv')}
    drop={r['model']:r for r in readcsv(out/'headtohead/FINAL_PK_TABLE_DROP10.csv')}
    comparison=[]
    for m,r in new.items():
        comparison.append(dict(study='headtohead55',model=m,C_MSE=float(r['C_MSE_mean']),
            C_gain_vs_M0=float(r['C_gain_over_M0_mean']),projection_ratio=float(r['projection_ratio_mean']),
            projection_ratio_min=float(r['projection_ratio_min']),projection_ratio_max=float(r['projection_ratio_max']),
            response_MSE=float(r['response_MSE_mean']),response_gain_vs_M0=float(r['response_gain_over_M0_mean']),
            standardized_C_gain_vs_M0=float(std[m]['C_gain_over_M0_mean']),drop10_C_gain_vs_M0=float(drop[m]['C_gain_over_M0_mean'])))
    writecsv(out/'B_Matched55_Model_Comparison.csv',comparison)
    pairwise=[]
    for m in ('M0','M1','additive','GEARS','scouter'):
        pairwise.append(dict(model='R',reference=m,C_error_reduction_vs_reference=1-float(new['R']['C_MSE_mean'])/float(new[m]['C_MSE_mean']),
            C_error_reduction_vs_best_reference_seed=1-float(new['R']['C_MSE_mean'])/float(new[m]['C_MSE_min'])))
    writecsv(out/'B_R_Pairwise_Comparisons.csv',pairwise)
    if a.figure:
        subprocess.run([sys.executable,str(ROOT/'make_figure.py'),'--results',str(out)],check=True,env=env)
    result=dict(passed=True,modules=checks,
        checked_values=sum(c['comparisons']+c.get('additional_table_comparisons',0) for c in checks.values()),
        max_abs_diff=max(c['max_abs_diff'] for c in checks.values()),
        seconds=time.monotonic()-start,figure_recreated=a.figure,
        scope='Offline reproduction of all declared scores from unquantized float64 contributions. Full prediction arrays and training inputs remain in the original experiment archives; v22 adds only this compact package and navigation.',
        independent_studies_pooled=False,model_training_performed=False)
    (out/'REPRODUCTION_CHECK.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k!='modules'},indent=2))

if __name__=='__main__':main()
