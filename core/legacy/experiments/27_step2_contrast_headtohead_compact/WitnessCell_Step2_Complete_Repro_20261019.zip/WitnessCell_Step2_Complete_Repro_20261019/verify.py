#!/usr/bin/env python3
"""Verify immutable package files; generated outputs may coexist with sources."""
import argparse,hashlib,json
from pathlib import Path

def main():
    p=argparse.ArgumentParser();p.add_argument('--root',type=Path,default=Path(__file__).resolve().parent)
    a=p.parse_args();root=a.root.resolve();manifest=json.loads((root/'PACKAGE_MANIFEST.json').read_text())
    errors=[]
    for r in manifest['files']:
        path=(root/r['path']).resolve()
        if not path.is_relative_to(root) or not path.is_file():errors.append({'path':r['path'],'error':'missing or unsafe path'});continue
        b=path.read_bytes()
        if len(b)!=r['bytes'] or hashlib.sha256(b).hexdigest()!=r['sha256']:errors.append({'path':r['path'],'error':'bytes/hash mismatch'})
    result={'passed':not errors,'checked_files':len(manifest['files']),'errors':errors}
    print(json.dumps(result,indent=2));assert not errors,'Package integrity failed'

if __name__=='__main__':main()
