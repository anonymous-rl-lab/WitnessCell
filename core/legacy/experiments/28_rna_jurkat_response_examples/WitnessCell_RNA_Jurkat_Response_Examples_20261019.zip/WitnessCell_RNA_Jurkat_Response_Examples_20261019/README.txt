WitnessCell — RNA four-corner responses and Jurkat named combinations
Date: 19 October 2026

Purpose
Make the existing prediction gains visible as concrete RNA and growth-response examples. All predictions are the saved original v17 model outputs. No model was trained, selected, modified or clipped. Original competitive percentages are unchanged.

Start here
figures/RNA_four_corner_responses.pdf
figures/Jurkat_specific_combinations.pdf
text/PAPER_INSERTIONS_EN.txt — ready-to-use Results, Methods and Discussion text
text/FIGURE_LEGENDS_EN.txt — complete captions and selection disclosure
RESULTS_CN.txt — concise scientific interpretation

Each figure is supplied as PDF, editable SVG and PNG. Complementary displays include all eleven RNA contrasts for the illustrated readouts, all 617 Jurkat test pairs and adverse examples. This is a display/analysis supplement; it is not a replacement for the complete experiment reproduction packages.

Rebuild every figure (Python, NumPy and Matplotlib; no network/GPU needed)
python code/build_display_figures.py

Recheck the package tables and displayed calculations
python code/check_display_tables.py

Data
rna/selected_four_corners.csv contains the exact four RNA condition values, model predictions, condition cell counts, training weights through the paired JSON, and technical halves. rna/all_rectangle_readout_candidates.csv.gz contains all 54,945 evaluated coordinates. The CSV preserves signed contrasts; source logNor units must not be called fold changes.
jurkat/Jurkat_all_617_pairs_two_repeats.csv retains both observed and predicted repeats for all test pairs. Jurkat_all_617_pair_scores.csv and Jurkat_all_shared_endpoint_comparisons.csv include all corresponding pair and shared-endpoint comparisons. The latter are not endpoint-free contrasts.

The RNA and Jurkat analysis scripts also preserve extraction logic and hashes of the original experiment assets. Rerunning full extraction requires those existing original archives at the supplied paths; recreating the figures and checking the included numeric tables is self-contained. No original cell matrix, neural environment or model checkpoint has been duplicated into this display package.

Selection and interpretation
Examples were chosen after inspecting saved outcomes to make the prediction behavior understandable. They include deliberate high-gain cases, plus adverse cases in supplementary displays. They are not representative samples, preregistered endpoints or new validation experiments. Local case improvements do not replace the full-panel 15.96% RNA or 6.43% Jurkat results. Methods and captions specify the exact rules.

Paper integration
Use the RNA panels to expand the current Fig. 3e–f contrast-only explanation; retain complete profiles in Extended Data. Add named Jurkat combinations to Fig. 5 with the all-pair background. Main-text insertion paragraphs and Methods disclosure are included. This delivery does not change or renumber the released v17 paper or the code release.
