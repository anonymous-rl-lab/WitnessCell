#!/usr/bin/env python3
"""Publication displays from saved predictions only; no model fitting or selection."""
from pathlib import Path
import csv,json,string
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'figures';OUT.mkdir(exist_ok=True)
COL={'observed':'#182D3B','M0':'#89949E','M1':'#3B78A3','R':'#BC7F25','rank1_selected':'#3B78A3'}
NAME={'observed':'Observed','M0':'Baseline M0','M1':'Partner M1','R':'Weighted R','rank1_selected':'M0 + partner'}
MARK={'observed':'D','M0':'s','M1':'^','R':'o','rank1_selected':'o'}
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'axes.titlesize':10,
 'axes.labelsize':9,'xtick.labelsize':8.5,'ytick.labelsize':8.5,'axes.spines.top':False,
 'axes.spines.right':False,'axes.linewidth':.7,'pdf.fonttype':42,'ps.fonttype':42,
 'svg.fonttype':'none','savefig.facecolor':'white','figure.facecolor':'white'})
def read(p):return list(csv.DictReader((ROOT/p).open()))
def num(r,k):return float(r[k])
def panel(ax,letter,title):
 ax.set_title(title,loc='left',pad=14,fontweight='bold');ax.text(-.16,1.10,letter,
 transform=ax.transAxes,fontweight='bold',fontsize=13,va='bottom')
 ax.set_axisbelow(True);ax.grid(axis='y',lw=.55,color='#E2E7EB');ax.tick_params(length=3)
def save(fig,name):
 for ext in ('pdf','svg','png'):fig.savefig(OUT/f'{name}.{ext}',dpi=250,bbox_inches='tight',pad_inches=.15)
 plt.close(fig)
def legend(fig,models,y=.02):
 handles=[Line2D([0],[0],color=COL[m],marker=MARK[m],lw=1.3,ms=5,
 label=NAME[m],mfc='white' if m=='M0' else COL[m]) for m in models]
 fig.legend(handles=handles,loc='lower center',bbox_to_anchor=(.5,y),frameon=False,ncol=len(models),fontsize=9)

corners=read('rna/selected_four_corners.csv')
examples=json.loads((ROOT/'rna/RNA_EXAMPLES.json').read_text())['example_records']
def rna_row(fig,axes,case,letters):
 rows=[r for r in corners if r['case']==case];e=next(e for e in examples if e['case']==case)
 rownames=list(dict.fromkeys(r['row_endpoint'] for r in rows));cols=list(dict.fromkeys(r['column_endpoint'] for r in rows))
 vals=[num(r,k) for r in rows for k in ('observed_effect','M0_effect','M1_effect','R_effect')]
 lo,hi=min(vals),max(vals);pad=.14*(hi-lo or 1);lims=(lo-pad,hi+pad)
 for i,a in enumerate(axes[:2]):
  rs=[next(r for r in rows if r['row_endpoint']==rownames[i] and r['column_endpoint']==c) for c in cols]
  panel(a,letters[i],f"{e['readout']} | {rownames[i]} background")
  a.axhline(0,color='#CDD5DC',lw=.7)
  for m in ('observed','M0','M1','R'):
   yy=[num(r,m+'_effect') for r in rs];a.plot([0,1],yy,color=COL[m],marker=MARK[m],
    lw=1.9 if m=='observed' else 1.25,ms=5,ls='--' if m=='M0' else '-',
    mfc='white' if m=='M0' else COL[m],zorder=5 if m=='observed' else 3)
  for x,r in enumerate(rs):a.annotate(f"{num(r,'observed_effect'):+.3f}",(x,num(r,'observed_effect')),
    xytext=(0,9),textcoords='offset points',ha='center',fontsize=8,color=COL['observed'])
  a.set_xticks([0,1],cols);a.set_xlim(-.23,1.23);a.set_ylim(*lims);a.set_xlabel('Partner perturbation')
  if i==0:a.set_ylabel('RNA response relative to control\n(source logNor units)')
 a=axes[2];panel(a,letters[2],f"{e['readout']} | four-corner contrast")
 mods=('observed','M0','M1','R');vs=[e['observed_contrast'],e['M0_contrast'],e['M1_contrast'],e['R_contrast']]
 a.axhline(0,color='#253B4A',lw=.7);a.bar(range(4),vs,color=[COL[m] for m in mods],width=.60)
 for x,v in enumerate(vs):a.text(x,v+(.08 if v>=0 else -.08),f'{v:+.3f}',ha='center',va='bottom' if v>=0 else 'top',fontsize=8)
 a.set_xticks(range(4),['Observed','M0','M1','R']);a.set_ylabel('Difference of differences, C')
 a.set_ylim(min(0,min(vs))-.35,max(vs)+.50)
 a.text(.97,.96,f"Training weight = {e['training_weight']:.3f}",transform=a.transAxes,ha='right',va='top',fontsize=8)

def rna_main():
 fig,axes=plt.subplots(2,3,figsize=(12.4,7.5));fig.subplots_adjust(left=.075,right=.98,top=.91,bottom=.13,wspace=.40,hspace=.65)
 rna_row(fig,axes[0],'positive_S100A9','abc');rna_row(fig,axes[1],'positive_LYZ','def')
 legend(fig,['observed','M0','M1','R']);save(fig,'RNA_four_corner_responses')

def rna_context():
 fig=plt.figure(figsize=(12.4,7.5));gs=fig.add_gridspec(2,6,left=.075,right=.98,top=.92,bottom=.13,wspace=.9,hspace=.72)
 rows=read('rna/selected_readouts_all_11_rectangles.csv')
 for j,gene in enumerate(['S100A9','LYZ']):
  a=fig.add_subplot(gs[0,j*3:(j+1)*3]);panel(a,'ab'[j],gene+' | all eleven contrasts')
  rr=sorted([r for r in rows if r['gene']==gene],key=lambda r:int(r['rectangle']))
  for m in ('observed','M0','M1','R'):
   a.plot(range(1,12),[num(r,'C_'+m) for r in rr],color=COL[m],marker=MARK[m],lw=1.3,ms=4,ls='--' if m=='M0' else '-')
  a.axhline(0,color='#CDD5DC',lw=.6);a.set_xticks(range(1,12));a.set_xlabel('Archived rectangle');a.set_ylabel('Signed contrast C')
 axes=[fig.add_subplot(gs[1,j*2:(j+1)*2]) for j in range(3)]
 rna_row(fig,axes,'failure_global_largest_harm','cde')
 legend(fig,['observed','M0','M1','R']);save(fig,'RNA_all_contrasts_and_limitation')

jrows=read('jurkat/Jurkat_selected_pairs_two_repeats.csv');allj=read('jurkat/Jurkat_all_617_pair_scores.csv')
def jpair(pair):return sorted([r for r in jrows if r['pair_id']==pair],key=lambda r:int(r['repeat']))
def repeatpoints(a,rows,letter,title):
 panel(a,letter,title);mods=('observed','M0','rank1_selected')
 for j,m in enumerate(mods):
  for rep,r in enumerate(rows):a.scatter(rep+(j-1)*.16,num(r,m),color=COL[m],marker=MARK[m],s=40,
   edgecolors='white' if m!='M0' else COL[m],facecolors='white' if m=='M0' else COL[m],linewidth=.9,zorder=4)
 for rep,r in enumerate(rows):a.hlines(num(r,'observed'),rep-.35,rep+.35,color=COL['observed'],lw=.8,alpha=.65)
 a.set_xticks([0,1],['Repeat 1','Repeat 2']);a.set_xlim(-.5,1.5);a.set_ylabel('Growth phenotype, γ')
 vs=[num(r,m) for r in rows for m in mods];p=max(.006,(max(vs)-min(vs))*.20);a.set_ylim(min(vs)-p,max(vs)+p)

def jurkat_main():
 fig,axes=plt.subplots(2,2,figsize=(9.2,7.8));fig.subplots_adjust(left=.10,right=.98,top=.92,bottom=.13,wspace=.38,hspace=.55)
 a,b,c,d=axes.ravel();panel(a,'a','All 617 held-out combinations')
 xx=np.array([np.sqrt(num(r,'M0_SSE')/2) for r in allj]);yy=np.array([np.sqrt(num(r,'rank1_selected_SSE')/2) for r in allj])
 a.scatter(xx,yy,s=13,color='#9BA8B3',alpha=.6,edgecolors='none');lim=max(max(xx),max(yy))*1.05
 a.plot([0,lim],[0,lim],color='#3E515D',ls='--',lw=.8);a.set_xlim(-.004,lim);a.set_ylim(-.004,lim)
 a.set_xlabel('Baseline M0: pair RMSE');a.set_ylabel('M0 + partner: pair RMSE')
 a.text(.04,.96,'Pooled squared error: −6.43%\n349/617 pairs improve',transform=a.transAxes,va='top',fontsize=9)
 for pair,offset in [('MED1|RPL10',(14,-8)),('NIP7|POLN',(-60,12))]:
  r=next(r for r in allj if r['pair_id']==pair);x=np.sqrt(num(r,'M0_SSE')/2);y=np.sqrt(num(r,'rank1_selected_SSE')/2)
  a.scatter(x,y,s=40,color='#BC7F25',edgecolor='white',lw=.5,zorder=5)
  a.annotate(pair.replace('|',' + '),(x,y),xytext=offset,textcoords='offset points',fontsize=7.5,arrowprops={'arrowstyle':'-','lw':.6,'color':'#647786'})
 panel(b,'b','TTI2: changing the partner')
 pairs=['PGK1|TTI2','OGFOD1|TTI2']
 for m in ('observed','M0','rank1_selected'):
  vs=[np.mean([num(r,m) for r in jpair(pair)]) for pair in pairs]
  b.plot([0,1],vs,color=COL[m],marker=MARK[m],ms=5,lw=1.6,ls='--' if m=='M0' else '-')
 for x,pair in enumerate(pairs):
  rr=jpair(pair)
  for rep,r in enumerate(rr):b.scatter(x+(-.045 if rep==0 else .045),num(r,'observed'),s=24,color=COL['observed'],marker='x',zorder=5)
  b.annotate(f"{np.mean([num(r,'observed') for r in rr]):+.3f}",(x,np.mean([num(r,'observed') for r in rr])),xytext=(0,11),textcoords='offset points',ha='center',fontsize=8)
 b.set_xticks([0,1],['TTI2 + PGK1','TTI2 + OGFOD1']);b.set_xlim(-.20,1.20);b.set_ylim(-.39,.02);b.set_ylabel('Growth phenotype, γ')
 b.text(.05,.95,'Lines: repeat means\nCrosses: individual observations',transform=b.transAxes,va='top',fontsize=8)
 repeatpoints(c,jpair('MED1|RPL10'),'c','MED1 + RPL10: both repeats improve')
 panel(d,'d','TTI2 partner difference in each repeat')
 p=jpair('PGK1|TTI2');o=jpair('OGFOD1|TTI2')
 for j,m in enumerate(('observed','M0','rank1_selected')):
  vals=[num(o[i],m)-num(p[i],m) for i in range(2)]
  x=np.arange(2)+(j-1)*.18;d.bar(x,vals,width=.16,color=COL[m])
  for xi,v in zip(x,vals):d.text(xi,v+.005,f'{v:.3f}',ha='center',va='bottom',fontsize=7.5,rotation=0)
 d.set_xticks([0,1],['Repeat 1','Repeat 2']);d.set_ylim(0,.36);d.set_ylabel('γ(TTI2 + OGFOD1) − γ(TTI2 + PGK1)')
 legend(fig,['observed','M0','rank1_selected']);save(fig,'Jurkat_specific_combinations')

def jurkat_context():
 fig,axes=plt.subplots(1,2,figsize=(9.2,4.2));fig.subplots_adjust(left=.10,right=.98,top=.83,bottom=.20,wspace=.38)
 a,b=axes;repeatpoints(a,jpair('NIP7|POLN'),'a','NIP7 + POLN: both repeats worsen')
 panel(b,'b','Direction of per-pair error changes')
 both=sum(r['rank1_both_repeats_improved']=='True' for r in allj);bad=sum(r['rank1_both_repeats_worsened']=='True' for r in allj)
 counts=[both,len(allj)-both-bad,bad];b.bar(range(3),counts,color=['#3B78A3','#9BA8B3','#BC7F25'])
 for x,v in enumerate(counts):b.text(x,v+5,str(v),ha='center')
 b.set_xticks(range(3),['Both repeats\nimprove','Mixed or tied','Both repeats\nworsen']);b.set_ylabel('Held-out combinations');b.set_ylim(0,max(counts)*1.15)
 legend(fig,['observed','M0','rank1_selected'],y=.005);save(fig,'Jurkat_all_pairs_and_limitation')

if __name__=='__main__':
 rna_main();rna_context();jurkat_main();jurkat_context()
 print('Created four figures in PDF, SVG and PNG; no training or model changes.')
