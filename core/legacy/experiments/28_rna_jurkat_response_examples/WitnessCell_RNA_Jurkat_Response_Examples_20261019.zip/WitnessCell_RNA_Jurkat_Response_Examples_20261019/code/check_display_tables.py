#!/usr/bin/env python3
"""Self-contained numerical checks of the distributed display source tables."""
from pathlib import Path
import csv,gzip,json
import numpy as np
R=Path(__file__).resolve().parents[1]
def read(name):return list(csv.DictReader((R/name).open()))
def main():
 checks=[];corners=read('rna/selected_four_corners.csv');reported=read('rna/selected_contrasts.csv')
 for case in sorted({r['case'] for r in corners}):
  rows=[r for r in corners if r['case']==case];assert len(rows)==4
  assert len({r['fold'] for r in rows})==1
  for m in ('M0','M1','R','scalar'):
   rec=next(r for r in reported if r['case']==case and r['model']==m)
   truth=sum(float(r['contrast_sign'])*float(r['observed_effect']) for r in rows)
   pred=sum(float(r['contrast_sign'])*float(r[m+'_effect']) for r in rows)
   assert abs(truth-float(rec['observed_contrast']))<1e-12
   assert abs(pred-float(rec['predicted_contrast']))<1e-12
   checks.append({'case':case,'model':m,'observed_C':truth,'predicted_C':pred})
 sums={m:0. for m in ('M0','M1','R','scalar')};n=0
 with gzip.open(R/'rna/all_rectangle_readout_candidates.csv.gz','rt') as f:
  for row in csv.DictReader(f):
   n+=1;y=float(row['C_observed'])
   for m in sums:sums[m]+=(float(row['C_'+m])-y)**2
 assert n==11*4995
 losses={m:s/n for m,s in sums.items()};assert abs((1-losses['R']/losses['M0'])-.15962232110364138)<1e-12
 jr=read('jurkat/Jurkat_all_617_pairs_two_repeats.csv');assert len(jr)==1234
 ids={r['pair_id'] for r in jr};assert len(ids)==617
 for p in ids:assert {int(r['repeat']) for r in jr if r['pair_id']==p}=={1,2}
 sse={m:sum((float(r[m])-float(r['observed']))**2 for r in jr) for m in ('M0','rank1_selected')}
 gain=1-sse['rank1_selected']/sse['M0'];assert abs(gain-.0643083483997059)<1e-12
 report={'status':'PASS','RNA_four_corner_checks':checks,'RNA_all_coordinate_count':n,'RNA_C_MSE':losses,
  'Jurkat_pairs':len(ids),'Jurkat_rows':len(jr),'Jurkat_SSE':sse,'Jurkat_gain':gain,
  'new_model_fits':0}
 print(json.dumps(report,indent=2))
 return report
if __name__=='__main__':main()
