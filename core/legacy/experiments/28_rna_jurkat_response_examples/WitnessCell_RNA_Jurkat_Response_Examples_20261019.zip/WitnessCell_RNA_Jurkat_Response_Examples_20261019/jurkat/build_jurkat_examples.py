"""Read-only, post-hoc explanation of existing frozen Jurkat predictions.

No training, outcome-based model choice, filtering of the evaluation population,
or changes to the registered/frozen analysis are performed.
"""
from pathlib import Path
import argparse, hashlib, io, itertools, json, zipfile
import numpy as np
import pandas as pd

ap = argparse.ArgumentParser()
ap.add_argument('--paper', type=Path, default=Path('witnesscell_paper_v17_full'))
ap.add_argument('--out', type=Path, default=Path(__file__).parent)
args=ap.parse_args(); out=args.out; out.mkdir(parents=True, exist_ok=True)
src=args.paper/'source_data'
d=pd.read_csv(src/'Horlbeck_predictions.csv')
d=d[d.stage.eq('Jurkat')].copy().sort_values(['pair_id','repeat'])
gene_map=pd.read_csv(src/'Horlbeck_Jurkat_genes.csv').set_index('gene_index').gene.to_dict()
archive=args.paper/'experiments/WitnessCell_Horlbeck_TwoStage_Repro_20261018.zip'
prefix='WitnessCell_Horlbeck_TwoStage_Repro_20261018/stages/Jurkat/'
with zipfile.ZipFile(archive) as z:
    train=np.load(io.BytesIO(z.read(prefix+'inputs/training.npz')))
    query=np.load(io.BytesIO(z.read(prefix+'inputs/query.npz')))
    counts=np.load(io.BytesIO(z.read(prefix+'inputs/measurement_counts.npz')))
    provenance=json.loads(z.read(prefix+'INPUT_PROVENANCE.json'))
    source_check=json.loads(z.read(prefix+'SOURCE_CHECK.json'))
assert len(d)==1234 and d.pair_id.nunique()==617
assert set(d.pair_id)==set(query['global_ids'])
assert not set(d.pair_id)&set(train['global_ids'])
assert all(gene_map[i]==g for i,g in enumerate(train['genes']))
assert d.groupby('pair_id').repeat.apply(lambda x:sorted(x)==[1,2]).all()
edges=train['edges']; degree=np.bincount(edges.ravel(),minlength=79)
neighbors=[set() for _ in range(79)]
for a,b in edges: neighbors[a].add(b); neighbors[b].add(a)
countmap={str(p): counts['pair_physical_counts'][i] for i,p in enumerate(counts['pair_ids'])}
models=['M0','M0_repeat_mean','rank1_selected','spectral_selected']
d['gene_a']=d.endpoint_a.map(gene_map); d['gene_b']=d.endpoint_b.map(gene_map)
d['train_degree_a']=d.endpoint_a.map(dict(enumerate(degree)))
d['train_degree_b']=d.endpoint_b.map(dict(enumerate(degree)))
d['train_common_neighbors']=[len(neighbors[a]&neighbors[b]) for a,b in zip(d.endpoint_a,d.endpoint_b)]
d['physical_guide_pairs']=[int(countmap[p][r-1]) for p,r in zip(d.pair_id,d.repeat)]
d['single_a']=[train['singles'][a,r-1] for a,r in zip(d.endpoint_a,d.repeat)]
d['single_b']=[train['singles'][a,r-1] for a,r in zip(d.endpoint_b,d.repeat)]
for m in models:
    d[m+'_signed_error']=d[m]-d.observed
    d[m+'_absolute_error']=(d[m]-d.observed).abs()
    d[m+'_squared_error']=(d[m]-d.observed)**2
d['rank1_correction']=d.rank1_selected-d.M0
d['rank1_SSE_reduction']=d.M0_squared_error-d.rank1_selected_squared_error
d.to_csv(out/'Jurkat_all_617_pairs_two_repeats.csv',index=False,float_format='%.17g')
rows=[]; grouped={p:x.sort_values('repeat') for p,x in d.groupby('pair_id')}
for p,x in grouped.items():
    row={'pair_id':p,'gene_a':x.gene_a.iloc[0],'gene_b':x.gene_b.iloc[0],
         'endpoint_a':int(x.endpoint_a.iloc[0]),'endpoint_b':int(x.endpoint_b.iloc[0]),
         'train_degree_a':int(x.train_degree_a.iloc[0]),'train_degree_b':int(x.train_degree_b.iloc[0]),
         'train_common_neighbors':int(x.train_common_neighbors.iloc[0]),
         'observed_mean':x.observed.mean(),'observed_repeat_difference':x.observed.iloc[1]-x.observed.iloc[0]}
    for m in models:
        row[m+'_mean']=x[m].mean(); row[m+'_SSE']=x[m+'_squared_error'].sum()
        row[m+'_MAE']=x[m+'_absolute_error'].mean()
    row['rank1_SSE_reduction']=row['M0_SSE']-row['rank1_selected_SSE']
    row['rank1_relative_SSE_reduction']=row['rank1_SSE_reduction']/row['M0_SSE']
    row['rank1_min_repeat_SSE_reduction']=x.rank1_SSE_reduction.min()
    row['rank1_max_repeat_SSE_reduction']=x.rank1_SSE_reduction.max()
    row['rank1_both_repeats_improved']=bool((x.rank1_SSE_reduction>0).all())
    row['rank1_both_repeats_worsened']=bool((x.rank1_SSE_reduction<0).all())
    row['rank1_correction_mean']=x.rank1_correction.mean()
    rows.append(row)
f=pd.DataFrame(rows)
for key in ['rank1_SSE_reduction','rank1_relative_SSE_reduction','rank1_min_repeat_SSE_reduction']:
    f[key+'_descending_rank']=f[key].rank(method='min',ascending=False).astype(int)
    f[key+'_percentile']=f[key].rank(method='average',pct=True)*100
f=f.sort_values(['rank1_SSE_reduction','pair_id'],ascending=[False,True])
f.to_csv(out/'Jurkat_all_617_pair_scores.csv',index=False,float_format='%.17g')

shared=[]
for a in range(79):
    pool=[(p,x) for p,x in grouped.items() if a in x[['endpoint_a','endpoint_b']].iloc[0].to_list()]
    for (p1,x1),(p2,x2) in itertools.combinations(pool,2):
        row={'anchor':gene_map[a],'pair1':p1,'pair2':p2}
        delta={m:x1[m].to_numpy()-x2[m].to_numpy() for m in ['observed']+models}
        for m,v in delta.items():
            row[m+'_difference_mean']=float(v.mean())
            for r,val in enumerate(v,1): row[m+f'_difference_repeat{r}']=float(val)
            if m!='observed': row[m+'_difference_SSE']=float(np.sum((delta[m]-delta['observed'])**2))
        gains=(delta['M0']-delta['observed'])**2-(delta['rank1_selected']-delta['observed'])**2
        row['rank1_difference_SSE_reduction']=float(gains.sum())
        row['rank1_min_repeat_difference_SSE_reduction']=float(gains.min())
        row['same_observed_direction']=bool(np.prod(delta['observed'])>0)
        row['both_pairs_improve_in_both_repeats']=bool((x1.rank1_SSE_reduction>0).all() and (x2.rank1_SSE_reduction>0).all())
        row['opposite_corrections']=bool(x1.rank1_correction.mean()*x2.rank1_correction.mean()<0)
        shared.append(row)
s=pd.DataFrame(shared).sort_values(['rank1_min_repeat_difference_SSE_reduction','anchor','pair1','pair2'],ascending=[False,True,True,True])
s['min_repeat_gain_descending_rank']=np.arange(1,len(s)+1)
s.to_csv(out/'Jurkat_all_shared_endpoint_comparisons.csv',index=False,float_format='%.17g')

selected={'PGK1|TTI2':'positive shared-TTI2 example: negative correction',
          'OGFOD1|TTI2':'positive shared-TTI2 example: positive correction',
          'MED1|RPL10':'positive individual pair with improvement in both repeats',
          'NIP7|POLN':'limitation: largest pooled SSE worsening among all 617'}
dsel=d[d.pair_id.isin(selected)].copy(); dsel['display_role']=dsel.pair_id.map(selected)
dsel.to_csv(out/'Jurkat_selected_pairs_two_repeats.csv',index=False,float_format='%.17g')
fsel=f[f.pair_id.isin(selected)].copy(); fsel['display_role']=fsel.pair_id.map(selected)
fsel.to_csv(out/'Jurkat_selected_pair_summary.csv',index=False,float_format='%.17g')
c=s[(s.anchor=='TTI2') & (s.pair1=='OGFOD1|TTI2') & (s.pair2=='PGK1|TTI2')]
assert len(c)==1
c.to_csv(out/'Jurkat_TTI2_partner_change.csv',index=False,float_format='%.17g')
pop={m:float(f[m+'_SSE'].sum()) for m in models}
summary={'analysis_type':'post-hoc illustrative examples from existing frozen predictions; no new confirmation',
         'n_pairs':617,'n_repeats':2,'n_all_shared_endpoint_comparisons':len(s),
         'n_pairs_improved_pooled':int((f.rank1_SSE_reduction>0).sum()),
         'n_pairs_improved_both_repeats':int(f.rank1_both_repeats_improved.sum()),
         'n_pairs_worsened_both_repeats':int(f.rank1_both_repeats_worsened.sum()),
         'SSE':pop,'rank1_overall_relative_SSE_reduction':1-pop['rank1_selected']/pop['M0'],
         'selection':selected,
         'selection_rules':'After inspecting saved outcomes, choose a shared-endpoint example with opposite corrections and improvement for both pairs in both repeats (TTI2 with PGK1/OGFOD1); choose MED1/RPL10 for a compact, repeat-consistent large local correction; include the largest pooled deterioration as a limitation. Choices are explanatory and result-informed, not preregistered or representative sampling. All pair and shared-endpoint scores are retained.',
         'display_boundary':'Two pairs sharing TTI2 cancel the shared endpoint only; their difference does not eliminate the two other free endpoint effects. This figure illustrates response prediction and does not independently establish partner specificity. That claim relies on full-panel projected evaluation.',
         'primary_model':'rank1_selected, the frozen Jurkat primary; spectral retained only as secondary reference',
         'unit':'Author-processed growth phenotype gamma in original growth units, not percent growth, viability, GI score, RNA or protein abundance',
         'source':'GSE116198_sgRNA_pair_phenotypes.txt.gz; Jurkat, Triple Sequencing, Replicates 1 and 2; column indexes including ID 4,5',
         'aggregation':source_check['aggregation'],
         'gene_naming':'Preserve the original 79-gene source names; no alias relabelling',
         'training_support':'Actual degree and common neighbors from 2464 permitted training pairs; all 617 test pairs excluded in both repeats',
         'interpretation':'Observed directionally consistent growth-response corrections illustrate estimation of unmeasured CRISPRi combinations; no new mechanistic, therapeutic, hit-rate or prospective selection claim.',
         'source_sha256':source_check['source_sha256'],
         'input_sha256':{str(p.relative_to(args.paper)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [src/'Horlbeck_predictions.csv',src/'Horlbeck_Jurkat_genes.csv',archive]}}
(out/'Jurkat_example_selection.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False)+'\n')
pd.DataFrame({'gene_index':np.arange(79),'gene':train['genes'],'training_degree':degree,
              'single_repeat1':train['singles'][:,0],'single_repeat2':train['singles'][:,1]}).to_csv(out/'Jurkat_gene_support.csv',index=False,float_format='%.17g')
print(json.dumps(summary,indent=2,ensure_ascii=False)); print(fsel.to_string(index=False)); print(dsel[['pair_id','repeat','observed']+models].to_string(index=False)); print(c.to_string(index=False))
