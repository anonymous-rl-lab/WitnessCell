#!/usr/bin/env python3
"""Read-only, post-hoc RNA examples. No fitting, new score selection or hypothesis test.
Uses the archived v17 three-inner-fold prediction protocol, not the later single-fold
sensitivity. Sources are identity checked and every four-corner contrast is reconstructed.
"""
from pathlib import Path
import argparse,csv,gzip,json,hashlib
import numpy as np

def writecsv(p,rows):
    op=gzip.open if str(p).endswith('.gz') else open
    with op(p,'wt',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def percent(v,a):return float(100*np.mean(a<=v))
def main():
    a=argparse.ArgumentParser();a.add_argument('--root',default='/workspace/scratch/2c1de068d91a');a.add_argument('--out',default=None);args=a.parse_args()
    root=Path(args.root);out=Path(args.out) if args.out else Path(__file__).resolve().parent;out.mkdir(exist_ok=True,parents=True)
    sources={'signed':root/'witnesscell_paper_v17_full/source_data/RNA_signed_rectangle_predictions.npz','rectangles':root/'witnesscell_paper_v17_full/source_data/RNA_rectangle_definition.csv','predictions':root/'confirmation_20261018/controls/CONTROL_PREDICTIONS.npz','observations':root/'head_to_head_20261018/data/evaluation_only.npz','expression_documentation':root/'head_to_head_20261018/data/README.md'}
    z=dict(np.load(sources['signed'],allow_pickle=False));p=dict(np.load(sources['predictions'],allow_pickle=False));e=dict(np.load(sources['observations'],allow_pickle=False))
    with open(sources['rectangles']) as f:rect=list(csv.DictReader(f))
    genes=z['genes'];pairs=p['pairs'];gi={str(g):i for i,g in enumerate(genes)};pi={str(q):i for i,q in enumerate(pairs)};ei={str(q):i for i,q in enumerate(e['conditions'])};mask=e['score_gene_mask'];assert np.array_equal(e['genes'][mask],genes);assert np.array_equal(p['genes'],genes)
    truth=z['truth_effect'];err={k:(z[k]-truth)**2 for k in ['M0','M1','R','scalar']};gain=err['M0']-err['R'];ggenes=gain.sum(0);gorder=np.argsort(-ggenes,kind='stable');grank=np.empty(len(genes),int);grank[gorder]=np.arange(1,len(genes)+1)
    arank=np.empty(gain.size,int);arank[np.argsort(-gain.ravel(),kind='stable')]=np.arange(1,gain.size+1);arank=arank.reshape(gain.shape)
    conditions=e['means'][:,mask];half1=e['first_means'][:,mask];half2=e['second_means'][:,mask];control=conditions[ei['control']]
    assert np.array_equal(control,p['control']);assert np.allclose(conditions[[ei[str(q)] for q in pairs]]-control,p['truth_effect'],rtol=0,atol=1e-14)
    endpoints=sorted(set(x for q in pairs for x in str(q).split('+')));x=np.array([[float(g in str(q).split('+')) for g in endpoints] for q in pairs]);stats={};max_wdiff=0
    for fold in range(5):
        ti=np.flatnonzero(p['fold_ids']!=fold);ex=[ei[str(pairs[q])] for q in ti];pt=np.eye(len(ti))-x[ti]@np.linalg.pinv(x[ti]);za=pt@half1[ex];zb=pt@half2[ex];aa=(za*za).sum(0);bb=(zb*zb).sum(0);cross=(za*zb).sum(0);raw=np.divide(cross,.5*(aa+bb),out=np.zeros(len(genes)),where=(aa+bb)>0);calc=raw.clip(0,1);max_wdiff=max(max_wdiff,float(np.max(abs(calc-p['weights'][fold]))));cos=np.divide(cross,np.sqrt(aa*bb),out=np.zeros(len(genes)),where=(aa*bb)>0)
        stats[fold]={'raw':raw,'cos':cos,'half1_rms':np.sqrt(aa/len(ti)),'half2_rms':np.sqrt(bb/len(ti)),'training_pairs':len(ti),'projected_dof':int(round(np.trace(pt)))}
    max_cdiff=0.;rows=[]
    for r,d in enumerate(rect):
        f=int(d['fold'])-1;qs=d['ordered_pairs'].split('|');sign=np.array([float(x) for x in d['signs'].split('|')]);ids=[pi[q] for q in qs];assert np.all(p['fold_ids'][ids]==f)
        for k in ['truth_effect','M0','M1','R','scalar']:max_cdiff=max(max_cdiff,float(np.max(abs(sign@p[k][ids]-z[k][r]))))
        for g,name in enumerate(genes):
            row={'rectangle':r+1,'fold':f+1,'gene':str(name),'C_observed':float(truth[r,g]),**{f'C_{k}':float(z[k][r,g]) for k in err},'R_weight':float(p['weights'][f,g]),'gain_R_vs_M0_squared_units':float(gain[r,g]),'gain_R_vs_M1_squared_units':float(err['M1'][r,g]-err['R'][r,g]),'rank_gain_among_54945':int(arank[r,g]),'gene_gain_rank_among_4995':int(grank[g])};rows.append(row)
    writecsv(out/'all_rectangle_readout_candidates.csv.gz',rows)
    gene_rows=[{'gene':str(genes[g]),'net_gain_R_vs_M0_squared_units':float(ggenes[g]),'gain_rank':int(grank[g]),'positive_rectangles':int(np.sum(gain[:,g]>0)),'negative_rectangles':int(np.sum(gain[:,g]<0)),'zero_rectangles':int(np.sum(gain[:,g]==0)),'mean_weight':float(np.mean(p['weights'][:,g])),'positive_gain':float(np.maximum(gain[:,g],0).sum()),'negative_gain':float(np.minimum(gain[:,g],0).sum())} for g in gorder]
    writecsv(out/'all_gene_summary.csv',gene_rows)
    # Descriptive selection after observing archived outcomes, NOT prespecified discovery.
    # Positive readouts were already named and top-ranked in v17, not discovered here.
    choices=[('positive_S100A9',int(np.argmax(gain[:,gi['S100A9']])),gi['S100A9']),('positive_LYZ',int(np.argmax(gain[:,gi['LYZ']])),gi['LYZ'])]
    rr,gg=np.unravel_index(np.argmin(gain),gain.shape);choices.append(('failure_global_largest_harm',int(rr),int(gg)))
    corners=[];contrasts=[];examples=[];single_rows=[]
    for case,r,g in choices:
        d=rect[r];f=int(d['fold'])-1;qs=d['ordered_pairs'].split('|');sign=np.array([float(x) for x in d['signs'].split('|')]);ids=[pi[q] for q in qs];s=stats[f];weights=p['weights'][f];truthvals=p['truth_effect'][ids,g];partners=sorted(set(v for q in qs for v in q.split('+')));row1=next(iter(set(qs[0].split('+')) & set(qs[1].split('+'))));col1=next(v for v in qs[0].split('+') if v!=row1);col2=next(v for v in qs[1].split('+') if v!=row1);row2=next(v for v in qs[2].split('+') if v!=col1);assert set(qs[3].split('+'))=={row2,col2}
        for j,(q,sgn) in enumerate(zip(qs,sign)):
            k=ei[q];row={'case':case,'gene':str(genes[g]),'rectangle':r+1,'fold':f+1,'corner':j+1,'row_endpoint':row1 if j<2 else row2,'column_endpoint':col1 if j%2==0 else col2,'pair':q,'contrast_sign':int(sgn),'cells':int(e['counts'][k]),'control_mean':float(control[g]),'observed_effect':float(p['truth_effect'][ids[j],g]),'observed_condition_mean':float(conditions[k,g]),'half1_condition_mean':float(half1[k,g]),'half2_condition_mean':float(half2[k,g]),'half1_cells':int(e['first_counts'][k]),'half2_cells':int(e['second_counts'][k])}
            row.update({f'{model}_effect':float(p[model][ids[j],g]) for model in err});corners.append(row)
        for endpoint in partners:
            j=ei[endpoint];single_rows.append({'case':case,'gene':str(genes[g]),'perturbed_endpoint':endpoint,'observed_single_effect':float(conditions[j,g]-control[g]),'single_condition_mean':float(conditions[j,g]),'cells':int(e['counts'][j])})
        for model in err:
            contrasts.append({'case':case,'gene':str(genes[g]),'rectangle':r+1,'model':model,'observed_contrast':float(truth[r,g]),'predicted_contrast':float(z[model][r,g]),'signed_prediction_error':float(z[model][r,g]-truth[r,g]),'squared_error':float(err[model][r,g]),'absolute_error':float(abs(z[model][r,g]-truth[r,g])),'four_corner_MSE':float(np.mean((p[model][ids,g]-truthvals)**2))})
        examples.append({'case':case,'readout':str(genes[g]),'rectangle':r+1,'outer_fold':f+1,'row_endpoints':[row1,row2],'column_endpoints':[col1,col2],'ordered_pairs':qs,'signs':sign.astype(int).tolist(),'training_pairs':s['training_pairs'],'training_projected_dof':s['projected_dof'],'training_weight':float(weights[g]),'weight_percentile_within_fold':percent(weights[g],weights),'raw_training_half_agreement':float(s['raw'][g]),'training_projected_half_cosine':float(s['cos'][g]),'training_projected_half1_RMS':float(s['half1_rms'][g]),'training_projected_half2_RMS':float(s['half2_rms'][g]),'uniform_inner_selected_c':float(p['scalar_c'][f]),'gene_net_gain_rank':int(grank[g]),'case_raw_gain_rank_among_54945':int(arank[r,g]),'case_gain_percentile':percent(gain[r,g],gain),'absolute_observed_contrast_percentile':percent(abs(truth[r,g]),abs(truth)),'gain_R_vs_M0_squared_units':float(gain[r,g]),'contrast_error_reduction_R_vs_M0':float(gain[r,g]/err['M0'][r,g]),'observed_contrast':float(truth[r,g]),'M0_contrast':float(z['M0'][r,g]),'M1_contrast':float(z['M1'][r,g]),'R_contrast':float(z['R'][r,g]),'scalar_contrast':float(z['scalar'][r,g])})
    writecsv(out/'selected_four_corners.csv',corners);writecsv(out/'selected_contrasts.csv',contrasts);writecsv(out/'selected_permitted_single_responses.csv',single_rows)
    # All rectangles for the two illustrated readouts prevent a best-case-only view.
    writecsv(out/'selected_readouts_all_11_rectangles.csv',[q for q in rows if q['gene'] in ['S100A9','LYZ']])
    counts={'positive_R_vs_M0':int(np.sum(gain>0)),'negative_R_vs_M0':int(np.sum(gain<0)),'zero_R_vs_M0':int(np.sum(gain==0)),'positive_readouts_net':int(np.sum(ggenes>0)),'negative_readouts_net':int(np.sum(ggenes<0)),'zero_readouts_net':int(np.sum(ggenes==0))}
    result={'analysis':'Post-hoc explanatory examples from saved v17 original-protocol predictions; no new training.','selection_rule':'S100A9 and LYZ were named before this analysis among v17 top-ten gain readouts. For each, show the rectangle with the largest absolute R-versus-M0 squared-error reduction. Show additionally the globally largest harmful R-versus-M0 correction across all 11 x 4,995 coordinates (LYZ rectangle5). These are deliberately contrasting illustrative extrema, not representative estimates, prespecified tests or new biological discoveries.','units':'Original Wessels.h5ad X/logNor, without re-normalization (head_to_head data/README.md). Effect = mean logNor(condition) minus mean logNor(control); contrast = difference of differences in the same logNor units. Means of log-normalized expression, not log of mean counts; no raw-count or fold-change interpretation.','shared_control_cancels_in_rectangle':True,'independence':'Cell halves are within-experiment splits, not biological replicates. Overlapping rectangles/readouts not independent.','verification':{'max_four_corner_vs_archived_contrast_difference':max_cdiff,'max_recomputed_training_weight_difference':max_wdiff},'all_candidate_counts':counts,'aggregate_C_MSE':{k:float(v.mean()) for k,v in err.items()},'example_records':examples,'sources':{k:{'path':str(v.relative_to(root)),'sha256':sha(v)} for k,v in sources.items()}}
    (out/'RNA_EXAMPLES.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n');print(json.dumps(result,indent=2,ensure_ascii=False))
if __name__=='__main__':main()
