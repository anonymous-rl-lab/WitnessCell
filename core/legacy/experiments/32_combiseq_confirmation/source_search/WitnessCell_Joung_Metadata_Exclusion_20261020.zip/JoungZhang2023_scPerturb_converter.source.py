import subprocess
import os
import sys
import matplotlib.backends.backend_pdf
import scanpy as sc
import matplotlib.pyplot as pl
import anndata as ad
import pandas as pd
import numpy as np
import seaborn as sns

from pathlib import Path

# Jupyter stuff
from tqdm.notebook import tqdm
from IPython.display import clear_output
from IPython.core.display import display, HTML
display(HTML("<style>.container { width:95% !important; }</style>"))

%matplotlib inline

# Custom functions
sys.path.insert(1, '../')
from utils import *

# scperturb package
sys.path.insert(1, '../package/src/')
from scperturb import *

from pathlib import Path
figure_path = Path('../figures/')

TEMPDIR = Path('/scratch/peidli/scPerturb/JoungZhang2023')

file = TEMPDIR / 'GSE217460_210322_TFAtlas_S01-S04.csv'

tab = pd.read_csv(file, index_col=0)

import dask.dataframe as ddf
tab = ddf.read_csv(file, sample=int(1e8))





import re
import h5py
from scipy.sparse import csr_matrix, vstack


atlas = TEMPDIR / 'GSE217460_210322_TFAtlas.h5ad'

f = h5py.File(atlas, "r")

chunk_size = 10000
iterations = int(np.ceil(f['X'].shape[0] / chunk_size) + 1)
chunks = [csr_matrix(f['X'][i*chunk_size:(i+1)*chunk_size]) for i in tqdm(range(iterations))]
X = vstack(chunks)
print('X.shape', X.shape)
# sparsity is high (~95% of entries are empty)
print(f'Sparsity: {np.round(100* X.count_nonzero() / np.product(X.shape), 2)}%')
# obs
keys = [k for k in f['obs'].keys() if not k.startswith('__')]
obs = pd.DataFrame(np.vstack([np.array(f['obs'][k]) for k in keys]).T, columns=keys)
obs.set_index('_index', inplace=True)
obs.index = obs.index.astype(str)
obs.index.name='cell_barcode'
# var
keys = [k for k in f['var'].keys() if not k.startswith('__')]
var = pd.DataFrame(np.vstack([np.array(f['var'][k]) for k in keys]).T, columns=keys)
var.set_index('_index', inplace=True)
var.index = var.index.astype(str)
var.index.name='gene_symbol'

# assemble
adata = sc.AnnData(X=X, obs=obs, var=var)

# set metadata
# TODO: Perturbation here is just a number. Find out what it means!!!
adata.obs = adata.obs.rename({'n_genes': 'ngenes', 'n_counts': 'ncounts', 'TF': 'perturbation'}, axis=1)
adata.obs['disease'] = "healthy"
adata.obs['cancer'] = False
adata.obs['tissue_type']="cell_line"
adata.obs["cell_line"] = "hESCs"
adata.obs["celltype"] = 'hESCs'
adata.obs['organism'] = 'human'
adata.obs['perturbation_type'] = 'ORF overexpression'
adata.obs['nperts'] = 1
annotate_qc(adata, species='human')
adata.obs.index.name = 'cell_barcode'

assert_annotations(adata)

adata.obs.perturbation = adata.obs.perturbation.astype(str)
adata.obs.batch = adata.obs.batch.astype(str)
adata.obs.louvain = adata.obs.louvain.astype(str)
adata.obs.ncounts = adata.obs.ncounts.astype(int)
adata.obs.ngenes = adata.obs.ngenes.astype(int)
adata.obs.percent_mito = adata.obs.percent_mito.astype(float)

adata.obs.percent_mito = adata.obs.percent_mito.astype(float)

adata.write(TEMPDIR / 'test.h5ad')

keys = sorted([f.name.replace('_barcodes.tsv.gz', '') for f in path.glob('*_barcodes*')])

adata = sc.read_10x_mtx(path, prefix=keys[0]+'_')

adata

sorted([f.name for f in path.glob('*')])

df = pd.read_csv(path / 'GSM6719979_210322_TFmap_S10.csv.gz', index_col=0, header=None)

# get scRNA-seq from here!:
#https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE216463

# wget --recursive --no-parent -nd -R "index.html*" ftp://ftp.ncbi.nlm.nih.gov/geo/series/GSE216nnn/GSE216463/suppl/
# wget --recursive --no-parent -nd -R "index.html*" ftp://ftp.ncbi.nlm.nih.gov/geo/series/GSE216nnn/GSE216457/suppl/
# wget --recursive --no-parent -nd -R "index.html*" ftp://ftp.ncbi.nlm.nih.gov/geo/series/GSE216nnn/GSE216602/suppl/
# wget --recursive --no-parent -nd -R "index.html*" ftp://ftp.ncbi.nlm.nih.gov/geo/series/GSE216nnn/GSE216601/suppl/
# wget --recursive --no-parent -nd -R "index.html*" ftp://ftp.ncbi.nlm.nih.gov/geo/series/GSE216nnn/GSE216595/suppl/
# wget --recursive --no-parent -nd -R "index.html*" ftp://ftp.ncbi.nlm.nih.gov/geo/series/GSE217nnn/GSE217460/suppl/
# wget --recursive --no-parent -nd -R "index.html*" ftp://ftp.ncbi.nlm.nih.gov/geo/series/GSE217nnn/GSE217066/suppl/

GSE216463_keys = [x.name.replace('_matrix.mtx.gz', '') for x in TEMPDIR.glob('GSM66743*_matrix.mtx.gz')]
GSE216457_keys = [x.name.replace('_matrix.mtx.gz', '') for x in TEMPDIR.glob('GSM66742*_matrix.mtx.gz')]

GSE216463_keys

adata = sc.read_10x_mtx(TEMPDIR, prefix=GSE216457_keys[0]+'_')

adata.var

bdata = sc.read_10x_mtx(TEMPDIR, prefix=GSE216463_keys[0]+'_')

bdata.obs

# relevant (having perturbations and controls) are:
# 'GSE217066_210715_combinatorial.h5ad'
# 'GSE217460_210322_TFAtlas.h5ad'

[x.name for x in TEMPDIR.glob('*h5ad')]

adata = sc.read(TEMPDIR / 'GSE216457_191108_TFv2d56.h5ad')

adata

scv.pl.scatter(adata, dpi=120, color=['louvain', 'celltype'], legend_loc='on data')

# this works on lots of RAM
tdata = sc.read_h5ad(TEMPDIR / 'GSE217066_210715_combinatorial.h5ad')

# their adata.X was scaled and their adata.raw.X was saved as dense...
# reconstruct unfiltered count matrix and make true sparse
from scipy.sparse import csr_matrix, vstack
adata = sc.AnnData(csr_matrix(tdata.raw.X), tdata.obs, tdata.raw.var, 
                   tdata.uns, tdata.obsm, obsp=tdata.obsp)

# clean up names
import re
adata.obs['perturbation'] = ['+'.join(sorted(re.sub(r'TFORF[0-9]{4}-', ' ', s).replace(' ','').split(','))) for s in adata.obs.TF]  # cleaner names

scv.pl.scatter(adata, basis='umap', color='TF', dpi=120, legend_loc='right margin')

scv.pl.scatter(adata, basis='umap', color='perturbation', dpi=120, legend_loc='right margin')

adata

def adapt(adata):
    adata.obs = adata.obs.rename({'n_genes': 'ngenes', 'n_counts': 'ncounts'}, axis=1)
    adata.obs['disease'] = "healthy"
    adata.obs['cancer'] = False
    adata.obs['tissue_type']="cell_line"
    adata.obs["cell_line"] = "hESCs"
    adata.obs["celltype"] = 'hESCs'
    adata.obs['organism'] = 'human'
    adata.obs['perturbation_type'] = 'ORF overexpression'
    adata.obs['nperts'] = [p.count('+') + 1 - p.count('GFP') for p in adata.obs.perturbation]
    annotate_qc(adata, species='human')
    adata.obs.index.name = 'cell_barcode'
    return adata

[p.count('+') + 1 - p.count('GFP') for p in adata.obs.perturbation]

[p for p in adata.obs.perturbation]

adata

adata = adapt(adata)

annotate_qc(adata, species='human')

assert_annotations(adata)

# clusters 6,7,8 of differentiated cells
bdata = sc.read_h5ad(TEMPDIR / 'GSE217460_210322_TFAtlas_differentiated.h5ad')

bdata

scv.pl.scatter(bdata, color='louvain', legend_loc='on data')

sorted(list([x.split('-',1)[-1] for x in bdata.obs.TF.unique()]))[-10:]

bdata.obs['TF'] = [x.split('-',1)[1] for x in bdata.obs['TF']]
bdata.obs['TF_'] = bdata.obs.TF.copy().astype(str)
bdata.obs['TF_'][bdata.obs.TF.isin(['mCherry', 'GFP'])] = 'control'

sdata = equal_subsampling(bdata, 'TF', N_min=50)
ed = edist(sdata, 'TF')
ed = cluster_matrix(ed, 'both')

fig, ax = pl.subplots(1,1, figsize=[10,8])
sns.heatmap(ed, robust=True)
pl.show()

et = etest(sdata, 'TF_', control='control')

et

pl.figure(figsize=(20,6))
sns.barplot(data=et.reset_index(), x='index', y='edist', hue='significant_adj', dodge=False, order=et.sort_values('edist').index)
pl.xticks(rotation=90)
pl.show()

# not loadable
tab = pd.read_csv(TEMPDIR / 'GSE217460_210322_TFAtlas_S01-S04.csv', usecols=[0,1,2,3,4,5])

tab.head()

import anndata as ad
ad.__version__

# this fails, tested in anndata v0.8.0
# cdata = ad.read_h5ad(TEMPDIR / 'GSE217460_210322_TFAtlas.h5ad')
# AnnDataReadError: Above error raised while reading key '/X' of type <class 'h5py._hl.dataset.Dataset'> from /. 

import h5py
f = h5py.File(TEMPDIR / 'GSE217460_210322_TFAtlas.h5ad', "r")
list(f.keys())

# get obs
keys = [k for k in f['obs'].keys() if not k.startswith('__')]
obs = pd.DataFrame(np.vstack([np.array(f['obs'][k]) for k in keys]).T, columns=keys)
obs.set_index('_index', inplace=True)
obs.index = obs.index.astype(str)
obs.index.name='cell_barcode'

# get vars
keys = [k for k in f['var'].keys() if not k.startswith('__')]
var = pd.DataFrame(np.vstack([np.array(f['var'][k]) for k in keys]).T, columns=keys)
var.set_index('_index', inplace=True)
var.index = var.index.astype(str)
var.index.name='gene_symbol'

len(obs), len(var)

obs.TF.max()

obs.TF

f['X']  # this is not sparse

# could have been saved as sparse though...
f['X'][0,:]

from scipy.io import mmwrite

from pathlib import Path
Path('/fast/scratch/users/peidlis_c/perturbation_resource_paper/chunks/').mkdir(parents=True, exist_ok=True)

f['X'].shape

obs.shape

# convert to sparse in a chunked fashion
from scipy.sparse import csr_matrix

# We load the original dense data per chunk and convert each to sparse (csr) right on the spot
# This avoids loading all data as dense into memory (too big)
chunk_size = 10000
iterations = int(np.ceil(f['X'].shape[0] / 10000) + 1)
for i in tqdm(range(iterations)):
    chunk = csr_matrix(f['X'][i*chunk_size:(i+1)*chunk_size])
    mmwrite(f'/fast/scratch/users/peidlis_c/perturbation_resource_paper/chunks/{i}_chunk.mtx', chunk)

# convert to sparse in a chunked fashion
from scipy.sparse import csr_matrix

# We load the original dense data per chunk and convert each to sparse (csr) right on the spot
# This avoids loading all data as dense into memory (too big)
chunk_size = 10000
iterations = int(np.ceil(f['X'].shape[0] / chunk_size) + 1)
i = iterations - 10
csr_matrix(f['X'][i*chunk_size:(i+1)*chunk_size])

iterations

10600000 - f['X'].shape[0]

i*chunk_size, (i+1)*chunk_size

from scipy.sparse import vstack
X = vstack(chunks)

# sparsity is high (~95% of entries are empty)
print(f'Sparsity: {np.round(100* X.count_nonzero() / np.product(X.shape), 2)}%')

# Fig S4I
ddata = sc.read(TEMPDIR / 'GSE216595_180124_perturb.h5ad')
ddata

sorted(list(ddata.obs.TF.unique()))

scv.pl.scatter(ddata, color='louvain')

# Fig S5F
edata = sc.read(TEMPDIR / 'GSE216601_180525_CM.h5ad')
edata

scv.pl.scatter(edata, color='louvain')













