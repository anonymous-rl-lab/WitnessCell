#!/usr/bin/env python3
"""Strict metadata-only audit. Never opens expression, embedding or QC datasets.

Allowed datasets: obs/{perturbation,batch,TF,nperts,cell_barcode}, var/_index.
The X group is used only for its shape attribute, never data/indices/indptr.
"""
import hashlib
import json
from collections import Counter
from pathlib import Path

import h5py
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent
PATH = ROOT / "raw/JoungZhang2023_combinatorial.h5ad"
OUT = ROOT / "metadata"
OUT.mkdir(exist_ok=True)


def read_meta(g, key):
    x = g[key]
    if isinstance(x, h5py.Group):
        cats = x["categories"].asstr()[:]
        codes = x["codes"][:]
        return np.array([cats[i] if i >= 0 else "MISSING" for i in codes])
    if h5py.check_string_dtype(x.dtype):
        return x.asstr()[:]
    return x[:]


with h5py.File(PATH, "r") as f:
    shape = list(map(int, f["X"].attrs["shape"]))
    obs_keys = list(f["obs"].keys())
    obs = pd.DataFrame({k: read_meta(f["obs"], k) for k in
                        ["perturbation", "batch", "TF", "nperts", "cell_barcode"]})
    # Save names only; gene abundance metadata is intentionally not read.
    genes = read_meta(f["var"], "_index")


def targets(label):
    return tuple(sorted(g for g in label.split("+") if g != "GFP"))


obs["targets"] = obs.perturbation.map(targets)
obs["target_count"] = obs.targets.map(len)
assert np.array_equal(obs.target_count.values, obs.nperts.values)
condition = obs.groupby(["perturbation", "target_count"]).size().reset_index(name="cells")
condition["targets"] = condition.perturbation.map(lambda x: "+".join(targets(x)))
condition.to_csv(OUT / "condition_counts.csv", index=False)
batch_condition = obs.groupby(["batch", "perturbation", "target_count"]).size().reset_index(name="cells")
batch_condition.to_csv(OUT / "batch_condition_counts.csv", index=False)
obs.drop(columns=["targets"]).to_csv(OUT / "cell_metadata_only.csv.gz", index=False)
pd.Series(genes, name="gene_symbol").to_csv(OUT / "gene_names_only.csv", index=False)

single_counts = {targets(row.perturbation)[0]: int(row.cells)
                 for row in condition.itertuples() if row.target_count == 1}
pairs = []
for row in condition.itertuples():
    if row.target_count != 2:
        continue
    a, b = targets(row.perturbation)
    pairs.append(dict(pair=row.perturbation, gene_a=a, gene_b=b, cells=int(row.cells),
                      single_a_cells=single_counts.get(a, 0),
                      single_b_cells=single_counts.get(b, 0)))
pairs = pd.DataFrame(pairs).sort_values("pair")
pairs.to_csv(OUT / "pair_coverage.csv", index=False)

def graph_audit(frame):
    endpoints = sorted(set(frame.gene_a) | set(frame.gene_b))
    ix = {g: i for i, g in enumerate(endpoints)}
    X = np.zeros((len(frame), len(endpoints)))
    for j, row in enumerate(frame.itertuples()):
        X[j, ix[row.gene_a]] = X[j, ix[row.gene_b]] = 1
    rank = int(np.linalg.matrix_rank(X)) if X.size else 0
    degrees = {g: int(X[:, i].sum()) for g, i in ix.items()}
    return dict(pairs=len(frame), endpoints=len(endpoints), incidence_rank=rank,
                endpoint_orthogonal_dimension=len(frame)-rank,
                total_pair_cells=int(frame.cells.sum()), degrees=degrees,
                min_pair_cells=int(frame.cells.min()) if len(frame) else 0,
                median_pair_cells=float(frame.cells.median()) if len(frame) else 0)

thresholds = {}
for n in [1, 10, 20, 30, 50, 100]:
    mask = (pairs.cells >= n) & (pairs.single_a_cells >= n) & (pairs.single_b_cells >= n)
    thresholds[str(n)] = graph_audit(pairs[mask])
batch_summary = []
for batch in sorted(obs.batch.unique()):
    sub = batch_condition[batch_condition.batch == batch]
    ss = {targets(r.perturbation)[0]: int(r.cells)
          for r in sub.itertuples() if r.target_count == 1}
    pp = [r for r in sub.itertuples() if r.target_count == 2]
    eligible = [r for r in pp if r.cells >= 20 and
                all(ss.get(g, 0) >= 20 for g in targets(r.perturbation))]
    batch_summary.append(dict(batch=str(batch), cells=int(sub.cells.sum()),
                              singles=sum(sub.target_count == 1), doubles=len(pp),
                              triples=sum(sub.target_count == 3),
                              pairs_with_20_cells_and_matching_20_cell_singles=len(eligible)))

summary = {
    "audit_type": "METADATA_ONLY_NO_EXPRESSION_OUTCOMES_READ",
    "eligibility_decision": "EXCLUDE_FROM_PREEXISTING_CONTROL_DEPENDENT_FROZEN_PREDICTOR",
    "exclusion_reason": "No matched zero-perturbation control found in harmonized metadata, source converter or official GEO sample metadata; changing the baseline is outside this frozen procedure.",
    "source_url": "https://zenodo.org/records/13350497/files/JoungZhang2023_combinatorial.h5ad?download=1",
    "original_combinatorial_accession": "GSE217066",
    "original_super_series": "GSE216481",
    "paper_doi": "10.1016/j.cell.2022.11.026",
    "file_bytes": PATH.stat().st_size,
    "zenodo_md5_verified": "e3d5f50d228b4d90652b6146e97c605c",
    "shape": shape,
    "obs_fields_available_not_all_read": obs_keys,
    "fields_read": ["obs/perturbation", "obs/batch", "obs/TF", "obs/nperts", "obs/cell_barcode", "obs/cell_line (initial inventory)", "obs/celltype (initial inventory)", "obs/perturbation_type (initial inventory)", "var/_index", "X.attrs.shape"],
    "fields_explicitly_not_read": ["X/data", "X/indices", "X/indptr", "layers/*", "obsm/*", "obsp/*", "uns/*", "obs/louvain", "obs/ncounts", "obs/ngenes", "obs/percent_mito", "obs/percent_ribo", "var/abundance_fields"],
    "control_cells": int(sum(obs.target_count == 0)),
    "conditions_by_target_count": {str(k): int(v) for k, v in condition.groupby("target_count").size().items()},
    "cells_by_target_count": {str(k): int(v) for k, v in obs.groupby("target_count").size().items()},
    "single_counts": single_counts,
    "all_44_pairs_have_matching_singles": bool((pairs.single_a_cells > 0).all() and (pairs.single_b_cells > 0).all()),
    "graph_by_minimum_cells_for_pair_and_both_singles": thresholds,
    "batch_summary": batch_summary,
    "limits": [
        "No independent GFP-only, GFP+GFP, NT or unperturbed control cells exist in this harmonized file.",
        "Singles are TF+GFP in the combinatorial arm; do not silently substitute the separate TF atlas.",
        "Nine numerical batch labels are not proven biological replicates, time points or doses.",
        "ORF overexpression in hESCs is an intervention/context extension, not identical to CRISPRi in K562.",
        "No expression outcomes or model scores informed this audit or dataset selection."
    ]
}
(OUT / "metadata_audit.json").write_text(json.dumps(summary, indent=2, ensure_ascii=False)+"\n")
print(json.dumps(summary, indent=2, ensure_ascii=False))
