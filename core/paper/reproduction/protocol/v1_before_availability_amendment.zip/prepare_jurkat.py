"""ID-only split, original growth-phenotype aggregation; no outcome summaries."""
from pathlib import Path
import sys,json,hashlib,math,datetime,argparse
import numpy as np
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'core'))
import source_prepare_k562 as source

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,v):p.write_text(json.dumps(v,indent=2,allow_nan=False))
def jurkat_columns(reader):
    head=[next(reader) for _ in range(3)]
    if len(set(map(len,head)))!=1:raise ValueError('Inconsistent headers')
    labels=[tuple(head[k][j].strip() for k in range(3)) for j in range(len(head[0]))]
    cols=[]
    for label in [('Jurkat','Triple Sequencing','Replicate 1'),('Jurkat','Triple Sequencing','Replicate 2')]:
        idx=[j for j,x in enumerate(labels) if x==label]
        if len(idx)!=1:raise ValueError('Jurkat columns unresolved')
        cols.append(idx[0])
    return cols,labels

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--raw-dir',type=Path,required=True);args=ap.parse_args()
    lock=json.loads((ROOT/'FREEZE.json').read_text())
    for f,h in lock['files'].items():assert sha(ROOT/f)==h, f
    plan=json.loads((ROOT/'PLAN.json').read_text());genes=json.loads((ROOT/'protocol/genes.json').read_text())
    raw=[]
    for f,h in source.EXPECTED.items():
        p=args.raw_dir/f;assert sha(p)==h, f
        raw.append({'name':f,'sha256':h,'bytes':p.stat().st_size})
    source.header_columns=jurkat_columns
    mapping,annotation=source.read_annotation(args.raw_dir/source.ANNOTATION)
    single,scount,sm,labels=source.collect_physical_pairs(args.raw_dir/source.PHENOTYPES,mapping,'singles')
    missing=[g for g in genes if g not in single or any(v is None for v in single[g])]
    if missing:raise RuntimeError('Frozen panel singles unavailable: '+repr(missing))
    pairs,pcount,pm,_=source.collect_physical_pairs(args.raw_dir/source.PHENOTYPES,mapping,'combinations',set(genes))
    available=sorted(q for q,v in pairs.items() if all(x is not None for x in v))
    if not available:raise RuntimeError('No complete pair measurements')
    index={g:i for i,g in enumerate(genes)}
    edges=np.array([[index[g],index[h]] for g,h in available],dtype=np.int64)
    y=np.array([pairs[q] for q in available]);singles=np.array([single[g] for g in genes])
    ids=np.array(['|'.join(q) for q in available])
    salt=plan['outer_split']['salt']
    order=sorted(range(len(ids)),key=lambda i:(hashlib.sha256((salt+'|pair|'+ids[i]).encode()).hexdigest(),ids[i]))
    ntest=math.ceil(plan['outer_split']['test_fraction']*len(ids))
    test=np.sort(order[:ntest]);train=np.sort(order[ntest:])
    folds=np.array([int.from_bytes(hashlib.sha256(('wc_spectral_smoke_v1|'+s).encode()).digest()[:8],'big')%3 for s in ids[train]])
    assert len(train)>0 and len(test)>0 and set(folds)=={0,1,2}
    assert not set(ids[train])&set(ids[test])
    assert np.all(np.bincount(edges[train].ravel(),minlength=80)>0)
    common={'genes':np.array(genes),'singles':singles}
    np.savez_compressed(ROOT/'inputs/training.npz',**common,edges=edges[train],y=y[train],global_ids=ids[train],inner_fold=folds,low_positions=np.arange(len(train)))
    np.savez_compressed(ROOT/'inputs/query.npz',edges=edges[test],global_ids=ids[test])
    np.savez_compressed(ROOT/'sealed/evaluation_truth.npz',edges=edges[test],global_ids=ids[test],y=y[test])
    np.savez_compressed(ROOT/'inputs/measurement_counts.npz',single_physical_pairs=np.array([scount[g] for g in genes]),pair_ids=ids,pair_physical_counts=np.array([pcount[q] for q in available]))
    X=np.zeros((len(test),80));X[np.arange(len(test)),edges[test,0]]=1;X[np.arange(len(test)),edges[test,1]]=1
    d=len(test)-int(np.linalg.matrix_rank(X));assert d>0
    meta={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'cell_line':'Jurkat','genes':genes,'n_genes':80,'n_pairs':len(ids),'n_train':len(train),'n_test':len(test),'inner_counts':np.bincount(folds,minlength=3).tolist(),'test_contrast_dimension':d,
        'numeric_columns':[['Jurkat','Triple Sequencing','Replicate 1'],['Jurkat','Triple Sequencing','Replicate 2']],
        'source_column_indexes':[4,5],'source_assets':raw,'annotation':annotation,'singles_counts':sm,'combination_counts':pm,
        'missing_pair_ids':['|'.join(q) for q,v in pairs.items() if any(x is None for x in v)],
        'train_ids':ids[train].tolist(),'test_ids':ids[test].tolist(),'new_response_based_guide_filter':False,
        'access_disclosure':'Jurkat numeric values first computationally parsed after FREEZE; truth aggregated and sealed without outcome summaries or fitting. Local procedural separation, not independent third-party blinding.',
        'file_sha256':{str(p.relative_to(ROOT)):sha(p) for p in list((ROOT/'inputs').glob('*.npz'))+list((ROOT/'sealed').glob('*.npz'))}}
    dump(ROOT/'INPUT_PROVENANCE.json',meta)
    print(json.dumps({k:meta[k] for k in ('n_genes','n_pairs','n_train','n_test','inner_counts','test_contrast_dimension')}))
if __name__=='__main__':main()
